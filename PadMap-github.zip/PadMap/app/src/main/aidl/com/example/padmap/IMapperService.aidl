package com.example.padmap;
interface IMapperService {
    void destroy() = 16777114;
    void start(String config) = 1;
    void stop() = 2;
    boolean isRunning() = 3;
}
