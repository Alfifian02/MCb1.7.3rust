package com.example.padmap

import android.os.IBinder
import android.os.SystemClock
import android.view.InputDevice
import android.view.InputEvent
import android.view.MotionEvent
import java.io.DataInputStream
import java.io.File
import java.io.FileInputStream
import java.lang.reflect.Method
import java.nio.ByteBuffer
import java.nio.ByteOrder
import kotlin.concurrent.thread
import kotlin.system.exitProcess

/** Berjalan di proses shell (via Shizuku UserService). Baca /dev/input, suntik sentuhan. */
class MapperService : IMapperService.Stub() {
    private val map = HashMap<Int, IntArray>()          // kode tombol -> [x, y]
    private val streams = ArrayList<FileInputStream>()
    private val ids = LinkedHashMap<Int, Int>()         // kode tombol -> pointer id
    private var downTime = 0L
    @Volatile private var running = false

    private val im: Any
    private val inject: Method

    init {
        val binder = Class.forName("android.os.ServiceManager")
            .getMethod("getService", String::class.java).invoke(null, "input") as IBinder
        im = Class.forName("android.hardware.input.IInputManager\$Stub")
            .getMethod("asInterface", IBinder::class.java).invoke(null, binder)!!
        inject = im.javaClass.getMethod("injectInputEvent", InputEvent::class.java, Int::class.javaPrimitiveType)
    }

    override fun start(config: String) {
        stop()
        map.clear()
        config.split(";").filter { it.contains(":") }.forEach {
            val (c, xy) = it.split(":"); val (x, y) = xy.split(",")
            map[c.toInt()] = intArrayOf(x.toInt(), y.toInt())
        }
        running = true
        File("/dev/input").listFiles { f -> f.name.startsWith("event") }?.forEach { f ->
            thread(isDaemon = true) { readLoop(f) }
        }
    }

    private fun readLoop(f: File) {
        try {
            val fis = FileInputStream(f); synchronized(streams) { streams += fis }
            val din = DataInputStream(fis)
            val raw = ByteArray(24)                      // struct input_event (64-bit)
            val bb = ByteBuffer.wrap(raw).order(ByteOrder.LITTLE_ENDIAN)
            while (running) {
                din.readFully(raw)
                val type = bb.getShort(16).toInt(); val code = bb.getShort(18).toInt() and 0xFFFF
                val value = bb.getInt(20)
                if (type == 1 && map.containsKey(code) && value != 2) touch(code, value == 1)
            }
        } catch (_: Exception) { }
    }

    @Synchronized private fun touch(code: Int, down: Boolean) {
        val now = SystemClock.uptimeMillis()
        if (down) {
            if (ids.containsKey(code)) return
            if (ids.isEmpty()) downTime = now
            ids[code] = (0..9).first { it !in ids.values }
            val idx = ids.keys.indexOf(code)
            send(if (ids.size == 1) MotionEvent.ACTION_DOWN
                 else MotionEvent.ACTION_POINTER_DOWN or (idx shl 8), now)
        } else {
            val idx = ids.keys.indexOf(code); if (idx < 0) return
            send(if (ids.size == 1) MotionEvent.ACTION_UP
                 else MotionEvent.ACTION_POINTER_UP or (idx shl 8), now)
            ids.remove(code)
        }
    }

    private fun send(action: Int, now: Long) {
        val n = ids.size
        val props = arrayOfNulls<MotionEvent.PointerProperties>(n)
        val coords = arrayOfNulls<MotionEvent.PointerCoords>(n)
        ids.entries.forEachIndexed { i, (code, id) ->
            props[i] = MotionEvent.PointerProperties().apply { this.id = id; toolType = MotionEvent.TOOL_TYPE_FINGER }
            coords[i] = MotionEvent.PointerCoords().apply {
                x = map[code]!![0].toFloat(); y = map[code]!![1].toFloat(); pressure = 1f; size = 1f
            }
        }
        val ev = MotionEvent.obtain(downTime, now, action, n, props, coords, 0, 0, 1f, 1f, 0, 0,
            InputDevice.SOURCE_TOUCHSCREEN, 0)
        try { inject.invoke(im, ev, 0) } finally { ev.recycle() }
    }

    override fun stop() {
        running = false
        synchronized(streams) { streams.forEach { try { it.close() } catch (_: Exception) {} }; streams.clear() }
        synchronized(this) { ids.clear() }
    }

    override fun isRunning() = running
    override fun destroy() { stop(); exitProcess(0) }
}
