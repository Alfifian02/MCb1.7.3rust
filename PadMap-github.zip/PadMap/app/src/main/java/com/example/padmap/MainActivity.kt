package com.example.padmap

import android.content.ComponentName
import android.content.Context
import android.content.ServiceConnection
import android.content.pm.PackageManager
import android.os.Bundle
import android.os.IBinder
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import rikka.shizuku.Shizuku

class Btn(val name: String, val code: Int, x: String, y: String) {
    var x by mutableStateOf(x); var y by mutableStateOf(y)
}

class MainActivity : ComponentActivity() {
    private var service: IMapperService? = null
    private var bound by mutableStateOf(false)
    private var active by mutableStateOf(false)

    private val conn = object : ServiceConnection {
        override fun onServiceConnected(n: ComponentName, b: IBinder) {
            service = IMapperService.Stub.asInterface(b); bound = true
            active = service?.isRunning == true
        }
        override fun onServiceDisconnected(n: ComponentName) { service = null; bound = false; active = false }
    }

    private fun connect() {
        val args = Shizuku.UserServiceArgs(ComponentName(packageName, MapperService::class.java.name))
            .daemon(false).processNameSuffix("mapper").version(1)
        Shizuku.bindUserService(args, conn)
    }

    override fun onCreate(s: Bundle?) {
        super.onCreate(s)
        val prefs = getSharedPreferences("map", Context.MODE_PRIVATE)
        val defs = listOf("A" to 304, "B" to 305, "X" to 307, "Y" to 308,
            "L1" to 310, "R1" to 311, "L2" to 312, "R2" to 313)
        val buttons = defs.map { (n, c) -> Btn(n, c, prefs.getString("x$c", "") ?: "", prefs.getString("y$c", "") ?: "") }
        var shizukuOk by mutableStateOf(false)

        Shizuku.addRequestPermissionResultListener { _, r ->
            shizukuOk = r == PackageManager.PERMISSION_GRANTED; if (shizukuOk) connect()
        }
        try {
            if (Shizuku.pingBinder() && Shizuku.checkSelfPermission() == PackageManager.PERMISSION_GRANTED) {
                shizukuOk = true; connect()
            }
        } catch (_: Throwable) {}

        setContent {
            MaterialTheme(colorScheme = darkColorScheme()) {
                Surface(Modifier.fillMaxSize()) {
                    Column(Modifier.systemBarsPadding().padding(16.dp)) {
                        Text("PadMap", style = MaterialTheme.typography.headlineMedium)
                        Text(
                            when { !shizukuOk -> "Shizuku belum terhubung"
                                   active -> "Aktif — mapping berjalan"
                                   else -> "Siap" },
                            color = if (active) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurfaceVariant
                        )
                        Spacer(Modifier.height(12.dp))
                        if (!shizukuOk) {
                            Button(onClick = {
                                try { if (Shizuku.pingBinder()) Shizuku.requestPermission(0) } catch (_: Throwable) {}
                            }, Modifier.fillMaxWidth()) { Text("Beri izin Shizuku") }
                        }
                        Text("Koordinat layar tujuan (px) tiap tombol:", Modifier.padding(vertical = 8.dp))
                        LazyColumn(Modifier.weight(1f)) {
                            items(buttons) { b ->
                                Row(Modifier.padding(vertical = 4.dp), verticalAlignment = Alignment.CenterVertically) {
                                    Text(b.name, Modifier.width(44.dp), style = MaterialTheme.typography.titleMedium)
                                    OutlinedTextField(b.x, { b.x = it.filter(Char::isDigit) }, Modifier.weight(1f),
                                        label = { Text("X") }, singleLine = true,
                                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number))
                                    Spacer(Modifier.width(8.dp))
                                    OutlinedTextField(b.y, { b.y = it.filter(Char::isDigit) }, Modifier.weight(1f),
                                        label = { Text("Y") }, singleLine = true,
                                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number))
                                }
                            }
                        }
                        Button(
                            enabled = bound,
                            onClick = {
                                if (active) { service?.stop(); active = false }
                                else {
                                    val e = prefs.edit()
                                    buttons.forEach { e.putString("x${it.code}", it.x); e.putString("y${it.code}", it.y) }
                                    e.apply()
                                    val cfg = buttons.filter { it.x.isNotEmpty() && it.y.isNotEmpty() }
                                        .joinToString(";") { "${it.code}:${it.x},${it.y}" }
                                    service?.start(cfg); active = true
                                }
                            },
                            modifier = Modifier.fillMaxWidth().height(52.dp)
                        ) { Text(if (active) "BERHENTI" else "MULAI") }
                    }
                }
            }
        }
    }
}
