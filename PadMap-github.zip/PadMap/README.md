# PadMap
Build: buka folder di Android Studio -> Build > Build APK(s), atau `./gradlew assembleRelease`.
Pakai: jalankan Shizuku -> buka PadMap -> beri izin -> isi koordinat X/Y tiap tombol -> MULAI.
Tip koordinat: Pengaturan Developer > "Pointer location" untuk melihat X/Y layar.
