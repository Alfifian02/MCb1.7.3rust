//! Rivers, streams and lakes for every world type: a port of the Fabric mod "Streams Reflowing" 2.15.2 (nicejohn).
//!
//! The mod was read from its class files (no source was available); every number marked `mod:` below was read from the bytecode and
//! the plate lattice and hashing were checked bit for bit against the mod's own classes. The values are the ones the game really runs
//! with (`StreamsSettings` defaults, `QualityPreset.MEDIUM`, `WatershedSize.DEFAULT`, `StreamsWorldgen.engine`), not the core's
//! `StreamsConfig.defaults()`. How it works, as in the mod:
//!
//! * **Plates** (`core.plate`): the world is cut into jittered Voronoi cells of 768 blocks (`PlateLattice`, jitter 0.45). Each plate
//!   gets one river network, built once and cached.
//! * **Grid** (`core.grid.LowResGrid`): the terrain is read every 16 blocks over the plate and a margin of `HALO` cells. The generator
//!   reads it itself (`OverworldGenerator::probe`: the vanilla density column or `Tectonic::surface`), so Vanilla and Tectonic worlds
//!   use this same code.
//! * **Routing** (`NetworkTracer.build`): priority flood from the sea (depressions are filled, `+0.001` a step), D8 receivers on the
//!   filled surface, flow accumulation (0.8 per cell), a cell is a stream from `max(1, 6 * 0.75)` = 4.5, dry headwaters are dropped
//!   with the odds `clamp((wetness - 0.2) / 0.5, 0.1, 1)` and everything downstream of a kept headwater stays, two stream systems that
//!   touch yield to the bigger one (separation), basins of at least 4 cells and 1.5 blocks deep become lakes.
//! * **Every river reaches the sea.** A river that leaves the window is traced on over the real terrain (best-first, lowest pass first)
//!   until it finds the sea; one that finds none is culled with everything upstream (the mod's "4b5 CULL: drainage reaches no water").
//!   A lake is not an end: it spills over its lowest rim and the stream goes on from there.
//! * **Shape** (`NetworkTracer`): chains run from a headwater or confluence to the next confluence or the sea; the grade never rises
//!   downstream; Chaikin corner cutting x3, then the mod's meander (three sines, phases from the hash, amplitude `16 * 1.2`, tapered at
//!   both ends, damped on steep ground).
//! * **Width** (`NetworkTracer.a(.., HydraulicGeometry, ..)`, every slider 0.5 by default, so on): the half width is
//!   `min(16, 0.4 + sqrt(acc * 256 / 2500))`, then follows the slope (steeper: narrower), the climate, a slow random variation, braiding
//!   on flat loose ground and delta mouths over the last 64 blocks into the sea, kept inside the base width's inset class.
//! * **Short streams** (`minStreamLength`, here `MIN_LEN` 160 blocks): a source's stretch to the confluence where it is not the biggest branch, or to the
//!   sea, must be that long, else its cells are dropped (repeated until nothing short is left).
//! * **Column plan** (`RiverEngine.plan`): a column is in the channel when its distance to the centre line is under the half width,
//!   in the bank up to `max(5, 2 * width)` further; water surface `max(sea - 1, floor(grade - inset))`, then made level with a bigger river at a confluence (`LEVEL_RUN`), depth `max(1, round(2 * width * 0.24))`.
//! * **Current** (`FlowSpeed`): `clamp((slope / (1/7))^(1/3) * clamp(base width / width, 0.6, 1.8), 0.25, 2)`, times a depth factor.
//!
//! UNVERIFIED (not in the bytecode I traced, or chosen here): the carve's block rules and bank profile (the mod's `RiverCarverFeature`
//! is 6700 instructions of `place` plus bank templates; only its plan, heights and materials by biome are followed), the lake level
//! (`spill - inset`), the mod's `cohesion` (taken as `0.4 + 0.6 * wetness`), how a plate's margin meets its neighbour (the owner's
//! network wins and a neighbour's fills the gaps), the plate seed, the push strength of the current, and how any of it plays on a device.
//! Added after the first port (UNVERIFIED, chosen here): a trough-shaped bed (`bed_at`), reeds and boulders on the bank, no ice on fast water
//! (`ICE_SPEED`), items carried by the current (`items.rs`).
//! NOT PORTED: `connectNetwork` (plate borders), lakes' 3-block masks,
//! waterfalls, the bend asymmetry of the bed, bank templates (logs, rocks as the mod shapes them), underwater flora, the fluid block and its
//! flow rendering, the fishing bobber in the current, the stream's sound (mc-rs has audio now, but no waterfall or stream sound), disk cache of
//! networks, village bridges and structure promises (b1.7.3 has neither). The Python reference is `tools/hydro_proto.py` (without the
//! hydraulic widths).

use crate::world::biome::Biome;
use crate::world::gen::overworld::{block, SEA_LEVEL};
use std::cmp::Reverse;
use std::collections::{BinaryHeap, HashMap};
use std::path::PathBuf;
use std::sync::{Arc, Mutex, OnceLock, RwLock};

/// Blocks between grid nodes (mod: `QualityPreset.MEDIUM`, the default, `gridSpacing` 16). A node is at world (16 gx, 16 gz); the generator's `probe` reads it there.
pub const CELL: i32 = 16;
/// mod: `WatershedSize.DEFAULT` = BLOCKS_768, `plateJitter` 0.45.
const PLATE: f64 = 768.0;
const JITTER: f64 = 0.45;
/// Cells of margin round a plate's own cell that are routed too, so a river runs on into the next plate for a while.
const HALO: i32 = 8;
/// mod, as `StreamsWorldgen.engine` sets them: `minRiverAccumulation` 6, `wetnessMultiplier` 1 x 0.8, `growDensity` 0.75, `baseWidth` 0.4, `maxWidth` 16, `widthScale` 1, `streamDepth` 0.24, `bankWidth` 2,
/// `ditchInset` 3, `aRiver` 1, `smoothingPasses` 3, `meanderStrength` 1.2, wetness cutoff / reference 0.2 / 0.7 and floor 0.1 (`StreamsSettings`).
/// ponytail: the mod's `minRiverAccumulation` is 6; here 20, a stream needs 3.3x the catchment, so there are fewer small streams and the
/// rivers lie about 1.8x farther apart (spacing goes with the square root of the catchment). Back to 6.0 for the mod's density.
const MIN_ACC: f64 = 20.0;
const WETNESS_MULT: f64 = 0.8;
const GROW_DENSITY: f64 = 0.75;
const BASE_W: f64 = 0.4;
const MAX_W: f64 = 16.0;
const WIDTH_SCALE: f64 = 1.0;
const STREAM_DEPTH: f64 = 0.24;
const BANK_WIDTH: f64 = 2.0;
/// Farthest a bank is cut from the channel's edge (blocks): the slope has to reach the real terrain, or a trench is left with a wall at
/// the end of the band (a 5 block band beside 20 blocks of hill was a 20 block cliff), and the slope's steepness (blocks up per block out).
const VALLEY: f64 = 48.0;
const BANK_SLOPE: f64 = 0.5;
const DITCH_INSET: f64 = 3.0;
const A_RIVER: f64 = 1.0;
const SMOOTHING: usize = 3;
const MEANDER: f64 = 1.2;
const WET_CUT: f64 = 0.2;
const WET_REF: f64 = 0.7;
const WET_FLOOR: f64 = 0.1;
/// mod: `StreamsSettings` default 0.5 for every hydraulic-geometry slider (width follows slope / climate / variation, channel bars,
/// delta mouths); `HydraulicGeometry.OFF` is only the core's own default, not the game's.
const HG_SLOPE: f64 = 0.5;
const HG_CLIMATE: f64 = 0.5;
const HG_VARIATION: f64 = 0.5;
const HG_DELTA: f64 = 0.5;
/// mod: `lakeMinArea` 1024 blocks^2 = 4 cells of 256; a basin's mean depth must reach 1.5 (its "film" gate).
const LAKE_MIN_CELLS: usize = 4;
const LAKE_MIN_DEPTH: f64 = 1.5;
/// Cells a river may be traced over the real terrain, past the window, to find the sea.
const TAIL_CAP: usize = 6000;
/// Blocks a second per unit of the mod's flow speed (0.25..2) before the entity's factor: UNVERIFIED. The factor is the mod's own
/// (`CurrentPush.factor` -> `StreamsSettings.playerPush` 1.2, `boatPush` 2.0, `mobPush` 1.2), so a player is pushed 1.25 x 1.2 = 1.5 as before.
const BASE_PUSH: f64 = 1.25;
/// A stream that is not the biggest branch where it joins another (or that ends in the sea) must run at least this many blocks from its
/// source, measured on the 16-block grid path (the mod's `minStreamLength` is 75; the player wants the small rivers long, so more). Chaikin and the
/// meander add about 15% to what is drawn.
const MIN_LEN: f64 = 160.0;
/// Where a stream joins a bigger river its water first runs level with the big river's surface over `LEVEL_RUN` blocks plus twice the big
/// river's half width (so the whole overlap of the two channels is one level), then rises to its own grade over `LEVEL_RAMP` blocks.
const LEVEL_RUN: f64 = 24.0;
const LEVEL_RAMP: f64 = 48.0;
const BUCKET: i32 = 16;
const MAX_PLATES: usize = 12;
/// Lake hi-res mask: the lake cells' occupancy, interpolated between cell centres, is a lake where it reaches this (the mod's `Lake` masks
/// sample every 3 blocks; this one is smooth at any block). UNVERIFIED: chosen here.
const LAKE_EDGE: f64 = 0.3;
/// Blocks a lake's floor dips below its surface at the middle, over the first block (`lakeDip`). UNVERIFIED.
const LAKE_DIP: f64 = 2.0;
/// How far a bend moves the deepest line of the bed toward the outer bank (a share of the half width at a full bend). UNVERIFIED.
const BEND_SHIFT: f64 = 0.5;
/// The disk cache's version: raise it whenever the routing or the plan changes, or an old file would be read as the new one.
const CACHE_VERSION: u32 = 1;
/// Water faster than this (the mod's flow speed, 0.25..2) does not freeze over: the ice melt of a quick stream. UNVERIFIED: chosen here.
const ICE_SPEED: f64 = 1.2;

/// The mod's `StreamsSettings`, the parts that act when a column is carved or a current read (the ones that shape a network, `MIN_ACC`,
/// `MIN_LEN`, are in its cache and stay constants).
#[derive(Clone, Debug, PartialEq)]
pub struct Settings {
    /// Rivers and lakes on (`false`: the terrain's own water only; `current` is `None`).
    pub enabled: bool,
    /// `StreamsSettings.playerPush`, `boatPush`, `mobPush` (the mod's defaults 1.2, 2.0, 1.2): what a current's strength is multiplied by.
    pub player_push: f64,
    pub boat_push: f64,
    pub mob_push: f64,
    /// Water faster than this stays open in the cold.
    pub ice_speed: f64,
    /// `streamBiomeBlacklist`: no river is cut in these biomes (a lake still is).
    pub blacklist: Vec<Biome>,
}

impl Default for Settings {
    fn default() -> Self {
        Self { enabled: true, player_push: 1.2, boat_push: 2.0, mob_push: 1.2, ice_speed: ICE_SPEED, blacklist: Vec::new() }
    }
}

/// Who a current pushes (`CurrentPush.factor`: a player, a boat, anything else).
#[derive(Clone, Copy, Debug, PartialEq, Eq)]
pub enum Push {
    Player,
    Boat,
    Mob,
}

impl Settings {
    fn factor(&self, k: Push) -> f64 {
        match k {
            Push::Player => self.player_push,
            Push::Boat => self.boat_push,
            Push::Mob => self.mob_push,
        }
    }

    /// Reads `hydro:true|false`, `playerPush:1.2`, `boatPush:2.0`, `mobPush:1.2`, `hydroIceSpeed:1.2` and `hydroBlacklist:Desert,Beach` lines (the `options.txt` shape;
    /// anything else is ignored, a bad value keeps the default). A biome is named as its variant, any case.
    pub fn parse(text: &str, all: &[Biome]) -> Self {
        let mut s = Self::default();
        for line in text.lines() {
            let Some((k, v)) = line.split_once(':') else { continue };
            let v = v.trim();
            match k.trim() {
                "hydro" => s.enabled = v != "false",
                "playerPush" => s.player_push = v.parse().unwrap_or(s.player_push).clamp(0.0, 10.0),
                "boatPush" => s.boat_push = v.parse().unwrap_or(s.boat_push).clamp(0.0, 10.0),
                "mobPush" => s.mob_push = v.parse().unwrap_or(s.mob_push).clamp(0.0, 10.0),
                "hydroIceSpeed" => s.ice_speed = v.parse().unwrap_or(s.ice_speed),
                "hydroBlacklist" => s.blacklist = v.split(',').filter_map(|n| all.iter().copied().find(|b| format!("{b:?}").eq_ignore_ascii_case(n.trim()))).collect(),
                _ => {}
            }
        }
        s
    }
}

static SETTINGS: RwLock<Option<Settings>> = RwLock::new(None);

/// The settings in force (the defaults until `configure`).
pub fn settings() -> Settings {
    SETTINGS.read().ok().and_then(|g| g.clone()).unwrap_or_default()
}

/// Sets the settings of the world being played. A river already carved stays as it is; a chunk made after this obeys.
pub fn configure(s: Settings) {
    if let Ok(mut g) = SETTINGS.write() {
        *g = Some(s);
    }
}

/// Where networks are kept between runs (`None`: nowhere). `FileNetworkStore`. A file holds one plate of one seed and world type; it does
/// not know the Natural Temperature settings, so the caller sets no directory while those are on.
static CACHE: Mutex<Option<PathBuf>> = Mutex::new(None);

pub fn cache_dir(dir: Option<PathBuf>) {
    if let Ok(mut c) = CACHE.lock() {
        *c = dir;
    }
}
/// Share of the depth kept at the channel's edge: the bed is a bar-shaped trough, deepest on the centre line (`HydraulicGeometry` bed side,
/// symmetric here: the bend asymmetry needs the side of the centre line, which `Plan` does not carry). UNVERIFIED: chosen here.
const BED_EDGE: f64 = 0.4;
const NONE: usize = usize::MAX;
const NB: [(i32, i32); 8] = [(-1, -1), (-1, 0), (-1, 1), (0, -1), (0, 1), (1, -1), (1, 0), (1, 1)];

// ---- hashing and plates: bit for bit the mod's `core.math.Hashing` and `core.plate.PlateLattice` --------------------------------

const K1: u64 = 0x9E37_79B9_7F4A_7C15;
const K2: u64 = 0xD1B5_4A32_D192_ED03;
const K3: u64 = 0xA076_1D64_78BD_642F;
const K4: u64 = 0xE703_7ED1_A0B4_28DB;

fn mix(mut x: u64) -> u64 {
    x ^= x >> 30;
    x = x.wrapping_mul(0xBF58_476D_1CE4_E5B9);
    x ^= x >> 27;
    x = x.wrapping_mul(0x94D0_49BB_1331_11EB);
    x ^ (x >> 31)
}

fn hash3(a: i64, b: i64, c: i64) -> u64 {
    let mut h = (a as u64).wrapping_mul(K1);
    h = mix(h ^ (b as u64).wrapping_mul(K2));
    h = mix(h ^ (c as u64).wrapping_mul(K3));
    mix(h)
}

fn hash4(a: i64, b: i64, c: i64, d: i64) -> u64 {
    mix(hash3(a, b, c) ^ (d as u64).wrapping_mul(K4))
}

fn to_unit(h: u64) -> f64 {
    (h >> 11) as f64 * 1.110_223_024_625_156_5e-16
}

fn unit3(a: i64, b: i64, c: i64) -> f64 {
    to_unit(hash3(a, b, c))
}

fn unit4(a: i64, b: i64, c: i64, d: i64) -> f64 {
    to_unit(hash4(a, b, c, d))
}

/// The seed point of lattice cell (i, j) (`PlateLattice.seedX` / `seedZ`).
fn plate_seed_point(seed: i64, i: i32, j: i32) -> (f64, f64) {
    let c = JITTER.max(0.0).min(0.49);
    let (i, j) = (i as i64, j as i64);
    (
        ((i as f64 + 0.5) + (unit4(seed, i, j, 1) - 0.5) * 2.0 * c) * PLATE,
        ((j as f64 + 0.5) + (unit4(seed, i, j, 2) - 0.5) * 2.0 * c) * PLATE,
    )
}

/// The plate owning a point: the nearest seed of the 3 x 3 lattice cells round it (`PlateLattice.plateAt`).
pub fn plate_at(seed: i64, x: f64, z: f64) -> (i32, i32) {
    let (ci, cj) = ((x / PLATE).floor() as i32, (z / PLATE).floor() as i32);
    let mut best = f64::MAX;
    let mut key = (ci, cj);
    for dj in -1..=1 {
        for di in -1..=1 {
            let (i, j) = (ci + di, cj + dj);
            let (sx, sz) = plate_seed_point(seed, i, j);
            let d = (sx - x) * (sx - x) + (sz - z) * (sz - z);
            if d < best || (d == best && (i, j) < key) {
                best = d;
                key = (i, j);
            }
        }
    }
    key
}

// ---- the mod's small formulas ---------------------------------------------------------------------------------------------------

/// Half width of a stream draining `acc` cells (`NetworkTracer.b(acc, cfg)`).
fn width_of(acc: f64) -> f64 {
    let area = acc * (CELL * CELL) as f64;
    MAX_W.min(BASE_W + WIDTH_SCALE * (area / 2500.0).sqrt())
}

/// How far the water surface lies under the grade (`RiverEngine.insetFor`).
fn inset_for(w: f64) -> i32 {
    (DITCH_INSET * (0.5 + 0.5 * (w / 3.0).min(1.0)) + 0.5).floor() as i32
}

/// `FlowSpeed.forReach`: slope (blocks per block, positive downhill) and the widths at the two ends of the reach.
fn flow_for_reach(slope: f64, a1: f64, a2: f64) -> f64 {
    let s = (slope.max(0.0001) / (1.0 / 7.0)).powf(1.0 / 3.0);
    let r = if a2 > 1e-6 && a1 > 1e-6 { (a2 / a1).max(0.6).min(1.8) } else { 1.0 };
    (s * r).max(0.25).min(2.0)
}

/// `FlowSpeed.at`: the reach speed times a factor for the depth.
fn flow_at_depth(speed: f64, depth: f64) -> f64 {
    let f = ((depth.max(0.5) / 2.0).powf(1.0 / 3.0)).max(0.65).min(1.35);
    (speed * f).max(0.25).min(2.0)
}

/// `HydraulicGeometry.braidFloor` / `expectedBarShare`.
fn braid_floor(depth: f64) -> f64 {
    2.2f64.min(depth.max(0.0) * 0.7)
}

fn expected_bar_share(s: f64) -> f64 {
    0.22 * s.max(0.0).min(1.0).powf(1.8) * 0.75
}

/// `NetworkTracer.a(double, double, cfg)`: keep a reach's width within the inset class of its base width, so that widening by the
/// hydraulic geometry never moves the water surface.
fn adjust_width(w: f64, base: f64) -> f64 {
    let ib = inset_for(base);
    if inset_for(w) == ib {
        return w;
    }
    if w < base {
        let (mut lo, mut hi) = (0.0, base);
        for _ in 0..24 {
            let mid = (lo + hi) * 0.5;
            if inset_for(mid) < ib {
                lo = mid;
            } else {
                hi = mid;
            }
        }
        return hi;
    }
    let (mut lo, mut hi) = (base, base.max(MAX_W));
    for _ in 0..24 {
        let mid = (lo + hi) * 0.5;
        if inset_for(mid) <= ib {
            lo = mid;
        } else {
            hi = mid;
        }
    }
    lo
}

/// Half width and flow speed of every point of a chain: `NetworkTracer.a(List, cfg, HydraulicGeometry, WetnessSampler, long, int, boolean)`.
/// Width follows the slope over +-8 blocks (steeper: narrower), the climate (wetter: wider), a slow random variation, and, on flat,
/// loose ground, braiding (shallower and wider, to carry the same flow) and delta mouths over the last 64 blocks into the sea.
/// `wet_at` is the humidity at a block; the mod's `cohesion` has no counterpart here and is taken as `0.4 + 0.6 * wetness`
/// (UNVERIFIED: dry ground is loose and braids).
fn hydraulic_widths(pts: &[Pt], seed: i64, cid: i64, to_sea: bool, wet_at: &dyn Fn(f64, f64) -> f64) -> (Vec<f64>, Vec<f64>) {
    let n = pts.len();
    let mut cum = vec![0.0; n];
    for i in 1..n {
        cum[i] = cum[i - 1] + (pts[i].x - pts[i - 1].x).hypot(pts[i].z - pts[i - 1].z);
    }
    let total = cum[n - 1];
    let tau = std::f64::consts::PI * 2.0;
    let (p1, p2) = (unit3(seed, cid, 21) * tau, unit3(seed, cid, 22) * tau);
    // Wetness and cohesion, read every 32 blocks along the chain.
    let (mut wet, mut coh) = (vec![0.5; n], vec![1.0; n]);
    let (mut w_now, mut c_now, mut next) = (0.5, 1.0, 0.0);
    for i in 0..n {
        if cum[i] >= next {
            w_now = wet_at(pts[i].x.round(), pts[i].z.round()).max(0.0).min(1.0);
            c_now = (0.4 + 0.6 * w_now).max(0.0).min(1.0);
            next = cum[i] + 32.0;
        }
        wet[i] = w_now;
        coh[i] = c_now;
    }
    let (mut width, mut speed) = (vec![0.0; n], vec![0.0; n]);
    let (mut lo, mut hi, mut flat_run) = (0usize, 0usize, 0.0);
    for i in 0..n {
        while lo < i && cum[i] - cum[lo] > 8.0 {
            lo += 1;
        }
        while hi < n - 1 && cum[hi + 1] - cum[i] <= 8.0 {
            hi += 1;
        }
        let span = cum[hi] - cum[lo];
        let slope = if span > 1e-6 { (pts[lo].y - pts[hi].y).abs() / span } else { 0.0 };
        let steep = (slope / 0.12).min(1.0);
        let mut f = 1.0;
        f *= 1.0 + HG_SLOPE * 0.3 * (1.0 - 2.0 * steep);
        f *= 1.0 + HG_SLOPE * 0.15 * (1.0 - 2.0 * coh[i]);
        f *= 1.0 + HG_CLIMATE * 0.25 * (2.0 * wet[i] - 1.0);
        f *= 1.0 + HG_VARIATION * 0.18 * (0.6 * (cum[i] * 0.045 + p1).sin() + 0.4 * (cum[i] * 0.011 + p2).sin());
        flat_run = if slope <= 0.03 { flat_run + if i > 0 { cum[i] - cum[i - 1] } else { 0.0 } } else { 0.0 };
        let loose = ((0.6 - coh[i]) / 0.6).min(1.0).max(0.0);
        let base = width_of(pts[i].acc);
        let mut bar = 0.0;
        let (mut flat_f, mut run_f) = ((1.0 - slope / 0.04).max(0.0), (flat_run / 64.0).min(1.0));
        if pts[i].y <= (SEA_LEVEL + 1) as f64 {
            flat_f = 1.0;
            run_f = 1.0;
        }
        let braid = loose * flat_f * run_f * HG_SLOPE.sqrt();
        let share = braid.sqrt();
        let depth = 2.0 * base * STREAM_DEPTH;
        let bed = depth * (1.0 - share) + braid_floor(depth) * share;
        let section = 2.0 / 3.0 + (1.0 / 3.0) * share;
        if bed > 1e-6 {
            let open = (0.2f64).max(1.0 - expected_bar_share(braid));
            bar = (depth * (2.0 / 3.0) / (bed * section * open) - 1.0).min(2.5).max(0.0);
        }
        if to_sea {
            let d = total - cum[i];
            if d < 64.0 {
                let t = 1.0 - d / 64.0;
                let smooth = t * t * (3.0 - 2.0 * t);
                bar = bar.max(HG_DELTA * 2.0 * smooth * (flat_run / 32.0).min(1.0) * loose);
            }
        }
        f *= 1.0 + bar;
        width[i] = adjust_width(BASE_W.max(MAX_W.min(base * f)), base);
        speed[i] = flow_for_reach(slope, width[i], base);
    }
    (width, speed)
}

#[derive(Clone, Copy)]
struct Pt {
    x: f64,
    z: f64,
    y: f64,
    acc: f64,
}

fn lerp_pt(a: Pt, b: Pt, t: f64) -> Pt {
    Pt { x: a.x + (b.x - a.x) * t, z: a.z + (b.z - a.z) * t, y: a.y + (b.y - a.y) * t, acc: a.acc + (b.acc - a.acc) * t }
}

/// `NetworkTracer.a(List, int)`: corner cutting, each point becomes the points at 1/4 and 3/4 of its segments.
fn chaikin(mut pts: Vec<Pt>, passes: usize) -> Vec<Pt> {
    for _ in 0..passes {
        if pts.len() < 3 {
            break;
        }
        let mut out = Vec::with_capacity(pts.len() * 2);
        out.push(pts[0]);
        for w in pts.windows(2) {
            out.push(lerp_pt(w[0], w[1], 0.25));
            out.push(lerp_pt(w[0], w[1], 0.75));
        }
        out.push(pts[pts.len() - 1]);
        pts = out;
    }
    pts
}

/// `NetworkTracer.a(List, long, int, cfg)`: the meander. `seed` is the plate's, `cid` the chain's number.
fn meander(pts: Vec<Pt>, seed: i64, cid: i64) -> Vec<Pt> {
    let n = pts.len();
    if n < 3 {
        return pts;
    }
    let amp = CELL as f64 * MEANDER;
    let tau = std::f64::consts::PI * 2.0;
    let (p1, p2, p3) = (unit3(seed, cid, 11) * tau, unit3(seed, cid, 12) * tau, unit3(seed, cid, 13) * tau);
    let mut cum = vec![0.0; n];
    for i in 1..n {
        cum[i] = cum[i - 1] + (pts[i].x - pts[i - 1].x).hypot(pts[i].z - pts[i - 1].z);
    }
    let mut out = Vec::with_capacity(n);
    out.push(pts[0]);
    for i in 1..n - 1 {
        let (a, c, b) = (pts[i - 1], pts[i], pts[i + 1]);
        let (dx, dz) = (b.x - a.x, b.z - a.z);
        let len = dx.hypot(dz);
        if len < 1e-6 {
            out.push(c);
            continue;
        }
        let (nx, nz) = (-dz / len, dx / len);
        let taper = (std::f64::consts::PI * i as f64 / (n - 1) as f64).sin();
        let flat = (1.0 - (a.y - b.y).abs() / len / 1.0).max(0.0);
        let off = amp * taper * flat * (0.5 * (cum[i] * 0.03 + p1).sin() + 0.3 * (cum[i] * 0.07 + p2).sin() + 0.2 * (cum[i] * 0.017 + p3).sin());
        out.push(Pt { x: c.x + nx * off, z: c.z + nz * off, y: c.y, acc: c.acc });
    }
    out.push(pts[n - 1]);
    out
}

/// `NetworkTracer.b(List)`: drop points closer than 0.25 to the one before (the last one replaces it).
fn dedupe(pts: Vec<Pt>) -> Vec<Pt> {
    if pts.len() < 3 {
        return pts;
    }
    let mut out: Vec<Pt> = Vec::with_capacity(pts.len());
    out.push(pts[0]);
    let last = pts.len() - 1;
    for (i, p) in pts.iter().enumerate().skip(1) {
        let q = out[out.len() - 1];
        if (p.x - q.x).hypot(p.z - q.z) < 0.25 {
            if i == last && out.len() >= 2 {
                let l = out.len() - 1;
                out[l] = *p;
            } else if i == last {
                out.push(*p);
            }
        } else {
            out.push(*p);
        }
    }
    out
}

// ---- the network of one plate ------------------------------------------------------------------------------------------------

/// A straight piece of a river, `1` upstream to `2` downstream: position, water surface (its floor is the top water block), half width,
/// flow speed and the distance still to run to the sea at each end.
#[derive(Clone, Copy)]
struct Seg {
    x1: f64,
    z1: f64,
    y1: f64,
    w1: f64,
    x2: f64,
    z2: f64,
    y2: f64,
    w2: f64,
    sp: f64,
    o1: f64,
    o2: f64,
    /// Turn at this segment, -1..1: the cross product of the unit directions before and after it (positive: to the left, x toward z).
    bend: f64,
}

/// What the carve needs to know about a column (the mod's `ColumnPlan`, the fields this port uses).
#[derive(Clone, Copy, Debug)]
pub struct Plan {
    /// Within the half width of the centre line.
    pub in_channel: bool,
    /// Top water block's y, and the bed's y.
    pub water_y: i32,
    pub bed_y: i32,
    /// 0 at the channel's edge, 1 at the end of the bank.
    pub blend: f64,
    pub distance: f64,
    pub width: f64,
    /// The water surface here (a float; `water_y` is its floor).
    pub grade: f64,
    /// Unit direction of the flow.
    pub dir: [f64; 2],
    /// `FlowSpeed.at`, 0.25..2.
    pub speed: f64,
    /// Distance still to run to the outlet.
    pub to_outlet: f64,
    /// Which side of the centre line, as a share of the half width: -1 right .. 1 left (from the flow's direction, x toward z).
    pub side: f64,
    /// The segment's `bend`.
    pub bend: f64,
}

/// The bed's y of a channel column: the full depth on the deepest line, `BED_EDGE` of it at the edge, never less than one block of water.
/// The deepest line sits on the centre line of a straight reach and moves toward the outer bank in a bend (the water of a bend digs the
/// outside; `HydraulicGeometry`'s bed side, `RiverEngine`'s bend / lateral), by `BEND_SHIFT` of the half width at a full bend.
fn bed_at(p: &Plan) -> i32 {
    // Turning left (bend > 0) the outer bank is the right one (side < 0).
    let c = -p.bend.clamp(-1.0, 1.0) * BEND_SHIFT;
    let e = ((p.side - c).abs() / (1.0 + c.abs())).clamp(0.0, 1.0);
    let full = (p.water_y - p.bed_y) as f64;
    p.water_y - (full * (1.0 - (1.0 - BED_EDGE) * e * e)).round().max(1.0) as i32
}

impl Plan {
    /// Blocks from the channel's edge: negative inside the channel, the bank's distance outside it.
    fn clearance(&self) -> f64 {
        self.distance - self.width
    }
}

/// The rivers and lakes of one plate (and the margin round it).
pub struct Network {
    segs: Vec<Seg>,
    index: HashMap<(i32, i32), Vec<u32>>,
    /// Lake of each grid cell of the window (`u32::MAX`: none), the window's origin cell and size, and the lakes' top water block.
    lake_of: Vec<u32>,
    lake_top: Vec<i32>,
    g0: (i32, i32),
    n: (usize, usize),
}

/// Little-endian reader for `Network::from_bytes`.
struct Rd<'a>(&'a [u8]);

impl Rd<'_> {
    fn take<const N: usize>(&mut self) -> Option<[u8; N]> {
        let (a, b) = self.0.split_at_checked(N)?;
        self.0 = b;
        a.try_into().ok()
    }
    fn u32(&mut self) -> Option<u32> {
        self.take().map(u32::from_le_bytes)
    }
    fn i32(&mut self) -> Option<i32> {
        self.take().map(i32::from_le_bytes)
    }
    fn f64(&mut self) -> Option<f64> {
        self.take().map(f64::from_le_bytes)
    }
}

impl Network {
    /// `CACHE_VERSION`, the lattice, then the segments, the lake cells and the lake tops, all little endian. The index is made again on load.
    fn to_bytes(&self) -> Vec<u8> {
        let mut o = Vec::with_capacity(32 + self.segs.len() * 96 + self.lake_of.len() * 4);
        o.extend(b"HYD");
        o.extend(CACHE_VERSION.to_le_bytes());
        for v in [self.g0.0, self.g0.1, self.n.0 as i32, self.n.1 as i32, self.segs.len() as i32, self.lake_top.len() as i32] {
            o.extend(v.to_le_bytes());
        }
        for s in &self.segs {
            for v in [s.x1, s.z1, s.y1, s.w1, s.x2, s.z2, s.y2, s.w2, s.sp, s.o1, s.o2, s.bend] {
                o.extend(v.to_le_bytes());
            }
        }
        for v in &self.lake_of {
            o.extend(v.to_le_bytes());
        }
        for v in &self.lake_top {
            o.extend(v.to_le_bytes());
        }
        o
    }

    /// `None` for a file of another version or one cut short (the plate is then routed again).
    fn from_bytes(b: &[u8]) -> Option<Network> {
        let mut r = Rd(b.strip_prefix(b"HYD")?);
        if r.u32()? != CACHE_VERSION {
            return None;
        }
        let (g0, n) = ((r.i32()?, r.i32()?), (r.i32()? as usize, r.i32()? as usize));
        let (ns, nl) = (r.i32()? as usize, r.i32()? as usize);
        if ns > 1 << 22 || nl > 1 << 20 || n.0 > 4096 || n.1 > 4096 {
            return None;
        }
        let mut segs = Vec::with_capacity(ns);
        for _ in 0..ns {
            let mut f = [0.0; 12];
            for v in &mut f {
                *v = r.f64()?;
            }
            segs.push(Seg { x1: f[0], z1: f[1], y1: f[2], w1: f[3], x2: f[4], z2: f[5], y2: f[6], w2: f[7], sp: f[8], o1: f[9], o2: f[10], bend: f[11] });
        }
        let lake_of = (0..n.0 * n.1).map(|_| r.u32()).collect::<Option<Vec<_>>>()?;
        let lake_top = (0..nl).map(|_| r.i32()).collect::<Option<Vec<_>>>()?;
        let index = index_of(&segs);
        Some(Network { segs, index, lake_of, lake_top, g0, n })
    }
}

/// The grid cell (node index) a block belongs to: a node owns the 12 x 12 blocks round it.
fn cell_of(v: f64) -> i32 {
    ((v + (CELL / 2) as f64) / CELL as f64).floor() as i32
}

/// How far from the channel's edge a river still shapes the ground.
fn reach(w: f64) -> f64 {
    VALLEY.max(w * BANK_WIDTH)
}

/// Distance from (x, z) to the segment and the parameter of the closest point.
fn seg_distance(s: &Seg, x: f64, z: f64) -> (f64, f64) {
    let (dx, dz) = (s.x2 - s.x1, s.z2 - s.z1);
    let len2 = dx * dx + dz * dz;
    let t = if len2 <= 1e-9 { 0.0 } else { (((x - s.x1) * dx + (z - s.z1) * dz) / len2).max(0.0).min(1.0) };
    ((x - (s.x1 + dx * t)).hypot(z - (s.z1 + dz * t)), t)
}

/// Smooth value noise of the block (x, z), -4..4, on a 3-block lattice: `salt` makes the x and the z warp differ.
fn warp(x: i32, z: i32, salt: i64) -> f64 {
    let (fx, fz) = (x as f64 / 3.0, z as f64 / 3.0);
    let (i, j) = (fx.floor(), fz.floor());
    let (tx, tz) = (fx - i, fz - j);
    let n = |a: f64, b: f64| unit4(0x1A4E, salt, a as i64, b as i64);
    let top = n(i, j) * (1.0 - tx) + n(i + 1.0, j) * tx;
    let bot = n(i, j + 1.0) * (1.0 - tx) + n(i + 1.0, j + 1.0) * tx;
    ((top * (1.0 - tz) + bot * tz) - 0.5) * 8.0
}

impl Network {
    /// The segment a point belongs to: the one with the least clearance (distance to the centre line minus the half width), so a point
    /// inside a wide channel is never taken for the bank of a narrow river that merely ends nearer to it. The mod takes the plain
    /// nearest centre line; its carver copes with the confluence, this one does not, and used to wall off the main branch.
    fn nearest(&self, x: f64, z: f64) -> Option<(usize, f64, f64)> {
        let b = ((x / BUCKET as f64).floor() as i32, (z / BUCKET as f64).floor() as i32);
        let mut best: Option<(usize, f64, f64, f64)> = None; // segment, clearance, distance, t
        for &i in self.index.get(&b)? {
            let s = &self.segs[i as usize];
            let (d, t) = seg_distance(s, x, z);
            let clear = d - (s.w1 + (s.w2 - s.w1) * t);
            if best.map_or(true, |(bi, bc, _, _)| clear < bc || (clear == bc && (i as usize) < bi)) {
                best = Some((i as usize, clear, d, t));
            }
        }
        best.map(|(i, _, d, t)| (i, t, d))
    }

    /// The lowest water surface among every segment whose channel holds the point (clearance <= 0), `None` if no channel does.
    /// `nearest` picks ONE segment, so where two channels overlap (a confluence, the inside of a bend, a braid) the column took the level
    /// of whichever centre line was nearer and the border between the two levels ran along that arbitrary diagonal: a sawtooth of water
    /// standing at different heights side by side. One level per column removes the border; the lowest wins so water is never held
    /// above a neighbouring channel's floor.
    fn channel_grade(&self, x: f64, z: f64) -> Option<f64> {
        let b = ((x / BUCKET as f64).floor() as i32, (z / BUCKET as f64).floor() as i32);
        let mut low: Option<f64> = None;
        for &i in self.index.get(&b)? {
            let s = &self.segs[i as usize];
            let (d, t) = seg_distance(s, x, z);
            if d <= s.w1 + (s.w2 - s.w1) * t {
                let g = s.y1 + (s.y2 - s.y1) * t;
                low = Some(low.map_or(g, |l: f64| l.min(g)));
            }
        }
        low
    }

    /// `RiverEngine.plan` at a point, `None` away from every river.
    pub fn plan(&self, x: f64, z: f64) -> Option<Plan> {
        let (si, t, d) = self.nearest(x, z)?;
        let s = &self.segs[si];
        let w = s.w1 + (s.w2 - s.w1) * t;
        let band = 5.0f64.max(w * BANK_WIDTH);
        if d > w + reach(w) {
            return None;
        }
        let grade = s.y1 + (s.y2 - s.y1) * t;
        let water_y = (SEA_LEVEL - 1).max(grade.floor() as i32);
        let depth = ((2.0 * w * STREAM_DEPTH + 0.5).floor() as i32).max(1);
        let len = (s.x2 - s.x1).hypot(s.z2 - s.z1).max(1e-6);
        let cross = (s.x2 - s.x1) * (z - s.z1) - (s.z2 - s.z1) * (x - s.x1);
        Some(Plan {
            in_channel: d <= w,
            water_y,
            bed_y: water_y - depth,
            blend: ((d - w) / band).max(0.0).min(1.0).powf(A_RIVER),
            distance: d,
            width: w,
            grade,
            dir: [(s.x2 - s.x1) / len, (s.z2 - s.z1) / len],
            speed: flow_at_depth(s.sp, depth as f64),
            to_outlet: s.o1 + (s.o2 - s.o1) * t,
            side: (d / w.max(1e-6)).copysign(cross).clamp(-1.0, 1.0),
            bend: s.bend,
        })
    }

    /// The lake covering the block (x, z): its top water block's y and the y of its floor at that block. The mask is the lake cells'
    /// occupancy interpolated between the cell centres (12 blocks apart), so a shore is round at any block, and the floor dips toward the
    /// middle of the lake (`LAKE_DIP`). A cell's lake wins by its weight.
    fn lake_top_at(&self, x: i32, z: i32) -> Option<(i32, i32)> {
        // The shore is warped by smooth noise of up to 4 blocks (`Lake.coverageSmooth`: the sample point is moved by `(noise - 0.5) * 2 * 4/3 *
        // spacing` before the mask is read; here the noise is value noise on a 3-block lattice, the mod's hash is not followed).
        let (px, pz) = (x as f64 + 0.5 + warp(x, z, 3), z as f64 + 0.5 + warp(x, z, 4));
        let (fx, fz) = (px / CELL as f64, pz / CELL as f64);
        let (i0, j0) = (fx.floor() as i32, fz.floor() as i32);
        let (tx, tz) = (fx - i0 as f64, fz - j0 as f64);
        let (mut occ, mut best): (f64, Option<(f64, u32)>) = (0.0, None);
        for (di, dj, w) in [(0, 0, (1.0 - tx) * (1.0 - tz)), (1, 0, tx * (1.0 - tz)), (0, 1, (1.0 - tx) * tz), (1, 1, tx * tz)] {
            let (i, j) = (i0 + di - self.g0.0, j0 + dj - self.g0.1);
            if i < 0 || j < 0 || i as usize >= self.n.0 || j as usize >= self.n.1 {
                continue;
            }
            let id = self.lake_of[i as usize * self.n.1 + j as usize];
            if id != u32::MAX {
                occ += w;
                if best.map_or(true, |(bw, _)| w > bw) {
                    best = Some((w, id));
                }
            }
        }
        if occ < LAKE_EDGE {
            return None;
        }
        let top = self.lake_top[best?.1 as usize];
        let dip = (LAKE_DIP * ((occ - LAKE_EDGE) / (1.0 - LAKE_EDGE)).clamp(0.0, 1.0)).round() as i32;
        Some((top, top - 1 - dip))
    }

    /// The current at a point in blocks per second, `None` outside a channel.
    pub fn flow_at(&self, x: f32, z: f32, k: Push) -> Option<[f32; 2]> {
        let p = self.plan(x as f64, z as f64)?;
        if p.distance > p.width + 0.5 {
            return None;
        }
        let v = p.speed * BASE_PUSH * settings().factor(k);
        Some([(p.dir[0] * v) as f32, (p.dir[1] * v) as f32])
    }
}

/// Best-first walk over the real terrain from node (gi, gj) to the first sea node, lowest pass first: the nodes (and their heights).
fn trace_tail(height: &mut dyn FnMut(i32, i32) -> f64, gi: i32, gj: i32, sea_h: f64) -> Option<Vec<(i32, i32, f64)>> {
    let y0 = height(gi, gj);
    let mut heap = BinaryHeap::new();
    let mut parent: HashMap<(i32, i32), Option<(i32, i32)>> = HashMap::new();
    let mut level: HashMap<(i32, i32), f64> = HashMap::new();
    parent.insert((gi, gj), None);
    level.insert((gi, gj), y0);
    heap.push(Reverse(((y0 * 4096.0) as i64, gi, gj)));
    let mut steps = 0;
    while let Some(Reverse((_, a, b))) = heap.pop() {
        steps += 1;
        if steps > TAIL_CAP {
            break;
        }
        let lv = level[&(a, b)];
        let ha = height(a, b);
        if ha < sea_h {
            let mut path = vec![(a, b, ha)];
            let mut c = (a, b);
            while let Some(Some(p)) = parent.get(&c) {
                c = *p;
                path.push((c.0, c.1, height(c.0, c.1)));
            }
            path.reverse();
            return Some(path);
        }
        for (da, db) in NB {
            let c = (a + da, b + db);
            if parent.contains_key(&c) {
                continue;
            }
            parent.insert(c, Some((a, b)));
            let l = height(c.0, c.1).max(lv);
            level.insert(c, l);
            heap.push(Reverse(((l * 4096.0) as i64, c.0, c.1)));
        }
    }
    None
}

/// Route one plate. `probe(gx, gz)` is the (surface height, humidity 0..1) of the node at world (12 gx, 12 gz).
fn build(seed: i64, key: (i32, i32), probe: &mut dyn FnMut(i32, i32) -> (f64, f64)) -> Network {
    let (cx, cz) = plate_seed_point(seed, key.0, key.1);
    let c = CELL as f64;
    let g0 = (((cx - PLATE) / c).floor() as i32 - HALO, ((cz - PLATE) / c).floor() as i32 - HALO);
    let g1 = (((cx + PLATE) / c).ceil() as i32 + HALO, ((cz + PLATE) / c).ceil() as i32 + HALO);
    let (nx, nz) = ((g1.0 - g0.0 + 1) as usize, (g1.1 - g0.1 + 1) as usize);
    let n = nx * nz;
    let at = |i: usize, j: usize| i * nz + j;
    let node = |k: usize| (g0.0 + (k / nz) as i32, g0.1 + (k % nz) as i32);

    // The plate's own cell, grown by the margin (separable dilation).
    let hl = HALO as usize;
    let mut own = vec![false; n];
    for i in 0..nx {
        for j in 0..nz {
            own[at(i, j)] = plate_at(seed, ((g0.0 + i as i32) * CELL) as f64, ((g0.1 + j as i32) * CELL) as f64) == key;
        }
    }
    let mut tmp = vec![false; n];
    for j in 0..nz {
        for i in 0..nx {
            if own[at(i, j)] {
                for a in i.saturating_sub(hl)..=(i + hl).min(nx - 1) {
                    tmp[at(a, j)] = true;
                }
            }
        }
    }
    let mut dom = vec![false; n];
    for i in 0..nx {
        for j in 0..nz {
            if tmp[at(i, j)] {
                for b in j.saturating_sub(hl)..=(j + hl).min(nz - 1) {
                    dom[at(i, b)] = true;
                }
            }
        }
    }
    let in_dom = |i: i32, j: i32| i >= 0 && j >= 0 && (i as usize) < nx && (j as usize) < nz && dom[at(i as usize, j as usize)];

    let mut h = vec![0.0f64; n];
    let mut wet = vec![0.0f64; n];
    for k in 0..n {
        if dom[k] {
            let (gx, gz) = node(k);
            let (a, b) = probe(gx, gz);
            h[k] = a;
            wet[k] = b;
        }
    }
    let sea_h = SEA_LEVEL as f64 - 1.0;

    // Priority flood from the sea and the window's edge: `fill` is the terrain with its depressions filled to their spill height.
    let mut fill = vec![f64::INFINITY; n];
    let mut done = vec![false; n];
    let mut order: Vec<usize> = Vec::with_capacity(n);
    let mut heap = BinaryHeap::new();
    for i in 0..nx {
        for j in 0..nz {
            let k = at(i, j);
            if !dom[k] {
                continue;
            }
            let edge = NB.iter().any(|&(a, b)| !in_dom(i as i32 + a, j as i32 + b));
            if h[k] < sea_h || edge {
                fill[k] = h[k];
                heap.push(Reverse(((h[k] * 4096.0) as i64, k)));
            }
        }
    }
    while let Some(Reverse((_, k))) = heap.pop() {
        if done[k] {
            continue;
        }
        done[k] = true;
        order.push(k);
        let (i, j) = ((k / nz) as i32, (k % nz) as i32);
        for (a, b) in NB {
            if !in_dom(i + a, j + b) {
                continue;
            }
            let m = at((i + a) as usize, (j + b) as usize);
            if fill[m].is_finite() {
                continue;
            }
            fill[m] = h[m].max(fill[k] + 0.001);
            heap.push(Reverse(((fill[m] * 4096.0) as i64, m)));
        }
    }

    // D8 receivers on the filled surface (steepest descent, a diagonal is sqrt 2 long). The sea has none.
    let mut recv = vec![NONE; n];
    for &k in &order {
        if h[k] < sea_h {
            continue;
        }
        let (i, j) = ((k / nz) as i32, (k % nz) as i32);
        let mut best = 0.0;
        for (a, b) in NB {
            if !in_dom(i + a, j + b) {
                continue;
            }
            let m = at((i + a) as usize, (j + b) as usize);
            if !fill[m].is_finite() {
                continue;
            }
            let s = (fill[k] - fill[m]) / if a != 0 && b != 0 { std::f64::consts::SQRT_2 } else { 1.0 };
            if s > best {
                best = s;
                recv[k] = m;
            }
        }
    }

    // Flow accumulation, high to low.
    let mut acc: Vec<f64> = dom.iter().map(|&d| if d { WETNESS_MULT } else { 0.0 }).collect();
    for &k in order.iter().rev() {
        if recv[k] != NONE {
            let a = acc[k];
            acc[recv[k]] += a;
        }
    }
    let thr = (MIN_ACC * GROW_DENSITY).max(1.0) * (16.0 / c) * (16.0 / c);
    let mut stream: Vec<bool> = (0..n).map(|k| dom[k] && fill[k] > SEA_LEVEL as f64 - 0.5 && h[k] >= sea_h && acc[k] >= thr).collect();

    // Dry headwaters are dropped; whatever lies downstream of a kept one stays.
    let plate_seed = hash3(seed, key.0 as i64, key.1 as i64) as i64;
    let mut has_up = vec![false; n];
    for &k in &order {
        if stream[k] && recv[k] != NONE && stream[recv[k]] {
            has_up[recv[k]] = true;
        }
    }
    let mut keep = vec![false; n];
    for &k in &order {
        if !stream[k] || has_up[k] {
            continue;
        }
        let p = ((wet[k] - WET_CUT) / (WET_REF - WET_CUT)).min(1.0).max(WET_FLOOR);
        keep[k] = unit3(plate_seed, k as i64, 71) < p;
    }
    for &k in order.iter().rev() {
        if keep[k] && recv[k] != NONE && stream[recv[k]] {
            keep[recv[k]] = true;
        }
    }
    for k in 0..n {
        stream[k] = stream[k] && keep[k];
    }

    // Separation: two stream systems (trees draining to different mouths) must not touch; the smaller yields its contact cell unless
    // one of the two is a mouth, and what that cuts off from the sea goes with it (the alive pass below).
    let mut system = vec![NONE; n];
    for &k in &order {
        if stream[k] {
            let r = recv[k];
            system[k] = if r != NONE && stream[r] { system[r] } else { k };
        }
    }
    let mut size: HashMap<usize, usize> = HashMap::new();
    for k in 0..n {
        if stream[k] {
            *size.entry(system[k]).or_insert(0) += 1;
        }
    }
    let mouth = |k: usize, stream: &[bool]| recv[k] == NONE || !stream[recv[k]];
    let mut drop = vec![false; n];
    for k in 0..n {
        if !stream[k] {
            continue;
        }
        let (i, j) = ((k / nz) as i32, (k % nz) as i32);
        for (a, b) in NB {
            if !in_dom(i + a, j + b) {
                continue;
            }
            let m = at((i + a) as usize, (j + b) as usize);
            if !stream[m] || system[m] == system[k] || mouth(k, &stream) || mouth(m, &stream) {
                continue;
            }
            if (size[&system[k]], system[k]) < (size[&system[m]], system[m]) {
                drop[k] = true;
            }
        }
    }
    for k in 0..n {
        stream[k] = stream[k] && !drop[k];
    }

    // Minimum length (the mod's `minStreamLength`): a stream from its source to where it joins a bigger branch, or to the sea, must run at least
    // `MIN_LEN` blocks, else its cells go (a stub of a few cells that empties into the big river). A stream that is the biggest branch where
    // it joins, or that leaves the window, stays. Repeated, because a dropped branch can leave the next stretch a short source of its own.
    for _ in 0..8 {
        let (mut inflow, mut main_in) = (vec![0u8; n], vec![NONE; n]);
        for k in 0..n {
            if stream[k] && recv[k] != NONE && stream[recv[k]] {
                let r = recv[k];
                inflow[r] += 1;
                if main_in[r] == NONE || (acc[k], k) > (acc[main_in[r]], main_in[r]) {
                    main_in[r] = k;
                }
            }
        }
        let mut cut = Vec::new();
        for s0 in 0..n {
            if !stream[s0] || inflow[s0] != 0 {
                continue;
            }
            let (mut path, mut len) = (vec![s0], 0.0);
            let short = loop {
                let (cur, r) = (*path.last().unwrap(), recv[*path.last().unwrap()]);
                if r == NONE {
                    break false;
                }
                let diag = (cur / nz != r / nz) && (cur % nz != r % nz);
                len += if diag { c * std::f64::consts::SQRT_2 } else { c };
                if !stream[r] {
                    break len < MIN_LEN;
                }
                if inflow[r] >= 2 {
                    break len < MIN_LEN && main_in[r] != cur;
                }
                if len >= MIN_LEN {
                    break false;
                }
                path.push(r);
            };
            if short {
                cut.extend(path);
            }
        }
        if cut.is_empty() {
            break;
        }
        for k in cut {
            stream[k] = false;
        }
    }

    // Every river must end in the sea. One that leaves the window is traced on over the real terrain; one that finds none is culled.
    let mut memo: HashMap<(i32, i32), f64> = HashMap::new();
    let mut height = |gx: i32, gz: i32| -> f64 { *memo.entry((gx, gz)).or_insert_with(|| probe(gx, gz).0) };
    let mut tails: HashMap<usize, Vec<(i32, i32, f64)>> = HashMap::new();
    for k in 0..n {
        if stream[k] && recv[k] == NONE {
            let (gx, gz) = node(k);
            if let Some(t) = trace_tail(&mut height, gx, gz, sea_h) {
                tails.insert(k, t);
            }
        }
    }
    let mut alive = vec![false; n];
    for &k in &order {
        if !stream[k] {
            continue;
        }
        let r = recv[k];
        alive[k] = if r == NONE {
            tails.contains_key(&k)
        } else if stream[r] {
            alive[r]
        } else {
            h[r] < sea_h
        };
    }
    for k in 0..n {
        stream[k] = stream[k] && alive[k];
    }

    // Lakes: basins of the filled terrain, at least 4 cells and 1.5 blocks deep on average, above the sea. They spill over their rim.
    let mut lake_of = vec![u32::MAX; n];
    let mut lake_top: Vec<i32> = Vec::new();
    let basin = |k: usize| dom[k] && h[k] >= sea_h && fill[k] - h[k] >= 0.5;
    let mut seen = vec![false; n];
    for s in 0..n {
        if seen[s] || !basin(s) || !own[s] {
            continue;
        }
        let mut comp = vec![s];
        seen[s] = true;
        let mut at_ = 0;
        while at_ < comp.len() {
            let k = comp[at_];
            at_ += 1;
            let (i, j) = ((k / nz) as i32, (k % nz) as i32);
            for (a, b) in NB {
                if !in_dom(i + a, j + b) {
                    continue;
                }
                let m = at((i + a) as usize, (j + b) as usize);
                if !seen[m] && basin(m) && (fill[m] - fill[s]).abs() <= 0.5 {
                    seen[m] = true;
                    comp.push(m);
                }
            }
        }
        let depth = comp.iter().map(|&k| fill[k] - h[k]).sum::<f64>() / comp.len() as f64;
        let level = comp.iter().map(|&k| fill[k]).fold(f64::INFINITY, f64::min);
        let top = level.floor() as i32 - 2;
        if comp.len() >= LAKE_MIN_CELLS && depth >= LAKE_MIN_DEPTH && top >= SEA_LEVEL - 1 {
            let id = lake_top.len() as u32;
            lake_top.push(top);
            for &k in &comp {
                lake_of[k] = id;
            }
        }
    }

    // Distance still to run to the outlet, per stream cell, low to high.
    let mut to_out = vec![0.0f64; n];
    for &k in &order {
        if !stream[k] {
            continue;
        }
        let r = recv[k];
        to_out[k] = if r == NONE {
            tails.get(&k).map_or(0.0, |t| (t.len() - 1) as f64 * c)
        } else if stream[r] {
            let (i, j) = (k / nz, k % nz);
            let (p, q) = (r / nz, r % nz);
            to_out[r] + if i != p && j != q { c * std::f64::consts::SQRT_2 } else { c }
        } else {
            0.0
        };
    }

    // Chains: from a headwater or a confluence to the next confluence, the sea or a lake. Stream cells inside a lake are not drawn.
    let drawn: Vec<bool> = (0..n).map(|k| stream[k] && lake_of[k] == u32::MAX).collect();
    let mut inflow = vec![0u8; n];
    for &k in &order {
        if drawn[k] && recv[k] != NONE && drawn[recv[k]] {
            inflow[recv[k]] = inflow[recv[k]].saturating_add(1);
        }
    }
    // Humidity at a block, read off the grid (0.5 where the window has none, as the mod's default).
    let wet_near = |x: f64, z: f64| -> f64 {
        let (i, j) = (cell_of(x) - g0.0, cell_of(z) - g0.1);
        if i < 0 || j < 0 || i as usize >= nx || j as usize >= nz || !dom[at(i as usize, j as usize)] {
            return 0.5;
        }
        wet[at(i as usize, j as usize)]
    };
    struct Chain {
        start: usize,
        last: usize,
        pts: Vec<Pt>,
        width: Vec<f64>,
        speed: Vec<f64>,
        arc: Vec<f64>,
        out_base: f64,
    }
    let mut chains: Vec<Chain> = Vec::new();
    let mut cid = 0i64;
    for &start in order.iter().rev() {
        if !drawn[start] || inflow[start] == 1 {
            continue;
        }
        let mut path = vec![start];
        loop {
            let r = recv[*path.last().unwrap()];
            if r == NONE {
                break;
            }
            path.push(r);
            if !drawn[r] || inflow[r] != 1 {
                break;
            }
        }
        let last = *path.last().unwrap();
        let mut pts: Vec<Pt> = Vec::with_capacity(path.len() + 8);
        let mut prev_acc = acc[start];
        for &k in &path {
            let (gx, gz) = node(k);
            let (y, a) = if drawn[k] { (fill[k], acc[k]) } else { (fill[k].max(sea_h), prev_acc) };
            prev_acc = a;
            pts.push(Pt { x: (gx * CELL) as f64, z: (gz * CELL) as f64, y, acc: a });
        }
        let mut out_base = if drawn[last] { to_out[last] } else { 0.0 };
        if let Some(t) = tails.get(&last) {
            // The tail runs on over the real terrain; the grade follows the lowest ground so far, never rising, never under the sea.
            let mut ly = pts[pts.len() - 1].y;
            for &(gx, gz, ty) in t.iter().skip(1) {
                ly = ly.min(ty.max(sea_h));
                pts.push(Pt { x: (gx * CELL) as f64, z: (gz * CELL) as f64, y: ly, acc: prev_acc });
            }
            out_base = 0.0;
        }
        // The grade never rises downstream.
        for t in 1..pts.len() {
            if pts[t].y > pts[t - 1].y {
                pts[t].y = pts[t - 1].y;
            }
        }
        let pts = dedupe(meander(chaikin(pts, SMOOTHING), plate_seed, cid));
        cid += 1;
        // Arc length to the chain's end, for the distance to the outlet; width and speed per point from the hydraulic geometry.
        let m = pts.len();
        let mut arc = vec![0.0; m];
        for i in (0..m.saturating_sub(1)).rev() {
            arc[i] = arc[i + 1] + (pts[i + 1].x - pts[i].x).hypot(pts[i + 1].z - pts[i].z);
        }
        let to_sea = tails.contains_key(&last) || (!drawn[last] && h[last] < sea_h);
        let (width, speed) = hydraulic_widths(&pts, plate_seed, cid - 1, to_sea, &wet_near);
        chains.push(Chain { start, last, pts, width, speed, arc, out_base });
    }

    // Water surface of every point: the grade less the inset, never rising downstream. Downstream chains first (the flood order puts a
    // chain's start after the start of the chain it flows into), so a stream joining a bigger river can take that river's level where they meet:
    // it runs level with it for `LEVEL_RUN` blocks (+ 2 half widths of the big river, which is its channel's whole overlap), then rises to its own
    // level over `LEVEL_RAMP`. The big river's own first stretch is held level too, so the meeting point is one flat water.
    let rank: HashMap<usize, usize> = order.iter().enumerate().map(|(i, &k)| (k, i)).collect();
    chains.sort_by_key(|ch| rank[&ch.start]);
    let mut starts: HashMap<usize, (f64, f64)> = HashMap::new(); // a confluence cell -> (water surface, half width) where the river below it begins
    let mut segs: Vec<Seg> = Vec::new();
    for ch in &chains {
        let m = ch.pts.len();
        let mut lv: Vec<f64> = (0..m).map(|i| ch.pts[i].y - inset_for(ch.width[i]) as f64).collect();
        for i in 1..m {
            lv[i] = lv[i].min(lv[i - 1]);
        }
        if inflow[ch.start] >= 2 {
            let hold = LEVEL_RUN + 2.0 * ch.width[0];
            for i in 1..m {
                if ch.arc[0] - ch.arc[i] > hold {
                    break;
                }
                lv[i] = lv[0];
            }
        }
        if let Some(&(t, wide)) = starts.get(&ch.last) {
            let (t, run) = (t.min(lv[m - 1]), LEVEL_RUN + 2.0 * wide);
            for i in 0..m {
                let f = ((ch.arc[i] - run) / LEVEL_RAMP).clamp(0.0, 1.0);
                lv[i] = t + (lv[i] - t) * f * f * (3.0 - 2.0 * f);
            }
        }
        starts.insert(ch.start, (lv[0], ch.width[0]));
        let dir = |a: Pt, b: Pt| -> (f64, f64) {
            let l = (b.x - a.x).hypot(b.z - a.z).max(1e-9);
            ((b.x - a.x) / l, (b.z - a.z) / l)
        };
        for i in 0..m.saturating_sub(1) {
            let (p, q) = (ch.pts[i], ch.pts[i + 1]);
            let d1 = dir(p, q);
            let bend = if i + 2 < m { let d2 = dir(q, ch.pts[i + 2]); (d1.0 * d2.1 - d1.1 * d2.0) * 4.0 } else { 0.0 }.clamp(-1.0, 1.0);
            segs.push(Seg {
                x1: p.x,
                z1: p.z,
                y1: lv[i],
                w1: ch.width[i],
                x2: q.x,
                z2: q.z,
                y2: lv[i + 1],
                w2: ch.width[i + 1],
                sp: (ch.speed[i] + ch.speed[i + 1]) * 0.5,
                o1: ch.out_base + ch.arc[i],
                o2: ch.out_base + ch.arc[i + 1],
                bend,
            });
        }
    }

    let index = index_of(&segs);
    Network { segs, index, lake_of, lake_top, g0, n: (nx, nz) }
}

/// Every bucket a segment's channel and bank can reach, per bucket the segments to test.
fn index_of(segs: &[Seg]) -> HashMap<(i32, i32), Vec<u32>> {
    let mut index: HashMap<(i32, i32), Vec<u32>> = HashMap::new();
    for (si, s) in segs.iter().enumerate() {
        let wmax = s.w1.max(s.w2);
        let r = wmax + reach(wmax);
        let b = BUCKET as f64;
        let (x0, x1) = (((s.x1.min(s.x2) - r) / b).floor() as i32, ((s.x1.max(s.x2) + r) / b).floor() as i32);
        let (z0, z1) = (((s.z1.min(s.z2) - r) / b).floor() as i32, ((s.z1.max(s.z2) + r) / b).floor() as i32);
        for bx in x0..=x1 {
            for bz in z0..=z1 {
                index.entry((bx, bz)).or_default().push(si as u32);
            }
        }
    }
    index
}

// ---- the carve ---------------------------------------------------------------------------------------------------------------------

/// Top solid block of a column (not water, not ice), or -1.
fn surface(col: &[u8]) -> i32 {
    (0..128).rev().find(|&y| !matches!(col[y], block::AIR | block::WATER | block::WATER_MOVING | block::ICE)).map_or(-1, |y| y as i32)
}

/// Blocks of a bank, after the mod's `bank_style` files by biome (river / plains: clay and gravel, desert and beach: sand, mountains:
/// gravel at the line; the mod's mud is dirt here, b1.7.3 has none).
struct Style {
    bed: &'static [u8],
    line: &'static [u8],
    top: &'static [u8],
    fill: u8,
}

fn style(b: Biome) -> Style {
    use block::*;
    match b {
        Biome::Desert | Biome::Beach | Biome::Ocean => Style { bed: &[SAND], line: &[SAND], top: &[SAND], fill: SAND },
        Biome::Savanna | Biome::Shrubland | Biome::Chaparral => Style { bed: &[SAND, GRAVEL, SAND], line: &[SAND, DIRT], top: &[GRASS], fill: DIRT },
        Biome::Mountains => Style { bed: &[GRAVEL, STONE], line: &[GRAVEL], top: &[STONE], fill: STONE },
        Biome::Swamp | Biome::Marsh => Style { bed: &[DIRT, CLAY], line: &[DIRT, GRASS], top: &[GRASS], fill: DIRT },
        _ => Style { bed: &[CLAY, GRAVEL], line: &[GRAVEL], top: &[GRASS], fill: DIRT },
    }
}

/// One of `list`, by `h` in 0..1 (patches of the same block come from `h` being the same over a few blocks).
fn pick(list: &[u8], h: f64) -> u8 {
    list[((h * list.len() as f64) as usize).min(list.len() - 1)]
}

/// The networks that can reach one chunk (its plate's first), made on demand.
pub struct Region {
    nets: Vec<Arc<Network>>,
}

impl Region {
    /// The plan of a column over every network that reaches the chunk: the one with the least clearance, as `Network::nearest` does inside
    /// one network (a channel, clearance <= 0, always beats a bank). It used to be the first network with any plan, so the bank of a river
    /// of the plate's own network (often a lower one) cut or skipped the channel of a higher river from a neighbouring plate: the upper
    /// water was left standing on a cliff, or the river was gone. Ties go to the earlier network (the plate's own).
    fn plan_at(&self, x: f64, z: f64) -> Option<Plan> {
        let mut p = self.nets.iter().filter_map(|n| n.plan(x, z)).reduce(|a, b| if b.clearance() < a.clearance() { b } else { a })?;
        if p.in_channel {
            // One water surface per channel column, over every segment and every network that overlaps it, so rivers that meet (or bend
            // back on themselves, or cross a plate border) merge into one flat water instead of a patchwork of levels.
            if let Some(g) = self.nets.iter().filter_map(|n| n.channel_grade(x, z)).reduce(f64::min) {
                if g < p.grade {
                    let depth = p.water_y - p.bed_y;
                    p.grade = g;
                    p.water_y = (SEA_LEVEL - 1).max(g.floor() as i32);
                    p.bed_y = p.water_y - depth;
                }
            }
        }
        Some(p)
    }

    /// What the World Preview paints at block (x, z): 1 where `carve` would cut a river's channel, 2 where it would fill a lake, 0 for dry
    /// land. `ground` is the land's height there (`carve`'s `surface`) and `biome` the column's. The same rules as `carve`, read at one
    /// column: off when `Settings::enabled` is off, a lake only over ground from 40 up to its top, the channel not in a blacklisted biome,
    /// not under 5 blocks, not above 120, and not where the ground lies more than 6 blocks under the channel's bed (the river is not
    /// cut into a pit).
    pub fn water_at(&self, x: i32, z: i32, ground: i32, biome: Biome) -> u8 {
        let set = settings();
        if !set.enabled {
            return 0;
        }
        let plan = self.plan_at(f64::from(x) + 0.5, f64::from(z) + 0.5);
        if !plan.is_some_and(|p| p.in_channel) {
            if let Some((top, _floor)) = self.nets.iter().find_map(|n| n.lake_top_at(x, z)) {
                return if (40..top).contains(&ground) { 2 } else { 0 };
            }
        }
        let Some(p) = plan.filter(|p| p.in_channel) else { return 0 };
        if set.blacklist.contains(&biome) || ground < 5 || p.bed_y < 5 || p.water_y > 120 || ground + 6 < bed_at(&p) {
            return 0;
        }
        1
    }

    /// Cut this region's rivers and fill its lakes into chunk (cx, cz), `(x << 11) | (z << 7) | y`, after terrain and surface.
    /// `biomes` and `temps` are the chunk's, `x * 16 + z`; ice caps the water where it is cold.
    pub fn carve(&self, cx: i32, cz: i32, blocks: &mut [u8], biomes: &[Biome], temps: &[f64]) {
        let set = settings();
        if !set.enabled {
            return;
        }
        for x in 0..16usize {
            for z in 0..16usize {
                let (wx, wz) = (cx * 16 + x as i32, cz * 16 + z as i32);
                let col = (x << 11) | (z << 7);
                let (st, cold) = (style(biomes[x * 16 + z]), temps[x * 16 + z] < 0.5);
                let pat = unit3(0x5EED, wx.div_euclid(3) as i64, wz.div_euclid(3) as i64);
                let s = surface(&blocks[col..col + 128]);
                let (px, pz) = (wx as f64 + 0.5, wz as f64 + 0.5);
                let plan = self.plan_at(px, pz);
                if !plan.is_some_and(|p| p.in_channel) {
                    if let Some((top, floor)) = self.nets.iter().find_map(|n| n.lake_top_at(wx, wz)) {
                        // Water fills what lies under the lake's surface, down to the dipped floor; the shore is the terrain's own.
                        if (40..top).contains(&s) {
                            let low = s.min(floor);
                            for y in low + 1..=top {
                                blocks[col + y as usize] = if cold && y == top { block::ICE } else { block::WATER };
                            }
                            blocks[col + low as usize] = pick(st.bed, pat);
                        }
                        continue;
                    }
                }
                let Some(p) = plan else { continue };
                if set.blacklist.contains(&biomes[x * 16 + z]) {
                    continue;
                }
                let (ws, bed) = (p.water_y, p.bed_y);
                if s < 5 || bed < 5 || ws > 120 {
                    continue;
                }
                // Water already stands at the river's level (the sea, a lake, a bigger river): a mouth opens into it. The bank's berm used
                // to treat such a column as low ground and fill it with dirt and gravel, a dam across every mouth.
                if matches!(blocks[col + ws as usize], block::WATER | block::WATER_MOVING | block::ICE) {
                    continue;
                }
                if p.in_channel {
                    // Channel: water up to the surface, whatever stood above it removed, a bed under it (built up where the ground is lower).
                    let bed = bed_at(&p);
                    let icy = cold && p.speed < set.ice_speed;
                    if s + 6 < bed {
                        continue;
                    }
                    for y in bed + 1..=s.max(ws).min(126) {
                        blocks[col + y as usize] = if y <= ws {
                            if icy && y == ws { block::ICE } else { block::WATER }
                        } else {
                            block::AIR
                        };
                    }
                    let bm = pick(st.bed, pat);
                    for y in (if s < bed { s + 1 } else { bed - 1 }).max(1)..=bed {
                        blocks[col + y as usize] = bm;
                    }
                } else {
                    // Bank: a slope up from the waterline cut into higher ground, a berm on lower ground so the water is held.
                    let k = p.distance - p.width;
                    let band = 5.0f64.max(p.width * BANK_WIDTH);
                    // The slope rises BANK_SLOPE a block from the waterline (the first block level with the water cell, its top 1/9 over the
                    // water) and, over the outer half of the reach, eases into the terrain's own height, so a hill beside the river is a
                    // valley side and never a wall at the end of the band.
                    let t = ws as f64 + k * BANK_SLOPE;
                    let u = ((k / reach(p.width) - 0.5) * 2.0).clamp(0.0, 1.0);
                    let target = ((t + (s as f64 - t) * u * u * (3.0 - 2.0 * u)).floor() as i32).min(120);
                    let top = pick(if k < 1.5 { st.line } else { st.top }, pat);
                    if s > ws {
                        if s > target {
                            for y in target + 1..=s {
                                blocks[col + y as usize] = block::AIR;
                            }
                            blocks[col + target as usize] = top;
                            for y in (target - 2).max(1)..target {
                                if blocks[col + y as usize] == block::STONE {
                                    blocks[col + y as usize] = st.fill;
                                }
                            }
                        }
                    } else if k <= 2.5 && ws - s <= 5 {
                        // A levee on low ground so the water is held: level with the water at the channel's edge, a block lower farther out,
                        // never the extra block over the water it used to be.
                        let btop = ws - (k * 0.75) as i32;
                        if btop > s {
                            for y in s + 1..btop {
                                blocks[col + y as usize] = st.fill;
                            }
                            blocks[col + btop as usize] = top;
                        }
                    }
                    // Flowers along the water, thinning out with the distance.
                    let ns = surface(&blocks[col..col + 128]);
                    let r = unit3(0x71, wx as i64, wz as i64);
                    let f = 1.0 - k / band;
                    if ns > 0 && ns < 126 && blocks[col + ns as usize] == block::GRASS && blocks[col + ns as usize + 1] == block::AIR && r < 0.12 * f {
                        blocks[col + ns as usize + 1] = if r < 0.06 * f { block::FLOWER_Y } else { block::FLOWER_R };
                    }
                    // Bank features (`BankFeature`, cut down): reeds where the ground is level with the water (sugar cane needs water beside
                    // its base), and now and then a boulder of cobblestone and moss. UNVERIFIED: the mod's templates are not followed.
                    let r2 = unit3(0x72, wx as i64, wz as i64);
                    let base = if ns > 0 && ns < 120 { blocks[col + ns as usize] } else { 0 };
                    if ns == ws && k < 2.0 && matches!(base, block::GRASS | block::DIRT | block::SAND) && blocks[col + ns as usize + 1] == block::AIR && r2 < 0.12 {
                        for y in ns + 1..=ns + 1 + (r2 * 25.0) as i32 % 3 {
                            blocks[col + y as usize] = block::REED;
                        }
                    } else if ns > ws && ns < 120 && k > 1.5 && k < band && base == block::GRASS && blocks[col + ns as usize + 1] == block::AIR && r2 > 0.995 {
                        blocks[col + ns as usize + 1] = if r2 > 0.998 { block::MOSSY } else { block::COBBLE };
                    }
                }
            }
        }
    }
}

// ---- the world's networks ----------------------------------------------------------------------------------------------------------

/// The plates of one world, made on demand and shared by every thread that generates for it.
#[derive(Default)]
pub struct Hydro {
    seed: i64,
    plates: Mutex<Vec<((i32, i32), Arc<OnceLock<Arc<Network>>>)>>,
    /// Whether this world's plates go through the disk cache (`cache_dir`). The World Preview's do not: its seed, type and Natural
    /// Temperature settings are not those of the world whose folder `cache_dir` points at, and a file does not know them.
    disk: bool,
}

impl Hydro {
    /// The (one) `Hydro` of the world with this seed and type.
    pub fn of(seed: i64, tectonic: bool) -> Arc<Hydro> {
        static WORLDS: OnceLock<Mutex<HashMap<(i64, bool), Arc<Hydro>>>> = OnceLock::new();
        let mut m = WORLDS.get_or_init(Default::default).lock().unwrap_or_else(|e| e.into_inner());
        m.entry((seed, tectonic)).or_insert_with(|| Arc::new(Hydro { seed, plates: Mutex::default(), disk: true })).clone()
    }

    /// The `Hydro` the World Preview reads: shared by the preview's workers like `of`, but apart from the game's worlds and never read from
    /// or written to the disk cache.
    pub fn of_preview(seed: i64, tectonic: bool) -> Arc<Hydro> {
        static PREVIEWS: OnceLock<Mutex<HashMap<(i64, bool), Arc<Hydro>>>> = OnceLock::new();
        let mut m = PREVIEWS.get_or_init(Default::default).lock().unwrap_or_else(|e| e.into_inner());
        m.entry((seed, tectonic)).or_insert_with(|| Arc::new(Hydro { seed, plates: Mutex::default(), disk: false })).clone()
    }

    /// The network of a plate, routed with `probe` if nobody has yet. A second thread that needs the same plate waits for the first.
    /// ponytail: past `MAX_PLATES` the oldest plate is dropped and made again if it is needed.
    fn network(&self, key: (i32, i32), probe: &mut dyn FnMut(i32, i32) -> (f64, f64)) -> Arc<Network> {
        let slot = {
            let mut p = self.plates.lock().unwrap_or_else(|e| e.into_inner());
            if let Some((_, s)) = p.iter().find(|(k, _)| *k == key) {
                s.clone()
            } else {
                if p.len() >= MAX_PLATES {
                    p.remove(0);
                }
                let s = Arc::new(OnceLock::new());
                p.push((key, s.clone()));
                s
            }
        };
        slot.get_or_init(|| {
            let file = self.disk.then(|| CACHE.lock().ok().and_then(|c| c.clone())).flatten().map(|d| d.join(format!("{:x}_{}_{}.net", self.seed, key.0, key.1)));
            if let Some(n) = file.as_ref().and_then(|f| std::fs::read(f).ok()).and_then(|b| Network::from_bytes(&b)) {
                return Arc::new(n);
            }
            let n = build(self.seed, key, probe);
            if let Some(f) = file {
                let _ = f.parent().map(std::fs::create_dir_all);
                let _ = std::fs::write(f, n.to_bytes());
            }
            Arc::new(n)
        }).clone()
    }

    /// The networks that reach chunk (cx, cz): its plate's and the neighbours' whose margin covers it.
    pub fn region(&self, cx: i32, cz: i32, probe: &mut dyn FnMut(i32, i32) -> (f64, f64)) -> Arc<Region> {
        let (mx, mz) = (cx as f64 * 16.0 + 8.0, cz as f64 * 16.0 + 8.0);
        let r = (HALO * CELL) as f64 + 8.0;
        let mut keys = vec![plate_at(self.seed, mx, mz)];
        for dx in [-r, 0.0, r] {
            for dz in [-r, 0.0, r] {
                let k = plate_at(self.seed, mx + dx, mz + dz);
                if !keys.contains(&k) {
                    keys.push(k);
                }
            }
        }
        let nets = keys.into_iter().map(|k| self.network(k, probe)).collect();
        Arc::new(Region { nets })
    }

    /// The network at a block, if it has been made.
    fn peek(&self, x: f32, z: f32) -> Option<Arc<Network>> {
        let key = plate_at(self.seed, x as f64, z as f64);
        let p = self.plates.lock().ok()?;
        p.iter().find(|(k, _)| *k == key)?.1.get().cloned()
    }
}

/// The world whose currents `current` reads (the one being played).
static WATCHED: Mutex<Option<Arc<Hydro>>> = Mutex::new(None);

/// Play this world's currents (`None`: none, as in the Nether). A no-op in tests, so a test's world does not push another's entities.
pub fn watch(h: Option<Arc<Hydro>>) {
    #[cfg(not(test))]
    {
        *WATCHED.lock().unwrap_or_else(|e| e.into_inner()) = h;
    }
    #[cfg(test)]
    {
        let _ = h;
    }
}

/// The current at a point in blocks per second, `None` away from a river or on a plate not made yet.
pub fn current(x: f32, z: f32) -> Option<[f32; 2]> {
    current_for(x, z, Push::Player)
}

/// `current` for a kind of pusher (a boat is pushed harder than a player or a mob).
pub fn current_for(x: f32, z: f32, k: Push) -> Option<[f32; 2]> {
    if !settings().enabled {
        return None;
    }
    let h = WATCHED.lock().ok()?.clone()?;
    h.peek(x, z)?.flow_at(x, z, k)
}

#[cfg(test)]
mod tests {
    use super::*;

    const SEED: i64 = 0xCAFE_BABE;

    /// Land rising east and north from a sea far in the west (x < -1700, past the plate's window, so its rivers are traced on to it), a little rough: (surface, humidity) of node (gx, gz).
    fn land(gx: i32, gz: i32) -> (f64, f64) {
        (66.0 + 0.0667 * (gx + 60) as f64 + 0.01 * gz.abs() as f64 + 2.0 * ((gx as f64) * 0.31).sin() * ((gz as f64) * 0.27).cos(), 0.9)
    }

    /// Hash, seed points and plates are the mod's own, checked against its `Hashing` and `PlateLattice` classes (run on a JVM).
    #[test]
    fn lattice_matches_the_mod() {
        assert_eq!(hash3(1, 2, 3) as i64, -7970969774787746530);
        assert_eq!(hash4(12345, -7, 99, 1) as i64, -9084196385740661577);
        assert_eq!(unit4(SEED, -3, 5, 2), 0.5797157391788732);
        let (x, z) = plate_seed_point(SEED, 0, -1);
        assert!((x - 349.3443395521448).abs() < 1e-9 && (z + 407.4152264968453).abs() < 1e-9, "{x} {z}");
        assert!((plate_seed_point(SEED, -2, 3).0 + 1115.6033249305112).abs() < 1e-9);
        for (p, k) in [((0.0, 0.0), (0, -1)), ((1500.0, -900.0), (2, -1)), ((-3000.0, 2500.0), (-5, 3)), ((100.0, 2047.0), (-1, 2))] {
            assert_eq!(plate_at(SEED, p.0, p.1), k);
        }
    }

    /// Width, inset and speed follow the mod's formulas.
    #[test]
    fn formulas_match_the_mod() {
        assert!((width_of(4.0) - (0.4 + (4.0f64 * (CELL * CELL) as f64 / 2500.0).sqrt())).abs() < 1e-12);
        assert_eq!(width_of(1.0e9), 16.0);
        assert_eq!((inset_for(0.9), inset_for(3.0), inset_for(9.0)), (2, 3, 3));
        assert!((width_of(0.0) - BASE_W).abs() < 1e-12);
        // The hydraulic width stays in the base width's inset class and between the mod's bounds; a delta mouth widens.
        let line: Vec<Pt> = (0..60).map(|i| Pt { x: i as f64 * 4.0, z: 0.0, y: 63.5, acc: 80.0 }).collect();
        let (w, sp) = hydraulic_widths(&line, SEED, 1, true, &|_, _| 0.1);
        assert!(w.iter().all(|&v| v >= BASE_W && v <= MAX_W) && sp.iter().all(|&v| (0.25..=2.0).contains(&v)));
        assert!(w[58] > w[0], "a delta mouth widens the last 64 blocks: {} vs {}", w[58], w[0]);
        let s = flow_for_reach(1.0 / 7.0, 2.0, 2.0);
        assert!((s - 1.0).abs() < 1e-12, "{s}");
        assert_eq!(flow_for_reach(0.0, 1.0, 1.0), 0.25);
        assert_eq!(flow_for_reach(5.0, 1.0, 1.0), 2.0);
    }

    /// The meander keeps both ends and the number of points; a flat chain leaves the line, a steep one does not.
    #[test]
    fn meander_keeps_the_ends() {
        let line = |dy: f64| (0..40).map(|i| Pt { x: i as f64 * 12.0, z: 0.0, y: 80.0 - dy * i as f64, acc: 10.0 }).collect::<Vec<_>>();
        let flat = meander(line(0.0), SEED, 3);
        assert_eq!(flat.len(), 40);
        assert_eq!((flat[0].z, flat[39].z), (0.0, 0.0));
        assert!(flat.iter().any(|p| p.z.abs() > 1.0));
        assert!(meander(line(20.0), SEED, 3).iter().all(|p| p.z.abs() < 1e-9));
    }

    /// Every river ends in the sea or runs into another river, none stops on land, and the grade never rises downstream.
    #[test]
    fn every_river_drains_to_the_sea() {
        let key = plate_at(SEED, 0.0, 0.0);
        let net = build(SEED, key, &mut land);
        assert!(net.segs.len() > 40, "{} segments", net.segs.len());
        let starts: Vec<(i64, i64)> = net.segs.iter().map(|s| ((s.x1 * 1000.0).round() as i64, (s.z1 * 1000.0).round() as i64)).collect();
        let sea_h = SEA_LEVEL as f64 - 1.0;
        let mut mouths = 0;
        for s in &net.segs {
            assert!(s.y2 <= s.y1 + 1e-9, "water rises: {} -> {}", s.y1, s.y2);
            assert!(s.w1 >= BASE_W && s.w2 <= MAX_W + 1e-9);
            let end = ((s.x2 * 1000.0).round() as i64, (s.z2 * 1000.0).round() as i64);
            if !starts.contains(&end) {
                // A mouth: its node is under the sea, or in a lake (which spills on in a river of its own).
                mouths += 1;
                let (gx, gz) = ((s.x2 / CELL as f64).round() as i32, (s.z2 / CELL as f64).round() as i32);
                // A mouth past the grid's edge is in no lake (the index would be negative).
                let (ix, iz) = (gx - net.g0.0, gz - net.g0.1);
                let on_grid = ix >= 0 && iz >= 0 && (ix as usize) < net.n.0 && (iz as usize) < net.n.1;
                let in_lake = on_grid && net.lake_of[ix as usize * net.n.1 + iz as usize] != u32::MAX;
                let h = land(gx, gz).0;
                assert!(in_lake || h < sea_h + 0.5, "river ends on land at ({}, {}), ground {h}", s.x2, s.z2);
            }
        }
        assert!(mouths > 0);
    }

    /// The carve puts water in a chunk with a river, holds it up, and leaves most chunks alone.
    #[test]
    fn carved_water_rests_on_ground() {
        let h = Hydro { seed: SEED, plates: Mutex::default(), disk: false };
        let (mut water, mut touched, mut chunks) = (0, 0, 0);
        let (sx, sz) = plate_seed_point(SEED, plate_at(SEED, 0.0, 0.0).0, plate_at(SEED, 0.0, 0.0).1);
        for cx in (sx / 16.0) as i32 - 12..(sx / 16.0) as i32 + 12 {
            for cz in (sz / 16.0) as i32 - 12..(sz / 16.0) as i32 + 12 {
                let reg = h.region(cx, cz, &mut land);
                let mut b = vec![block::AIR; 16 * 16 * 128];
                for i in 0..256 {
                    let top = land((cx * 16 + (i / 16) as i32).div_euclid(CELL), (cz * 16 + (i % 16) as i32).div_euclid(CELL)).0 as usize;
                    for y in 0..top.min(120) {
                        b[(i / 16) << 11 | (i % 16) << 7 | y] = block::STONE;
                    }
                }
                let before = b.clone();
                reg.carve(cx, cz, &mut b, &vec![Biome::Plains; 256], &vec![0.8; 256]);
                chunks += 1;
                if b != before {
                    touched += 1;
                }
                for i in 0..256usize {
                    for y in 1..127usize {
                        let at = (i / 16) << 11 | (i % 16) << 7 | y;
                        if b[at] == block::WATER {
                            water += 1;
                            assert!(b[at - 1] != block::AIR, "water over air at chunk ({cx}, {cz}), y {y}");
                        }
                    }
                }
            }
        }
        assert!(water > 100 && touched > 0 && touched < chunks, "{water} water blocks, {touched} of {chunks} chunks touched");
    }

    /// A hand-made network: segments (x1, z1, x2, z2, half width) at grade 64.5 (the water lies `inset_for(w)` under it).
    fn made(list: &[(f64, f64, f64, f64, f64)]) -> Network {
        made_at(64.5, list)
    }

    /// `made` at another grade.
    fn made_at(grade: f64, list: &[(f64, f64, f64, f64, f64)]) -> Network {
        let segs: Vec<Seg> = list
            .iter()
            .map(|&(x1, z1, x2, z2, w)| {
                let y = grade - inset_for(w) as f64;
                Seg { x1, z1, y1: y, w1: w, x2, z2, y2: y, w2: w, sp: 1.0, o1: 0.0, o2: 0.0, bend: 0.0 }
            })
            .collect();
        Network { index: index_of(&segs), segs, lake_of: Vec::new(), lake_top: Vec::new(), g0: (0, 0), n: (0, 0) }
    }

    /// The World Preview paints water where `carve` puts it: on flat ground, on ground far under the bed, and on a hill.
    #[test]
    fn the_preview_water_matches_the_carve() {
        let reg = Region { nets: vec![Arc::new(made(&[(0.0, 8.0, 15.0, 8.0, 2.0)]))] };
        for top in [69usize, 66, 30] {
            let mut b = vec![block::AIR; 16 * 16 * 128];
            for x in 0..16usize {
                for z in 0..16usize {
                    for y in 0..=top {
                        b[(x << 11) | (z << 7) | y] = block::STONE;
                    }
                }
            }
            reg.carve(0, 0, &mut b, &vec![Biome::Plains; 256], &vec![0.8; 256]);
            let mut wet = 0;
            for x in 0..16usize {
                for z in 0..16usize {
                    let carved = b[(x << 11) | (z << 7)..][..128].iter().any(|&c| c == block::WATER);
                    let seen = reg.water_at(x as i32, z as i32, top as i32, Biome::Plains) == 1;
                    assert_eq!(carved, seen, "ground {top}: column ({x}, {z}) carved {carved}, preview {seen}");
                    wet += usize::from(carved);
                }
            }
            assert_eq!(wet > 0, top >= 60, "ground {top}: {wet} wet columns");
        }
    }

    /// A river on a terrace is not overwritten by a lower river whose bank reaches it: the lower network comes first, as the plate's own
    /// does. Its bank used to take the upper channel's columns (cut or skipped), leaving no river or water standing on a cliff.
    /// Two channels that overlap (a stream joining a river, at different levels) are one water: every column of the overlap has the same
    /// surface whichever centre line is nearer, so there is no diagonal border of steps between them.
    #[test]
    fn overlapping_channels_share_one_water_level() {
        let big = made_at(70.5, &[(-40.0, 0.0, 60.0, 0.0, 5.0)]);
        let small = made_at(73.5, &[(10.0, -30.0, 10.0, 3.0, 2.0)]);
        let reg = Region { nets: vec![Arc::new(big), Arc::new(small)] };
        let low = reg.plan_at(40.0, 0.5).unwrap().water_y; // the big river alone
        let mut seen = 0;
        for xi in 0..20 {
            for zi in 0..16 {
                let (x, z) = (4.0 + xi as f64 * 0.7, -3.5 + zi as f64 * 0.5);
                let p = reg.plan_at(x, z).unwrap();
                let in_small = (x - 10.0).abs() <= 2.0 && z >= -30.0 && z <= 3.0;
                if p.in_channel && in_small && z.abs() <= 5.0 {
                    assert_eq!(p.water_y, low, "overlap column ({x}, {z}) stands at {} not {low}", p.water_y);
                    seen += 1;
                }
            }
        }
        assert!(seen > 20, "the channels never overlapped in the test ({seen})");
    }

    #[test]
    fn a_lower_river_does_not_overwrite_a_higher_one() {
        let lower = Arc::new(made_at(66.5, &[(-40.0, 0.0, 60.0, 0.0, 4.0)]));
        let upper = Arc::new(made_at(75.5, &[(-40.0, 10.0, 60.0, 10.0, 1.5)]));
        let reg = Region { nets: vec![lower, upper] };
        let mut b = vec![block::AIR; 16 * 16 * 128];
        for x in 0..16usize {
            for z in 0..16usize {
                for y in 0..70 {
                    b[(x << 11) | (z << 7) | y] = block::STONE;
                }
            }
        }
        reg.carve(0, 0, &mut b, &vec![Biome::Plains; 256], &vec![0.8; 256]);
        let at = |x: usize, z: usize, y: usize| b[(x << 11) | (z << 7) | y];
        // The upper river's surface: grade 75.5, half width 1.5 -> inset 2 -> water block 73, on channel columns z 8..=11.
        for x in 1..15usize {
            for z in 8..=11usize {
                assert_eq!(at(x, z, 73), block::WATER, "the upper river is gone at ({x}, {z})");
            }
        }
        // And it is held: no water of that level has air beside it.
        for x in 1..15usize {
            for z in 1..15usize {
                if at(x, z, 73) == block::WATER {
                    for (nx, nz) in [(x - 1, z), (x + 1, z), (x, z - 1), (x, z + 1)] {
                        assert_ne!(at(nx, nz, 73), block::AIR, "water at ({x}, {z}) stands beside air at ({nx}, {nz})");
                    }
                }
            }
        }
    }

    /// A river through high ground has a valley side, not a wall: over a plateau 36 blocks above the water, the surface never steps by
    /// more than 3 blocks between neighbours across the river (the old 5 block band left a cliff of ~30 at its end), the water is held,
    /// and the plateau itself is untouched past the reach.
    #[test]
    fn a_river_in_high_ground_has_sloped_banks_not_walls() {
        let reg = Region { nets: vec![Arc::new(made(&[(-200.0, 0.0, 200.0, 0.0, 2.0)]))] };
        let (x0, z0, nx, nz) = (-16i32, -80i32, 2usize, 10usize); // chunks cx -1..1, cz -5..5
        let mut h = vec![0i32; (nx * 16) * (nz * 16)];
        for cx in 0..nx {
            for cz in 0..nz {
                let mut b = vec![block::AIR; 16 * 16 * 128];
                for i in 0..256usize {
                    for y in 0..100 {
                        b[((i / 16) << 11) | ((i % 16) << 7) | y] = block::STONE;
                    }
                }
                reg.carve(x0 / 16 + cx as i32, z0 / 16 + cz as i32, &mut b, &vec![Biome::Plains; 256], &vec![0.8; 256]);
                for x in 0..16usize {
                    for z in 0..16usize {
                        let col = (x << 11) | (z << 7);
                        let top = (0..128usize).rev().find(|&y| b[col + y] != block::AIR).unwrap() as i32;
                        h[(cx * 16 + x) * (nz * 16) + cz * 16 + z] = top;
                    }
                }
            }
        }
        let at = |x: usize, z: usize| h[x * (nz * 16) + z];
        let mut worst = 0;
        for x in 0..nx * 16 {
            for z in 1..nz * 16 {
                worst = worst.max((at(x, z) - at(x, z - 1)).abs());
            }
            // Water at the river (z 0), plateau far away (z -80 and 79 are 78+ blocks out).
            assert!(at(x, 80) <= 66, "no river at x {x}: {}", at(x, 80));
            assert_eq!(at(x, 0), 99, "the plateau is cut at the far edge");
            assert_eq!(at(x, nz * 16 - 1), 99, "the plateau is cut at the far edge");
        }
        assert!(worst <= 3, "a wall of {worst} blocks beside the river");
    }

    /// A river opens into the sea: water already there is left alone (the bank's berm used to dam the mouth with dirt and gravel), and
    /// the river itself is cut on the land.
    #[test]
    fn the_mouth_opens_into_the_sea() {
        let reg = Region { nets: vec![Arc::new(made(&[(-30.0, 8.0, 12.0, 8.0, 1.5)]))] };
        let mut b = vec![block::AIR; 16 * 16 * 128];
        for x in 0..16usize {
            for z in 0..16usize {
                let top = if x < 8 { 66 } else { 60 };
                for y in 0..top {
                    b[(x << 11) | (z << 7) | y] = block::STONE;
                }
                if x >= 8 {
                    for y in top..64 {
                        b[(x << 11) | (z << 7) | y] = block::WATER;
                    }
                }
            }
        }
        let before = b.clone();
        reg.carve(0, 0, &mut b, &vec![Biome::Plains; 256], &vec![0.8; 256]);
        for x in 8..16usize {
            for z in 0..16usize {
                for y in 0..128usize {
                    let i = (x << 11) | (z << 7) | y;
                    assert_eq!(b[i], before[i], "the sea changed at ({x}, {z}, {y})");
                }
            }
        }
        assert_eq!(b[(3 << 11) | (8 << 7) | 63], block::WATER, "the river is cut on the land");
    }

    /// A point inside a wide channel belongs to it even where a narrow tributary's end lies nearer.
    #[test]
    fn a_wide_channel_wins_at_a_confluence() {
        let net = made(&[(-50.0, 0.0, 50.0, 0.0, 6.0), (10.0, -30.0, 10.0, 0.0, 1.5)]);
        let p = net.plan(12.0, -4.0).expect("a river here");
        assert!(p.in_channel && (p.width - 6.0).abs() < 1e-9, "{p:?}");
    }

    /// A river's current points downstream (west here) at a speed in the mod's range.
    fn plan_at_side(side: f64, bend: f64) -> Plan {
        Plan { in_channel: true, water_y: 62, bed_y: 56, blend: 0.0, distance: side.abs() * 6.0, width: 6.0, grade: 62.0, dir: [1.0, 0.0], speed: 1.0, to_outlet: 0.0, side, bend }
    }

    #[test]
    fn the_bed_is_deepest_on_the_centre_line() {
        assert_eq!(bed_at(&plan_at_side(0.0, 0.0)), 56);
        assert!(bed_at(&plan_at_side(0.5, 0.0)) > 56 && bed_at(&plan_at_side(1.0, 0.0)) > bed_at(&plan_at_side(0.5, 0.0)));
        assert_eq!(bed_at(&plan_at_side(1.0, 0.0)), 60); // 0.4 of 6 = 2.4 -> 2
        assert_eq!(bed_at(&Plan { bed_y: 61, ..plan_at_side(1.0, 0.0) }), 61); // never under one block of water
    }

    #[test]
    fn a_bend_digs_its_outer_bank() {
        // Turning left, the outer bank is the right one (side < 0): deeper there than on the inner side, and the straight reach is even.
        assert_eq!(bed_at(&plan_at_side(0.5, 0.0)), bed_at(&plan_at_side(-0.5, 0.0)));
        assert!(bed_at(&plan_at_side(-0.5, 1.0)) < bed_at(&plan_at_side(0.5, 1.0)));
        assert!(bed_at(&plan_at_side(0.5, -1.0)) < bed_at(&plan_at_side(-0.5, -1.0)));
    }

    #[test]
    fn the_cache_round_trips_and_refuses_a_cut_file() {
        let net = made(&[(0.0, 0.0, 100.0, 0.0, 2.0), (100.0, 0.0, 200.0, 40.0, 2.0)]);
        let b = net.to_bytes();
        let back = Network::from_bytes(&b).expect("reads back");
        assert_eq!(back.segs.len(), net.segs.len());
        assert_eq!(back.plan(50.0, 1.0).map(|p| p.water_y), net.plan(50.0, 1.0).map(|p| p.water_y));
        assert!(Network::from_bytes(&b[..b.len() - 1]).is_none());
        assert!(Network::from_bytes(b"HYD\xff\0\0\0").is_none());
    }

    #[test]
    fn a_boat_is_pushed_harder_than_a_player() {
        let s = Settings::default();
        assert!(s.factor(Push::Boat) > s.factor(Push::Player) && s.factor(Push::Mob) == s.factor(Push::Player));
        assert!((BASE_PUSH * s.factor(Push::Player) - 1.5).abs() < 1e-9);
    }

    #[test]
    fn the_lake_warp_stays_inside_four_blocks() {
        for x in -40..40 {
            for z in -40..40 {
                assert!(warp(x, z, 3).abs() <= 4.0 && warp(x, z, 4).abs() <= 4.0);
            }
        }
    }

    #[test]
    fn settings_read_their_lines() {
        let s = Settings::parse("hydro:false\nplayerPush:2.5\nhydroBlacklist:desert, Beach, nope\nx", &[Biome::Desert, Biome::Beach, Biome::Plains]);
        assert!(!s.enabled && s.player_push == 2.5 && s.boat_push == 2.0 && s.blacklist == vec![Biome::Desert, Biome::Beach]);
        assert_eq!(Settings::parse("playerPush:abc", &[]), Settings::default());
    }

    #[test]
    fn the_current_follows_the_river() {
        let net = build(SEED, plate_at(SEED, 0.0, 0.0), &mut land);
        let s = net.segs.iter().find(|s| s.x2 - s.x1 < -1.0 && s.w1 > 1.0).copied().expect("a river going west");
        let c = net.flow_at(((s.x1 + s.x2) / 2.0) as f32, ((s.z1 + s.z2) / 2.0) as f32).expect("water at the middle of a piece");
        assert!(c[0] < 0.0 && (0.3..=3.1).contains(&c[0].hypot(c[1])), "{c:?}");
    }

    /// Rougher land than `land`, so the plate has real branching: (surface, humidity) of node (gx, gz).
    fn rugged(gx: i32, gz: i32) -> (f64, f64) {
        let (x, z) = (gx as f64, gz as f64);
        (66.0 + 0.0667 * (gx + 60) as f64 + 0.01 * z.abs() + 7.0 * (x * 0.09 + 1.0).sin() * (z * 0.07).cos() + 4.0 * (x * 0.17).sin() * (z * 0.19 + 2.0).cos() + 2.0 * (x * 0.31).sin() * (z * 0.27).cos(), 0.7)
    }

    /// Steep, rough land: streams fall fast, so a tributary's own water stands well over the river it joins.
    fn steep(gx: i32, gz: i32) -> (f64, f64) {
        let (x, z) = (gx as f64, gz as f64);
        (66.0 + 0.35 * (gx + 60) as f64 + 0.02 * z.abs() + 9.0 * (x * 0.13 + 1.0).sin() * (z * 0.11).cos() + 3.0 * (x * 0.29).sin() * (z * 0.23 + 2.0).cos(), 0.7)
    }

    fn at_key(x: f64, z: f64) -> (i64, i64) {
        ((x * 1000.0).round() as i64, (z * 1000.0).round() as i64)
    }

    /// Where a stream joins a bigger river, its water runs at the big river's level for the last `LEVEL_RUN` blocks (the surface of the
    /// river below the confluence is the one both are made level with), on both test lands.
    #[test]
    fn a_stream_joins_a_bigger_river_at_the_same_level() {
        for land_fn in [land as fn(i32, i32) -> (f64, f64), rugged, steep] {
            let net = build(SEED, plate_at(SEED, 0.0, 0.0), &mut |a, b| land_fn(a, b));
            let (mut ends, mut starts): (HashMap<(i64, i64), Vec<usize>>, HashMap<(i64, i64), usize>) = (HashMap::new(), HashMap::new());
            for (i, s) in net.segs.iter().enumerate() {
                ends.entry(at_key(s.x2, s.z2)).or_default().push(i);
                starts.insert(at_key(s.x1, s.z1), i);
            }
            let mut joins = 0;
            for (k, e) in &ends {
                let (Some(&d), true) = (starts.get(k), e.len() >= 2) else { continue };
                let level = |y: f64| (SEA_LEVEL - 1).max(y.floor() as i32);
                let down = level(net.segs[d].y1);
                for &i in e {
                    joins += 1;
                    let (mut j, mut run) = (i, 0.0);
                    loop {
                        let s = &net.segs[j];
                        assert_eq!(level(s.y2), down, "stream ends {run:.0} blocks from its confluence at another level than the river below it");
                        run += (s.x2 - s.x1).hypot(s.z2 - s.z1);
                        if run > LEVEL_RUN || j == 0 || at_key(net.segs[j - 1].x2, net.segs[j - 1].z2) != at_key(s.x1, s.z1) {
                            break;
                        }
                        j -= 1;
                    }
                }
            }
            assert!(joins > 0, "no confluence to test");
        }
    }

    /// A stream does not run into a bigger one (or the sea) after a stub of a few cells: every source's stretch to its first confluence is
    /// long (`MIN_LEN` on the grid path; smoothing shortens a little). Only on lands where no short source is the biggest branch of its
    /// confluence (that one stays: it is where the river below begins, `steep` has such a case).
    #[test]
    fn small_streams_are_long() {
        for land_fn in [land as fn(i32, i32) -> (f64, f64), rugged] {
            let net = build(SEED, plate_at(SEED, 0.0, 0.0), &mut |a, b| land_fn(a, b));
            let (mut ends, mut starts): (HashMap<(i64, i64), usize>, HashMap<(i64, i64), usize>) = (HashMap::new(), HashMap::new());
            for (i, s) in net.segs.iter().enumerate() {
                *ends.entry(at_key(s.x2, s.z2)).or_default() += 1;
                starts.insert(at_key(s.x1, s.z1), i);
            }
            let mut sources = 0;
            for (k, &i) in &starts {
                if ends.contains_key(k) {
                    continue;
                }
                sources += 1;
                let (mut j, mut len) = (i, 0.0);
                loop {
                    let s = &net.segs[j];
                    len += (s.x2 - s.x1).hypot(s.z2 - s.z1);
                    let e = at_key(s.x2, s.z2);
                    match starts.get(&e) {
                        Some(&n) if ends[&e] < 2 => j = n,
                        _ => break,
                    }
                }
                assert!(len >= MIN_LEN * 0.8, "a source runs only {len:.0} blocks to its confluence");
            }
            assert!(sources > 0);
        }
    }
}
