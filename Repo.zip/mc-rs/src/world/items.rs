//! Items, block drops and the hotbar inventory. Ports of `ItemStack`, `InventoryPlayer.addItemStackToInventory`,
//! `Block.dropBlockAsItem` with the `idDropped` / `quantityDropped` / `damageDropped` overrides, and `EntityItem`
//! (20 Hz motion, 5 min lifetime, pickup after 10 ticks). Item ids follow Java: below 256 = the block with that
//! id, from 256 up = `Item.shiftedIndex` (256 + n).

use glam::Vec3;

use crate::render::atlas;
use crate::world::chunk::collision;
use crate::world::craft;
use crate::world::dig::TICK;
use crate::world::gen::noise::JavaRandom;
use crate::world::physics::{self, BlockQuery};

#[derive(Clone, Copy, PartialEq, Eq, Debug)]
pub struct ItemStack {
    pub id: u16,
    pub count: u8,
    /// `ItemStack.itemDamage`: the dye colour (lapis = 4) or, on a tool, the uses spent so far.
    pub damage: u16,
}

/// Empty bowl and mushroom stew (`Item.bowlEmpty` 25, `Item.bowlSoup` 26, shifted by 256).
pub const BOWL: u16 = 281;
pub const STEW: u16 = 282;

/// `ItemFood.healAmount` of every `ItemFood` in `Item` (ids shifted by 256).
pub fn heal_amount(id: u16) -> Option<i32> {
    match id {
        STEW => Some(10),
        260 => Some(4),  // apple
        297 => Some(5),  // bread
        319 => Some(3),  // raw porkchop
        320 => Some(8),  // cooked porkchop
        322 => Some(42), // golden apple
        349 => Some(2),  // raw fish
        350 => Some(5),  // cooked fish
        357 => Some(1),  // cookie
        _ => None,
    }
}

/// `ItemStack.getItemName` translated (`StringTranslate`): the `en_US.lang` name; wool, dye, slabs and charcoal by
/// damage (`ItemCloth`, `ItemDye`, `ItemSlab`, `ItemCoal`). `None` for an id the original gives no name.
pub fn name(s: ItemStack) -> Option<&'static str> {
    use crate::world::names::*;
    match s.id {
        35 => Some(WOOL[(s.damage & 15) as usize]),
        43 | 44 => Some(SLAB[(s.damage & 3) as usize]),
        263 if s.damage == 1 => Some(CHARCOAL),
        351 => Some(DYE[(s.damage & 15) as usize]),
        id => NAMES.binary_search_by_key(&id, |e| e.0).ok().map(|i| NAMES[i].1).or_else(|| crate::world::combat::catalog::name(id)),
    }
}

/// `Item.maxStackSize`: tools, armor, buckets, sign, doors, bed, stew and map 1, snowball and egg 16, cookie 8, everything else 64.
pub fn max_stack(id: u16) -> u8 {
    match id {
        261 | 282 | 323 | 324 | 330 | 333 | 346 | 354 | 355 | 325..=327 | 335 | 328 | 342 | 343 | 358 => 1,
        332 | 344 => 16,
        2256 | 2257 => 1, // records
        357 => 8,
        _ if craft::tool(id).is_some() || craft::armor(id).is_some() || crate::world::combat::catalog::get(id).is_some() => 1,
        _ => 64,
    }
}

/// Atlas tile (block id) whose flat colour stands in for an item until M14 has item sprites. A block item's
/// damage is its metadata (wool colour, wood species): see `stack_tile` for the tile that shows it.
// UNVERIFIED: colours only, picked from the existing atlas.
pub fn tile(id: u16) -> u8 {
    match id {
        0..=255 => id as u8,
        263 => 7,        // coal
        264 => 56,       // diamond
        287 | 330 => 4,  // string, iron door
        295 => 31,       // seeds
        296 | 338 => 83, // wheat, sugar cane
        318 => 13,       // flint
        323 | 324 => 5,  // sign, wooden door
        331 | 356 => 73, // redstone, repeater
        332 => 78,       // snowball
        337 => 82,       // clay
        336 => 38,       // brick
        348 => 14,       // glowstone dust
        351 => 21,       // lapis dye
        355 => 38,       // bed
        265 => 42,       // iron ingot
        266 => 41,       // gold ingot
        280 => 17,       // stick
        359 => 42,       // shears
        325 | 326 | 327 => [42, 9, 11][id as usize - 325], // buckets: iron, water, lava
        335 => 35,       // milk
        281 | 261 | 346 => 5, // bowl, bow, rod
        262 => 13,       // arrow (flint)
        297 => 12,       // bread (sand)
        349 | 350 => 9,  // fish
        282 => 39,       // mushroom stew
        // Tools: the material's colour (wood, stone, iron, diamond, gold); the HUD draws the head shape on top.
        _ => craft::tool(id).map(|(_, m)| m).or(craft::armor(id).map(|a| a.1)).or(crate::world::combat::catalog::get(id).map(|c| c.1)).map_or(255, |m| [5, 4, 42, 57, 41][m]),
    }
}

/// The atlas tile of a stack: a block item's damage is the metadata its block gets when placed (`placed_meta`), so
/// red wool and birch logs show their own colour; any other item (a tool's damage is its wear) keeps `tile`.
pub fn stack_tile(s: ItemStack) -> u16 {
    if s.id < 256 { atlas::tile_of(s.id as u8, s.damage as u8) } else { tile(s.id) as u16 }
}

/// `Item.getPlacedBlockMetadata`: the metadata a block item sets when it is placed. Sapling, log, wool and slab
/// (`ItemSapling`, `ItemLog`, `ItemCloth`, `ItemSlab`) pass their damage on, leaves add bit 8 (`ItemLeaves`: placed
/// by the player, never decays), every other block item places metadata 0.
pub fn placed_meta(s: ItemStack) -> u8 {
    match s.id {
        6 | 17 | 35 | 44 => s.damage as u8,
        18 => s.damage as u8 | 8,
        _ => 0,
    }
}

/// The metadata a block item is DRAWN with (`RenderBlocks.renderBlockOnInventory`): the one it places, except a piston and a sticky piston,
/// which are drawn as metadata 1 (the face up, so the inventory shows the piston's front and not its back plate).
pub fn icon_meta(s: ItemStack) -> u8 {
    if matches!(s.id, 29 | 33) { 1 } else { placed_meta(s) }
}

/// The blocks the inventory draws as their flat tile and not a cube: plants, the cobweb, torches, rails, doors, the bed ...
pub fn flat_icon(id: u8) -> bool {
    crate::world::chunk::cross_shape(id).is_some() || matches!(id, 26 | 27 | 28 | 30 | 50 | 51 | 55 | 63 | 64 | 65 | 66 | 68 | 69 | 71 | 75 | 76 | 77 | 90 | 92 | 93 | 94 | 96)
}

/// How high the cube of a block item is drawn, of its width: a slab is half of it, a pressure plate a quarter (a plate is 1/16 in the world;
/// the inventory shows it as a flat tile you can tell from a block), every other cube all of it.
pub fn icon_height(id: u16) -> f32 {
    match id {
        44 => 0.5,
        70 | 72 => 0.25,
        _ => 1.0,
    }
}

// ---- Block.idDropped / quantityDropped / damageDropped ----
// ponytail: blocks whose drop reads metadata and that nothing can make or place yet (stairs)
// are missing; their drops go in with the blocks. Slabs are here because the drop is two lines.

fn quantity(b: u8, r: &mut JavaRandom) -> i32 {
    match b {
        // fluids, glass, TNT, bookshelf, fire, spawner, snow layer, ice, portal, cake
        8..=11 | 20 | 46 | 47 | 51 | 52 | 78 | 79 | 90 | 92 => 0,
        43 => 2,                                  // double slab: two single slabs
        18 => (r.next_int_bound(20) == 0) as i32, // leaves: a sapling one time in 20
        21 => 4 + r.next_int_bound(5),            // lapis
        73 | 74 => 4 + r.next_int_bound(2),       // redstone ore
        80 | 82 => 4,                             // snow block, clay
        89 => 2 + r.next_int_bound(3),            // glowstone
        _ => 1,
    }
}

/// `idDropped`; 0 or -1 = nothing.
fn id_dropped(b: u8, r: &mut JavaRandom) -> i32 {
    match b {
        1 => 4,                                                       // stone -> cobblestone
        2 | 60 => 3,                                                  // grass, farmland -> dirt
        13 => if r.next_int_bound(10) == 0 { 318 } else { 13 },       // gravel -> flint 1 in 10
        16 => 263,                                                    // coal ore -> coal
        21 => 351,                                                    // lapis ore -> dye
        56 => 264,                                                    // diamond ore -> diamond
        18 => 6,                                                      // leaves -> sapling
        43 | 44 => 44,                                                // slabs -> single slab
        30 => 287,                                                    // web -> string
        31 => if r.next_int_bound(8) == 0 { 295 } else { -1 },        // tall grass -> seeds 1 in 8
        32 | 34 | 36 => -1,                                                     // dead bush
        52 => 0,                                                      // spawner
        55 | 73 | 74 => 331,                                          // redstone
        61 | 62 => 61,                                                // lit furnace -> furnace
        63 | 68 => 323,                                               // signs
        26 => 355,                                                    // bed
        64 => 324,                                                    // wooden door
        71 => 330,                                                    // iron door
        75 | 76 => 76,                                                // redstone torches
        93 | 94 => 356,                                               // repeaters
        80 => 332,                                                    // snow block -> snowball
        82 => 337,                                                    // clay
        83 => 338,                                                    // reeds
        89 => 348,                                                    // glowstone -> dust
        _ => b as i32,
    }
}

/// `Block.damageDropped(metadata)`: the damage of the dropped stack (of the item that is dropped, whatever it is).
fn damage_dropped(b: u8, meta: u8) -> u16 {
    match b {
        6 | 18 => (meta & 3) as u16,      // sapling, leaves: the species (leaves lose the placed bit)
        17 | 35 | 43 | 44 => meta as u16, // log, wool, slabs: as placed
        21 => 4,                          // lapis ore -> blue dye
        _ => 0,
    }
}

// ---- Inventory ----

/// `InventoryPlayer.mainInventory`: 0..9 is the hotbar, 9..36 the rest (shown on the inventory screen); 36..40 is
/// `armorInventory` (index 3 = helmet .. 0 = boots), so a `Slot` index past `MAIN` is an armor slot as in `ContainerPlayer`.
pub const MAIN: usize = 36;
pub const SLOTS: usize = MAIN + 4;

/// Starts empty, like a new survival player.
pub struct Inventory {
    pub slots: [Option<ItemStack>; SLOTS],
    /// For the stats (`StatList.objectUseStats` / `objectBreakStats`), which the frame drains: ids used (a block set down, a tool worn by
    /// a use; food is not) and ids broken (tools and armour).
    pub used: Vec<u16>,
    pub broke: Vec<u16>,
}

// Not derived: `Default` stops at 32-element arrays.
impl Default for Inventory {
    fn default() -> Self {
        Self { slots: [None; SLOTS], used: Vec::new(), broke: Vec::new() }
    }
}

impl Inventory {
    /// `addItemStackToInventory`: top up the first matching non-full stack, else take the first empty slot,
    /// until `s` is empty or nothing fits. `s.count` is what is left; true if any of it was taken.
    pub fn add(&mut self, s: &mut ItemStack) -> bool {
        let start = s.count;
        while s.count > 0 {
            let fits = |o: &Option<ItemStack>| o.is_some_and(|t| t.id == s.id && t.damage == s.damage && t.count < max_stack(t.id));
            let main = &self.slots[..MAIN];
            let Some(i) = main.iter().position(fits).or_else(|| main.iter().position(Option::is_none)) else { break };
            let t = self.slots[i].get_or_insert(ItemStack { count: 0, ..*s });
            let n = s.count.min(max_stack(s.id) - t.count);
            t.count += n;
            s.count -= n;
        }
        s.count < start
    }

    /// `ItemStack.damageItem`: wear a tool in `slot` by `n` uses; past its durability it breaks (a tool stack is 1).
    /// Anything that is not a tool is left alone.
    pub fn damage(&mut self, slot: usize, n: u16) {
        let Some(s) = &mut self.slots[slot] else { return };
        let Some(max) = craft::max_damage(s.id) else { return };
        s.damage += n;
        if slot < MAIN {
            self.used.push(s.id);
        }
        if s.damage > max {
            self.broke.push(s.id);
            self.slots[slot] = None;
        }
    }

    /// `ItemFood.onItemRightClick` on the item in `slot`: uses up one and returns the health it heals; a stew leaves its
    /// empty bowl (`ItemSoup`). Eating at full health still uses the item up, like the original. `None` if not food.
    pub fn eat(&mut self, slot: usize) -> Option<i32> {
        let id = self.slots[slot]?.id;
        let heal = heal_amount(id)?;
        self.consume(slot);
        if id == STEW {
            self.slots[slot] = Some(ItemStack { id: BOWL, count: 1, damage: 0 });
        }
        Some(heal)
    }

    /// Is there an `id` in the main slots (what `take_one` would take)?
    pub fn has(&self, id: u16) -> bool {
        self.slots[..MAIN].iter().any(|s| s.is_some_and(|s| s.id == id))
    }

    /// `InventoryPlayer.consumeInventoryItem`: use up one `id` from the first stack that has it (main slots only).
    pub fn take_one(&mut self, id: u16) -> bool {
        let Some(i) = self.slots[..MAIN].iter().position(|s| s.is_some_and(|s| s.id == id)) else { return false };
        self.consume(i);
        true
    }

    /// Use up one item of `slot` (`--stackSize`); an emptied stack becomes `None`.
    pub fn consume(&mut self, slot: usize) {
        if let Some(s) = &mut self.slots[slot] {
            if heal_amount(s.id).is_none() {
                self.used.push(s.id);
            }
            s.count -= 1;
            if s.count == 0 {
                self.slots[slot] = None;
            }
        }
    }
}

// ---- Dropped items (EntityItem) ----

/// Half the 0.25 x 0.25 box of `EntityItem.setSize`.
const R: f32 = 0.125;
/// Entities kept at once; the oldest goes first. Vanilla has no cap.
pub const MAX_ITEMS: usize = 256;
/// `EntityItem` lives 6000 ticks (5 minutes). A death pile (NOT b1.7.3, Immersive Pack worlds, UNVERIFIED) lives 4 times that.
pub const LIFE: u32 = 6000;
pub const PILE_LIFE: u32 = 4 * LIFE;
/// The save keeps `age` in a `u32`; this high bit marks a pile item, so the level file's layout does not change (an age is far below it).
const PILE_BIT: u32 = 1 << 31;

pub struct ItemEntity {
    /// Centre of the box, and where it was one tick ago (the renderer interpolates).
    pub pos: Vec3,
    pub prev: Vec3,
    /// Blocks per tick.
    vel: Vec3,
    pub stack: ItemStack,
    pub age: u32,
    /// Part of a death pile: it lasts `PILE_LIFE`, and the map marks where the pile lies (`Drops::pile_at`).
    pub pile: bool,
    delay: u32,
    on_ground: bool,
    /// `EntityItem.health`: 5; a blast takes the damage off it (`attackEntityFrom`). Not saved: an item comes back with 5.
    health: i32,
}

/// Anything an item cannot pass: a block with a collision box (not air, plants, torches, water or lava). An unloaded chunk reads as
/// solid (`ChunkManager::block`). ponytail: the whole cell, not the box (an item rests on a slab at the cell's top).
fn solid(get: BlockQuery<'_>, c: [i32; 3]) -> bool {
    get(c[0], c[1], c[2]).is_some_and(|b| collision(b).is_some())
}

fn cell(p: Vec3) -> [i32; 3] {
    [p.x.floor() as i32, p.y.floor() as i32, p.z.floor() as i32]
}

impl ItemEntity {
    /// `Explosion.doExplosionA` on a dropped item: `attackEntityFrom(damage)` takes it off the 5 health (true: it is gone) and `motion += direction x
    /// impact` (`push`, blocks a tick) throws it.
    pub fn blast(&mut self, push: Vec3, dmg: i32) -> bool {
        self.health -= dmg;
        self.vel += push;
        if push.y > 0.0 {
            self.on_ground = false;
        }
        self.health <= 0
    }

    /// The age as the level file keeps it: the pile mark rides in the top bit, and `resting` takes it out again.
    pub fn saved_age(&self) -> u32 {
        self.age | if self.pile { PILE_BIT } else { 0 }
    }

    /// A saved item coming back: at rest, ready to be picked up (it settles on the next tick).
    pub fn resting(pos: Vec3, stack: ItemStack, age: u32) -> Self {
        Self { pos, prev: pos, vel: Vec3::ZERO, stack, age: age & !PILE_BIT, pile: age & PILE_BIT != 0, delay: 0, on_ground: false, health: 5 }
    }

    /// One 20 Hz `EntityItem.onUpdate`; false once it is gone (lava, 5 min old, fell out of the world).
    // ponytail: collision tests the box centre line, not all 8 corners, so an item can overhang an edge by
    // up to 0.125; movement per tick is capped under one block so it cannot tunnel. Upgrade: sweep the AABB.
    // Lava deletes the item at once; vanilla bounces it for a few ticks first.
    fn step(&mut self, get: BlockQuery<'_>) -> bool {
        self.delay = self.delay.saturating_sub(1);
        self.prev = self.pos;
        let here = cell(self.pos);
        if matches!(get(here[0], here[1], here[2]), Some(10 | 11)) {
            return false;
        }
        self.vel.y -= 0.04;
        // pushOutOfBlocks (simplified): a block placed on top of it lifts it onto the block.
        if solid(get, here) {
            self.pos.y = here[1] as f32 + 1.0 + R;
        }
        self.on_ground = false;
        for a in [1usize, 0, 2] {
            let d = self.vel[a].clamp(-0.99, 0.99);
            if d == 0.0 {
                continue;
            }
            let mut p = self.pos;
            p[a] += d;
            let mut probe = p;
            probe[a] += R.copysign(d);
            let c = cell(probe);
            if solid(get, c) {
                // Flush against the face, 1e-3 clear of it so the probe sits in the free cell next tick.
                p[a] = if d > 0.0 { c[a] as f32 - R - 1e-3 } else { c[a] as f32 + 1.0 + R + 1e-3 };
                self.on_ground |= a == 1 && d < 0.0;
                self.vel[a] = 0.0;
            }
            self.pos = p;
        }
        // 0.1 * 0.1 * 58.8 = 0.6 * 0.98 = 0.588; ice has slipperiness 0.98.
        let mut f = 0.98;
        if self.on_ground {
            let below = cell(self.pos - Vec3::new(0.0, R + 0.01, 0.0));
            f = if get(below[0], below[1], below[2]) == Some(79) { 0.98 * 0.98 } else { 0.588 };
        }
        self.vel.x *= f;
        self.vel.z *= f;
        self.vel.y *= 0.98;
        self.age += 1;
        self.age < if self.pile { PILE_LIFE } else { LIFE } && self.pos.y > -64.0
    }

    /// `onCollideWithPlayer`: the player's box grown by 1.0 in x and z (not y) touches this item, after the
    /// 10 tick delay. Takes what fits; true when the whole stack is gone. `player` is the centre of its box.
    /// `pops` gets this item's place when something went into the bag (`random.pop` in the Java; a player's arrow is one of these too).
    fn picked_up(&mut self, player: Vec3, inv: &mut Inventory, pops: &mut Vec<Vec3>, got: &mut Vec<u16>) -> bool {
        let d = (self.pos - player).abs();
        let reach = physics::HALF.x + 1.0 + R;
        if self.delay > 0 || d.x >= reach || d.z >= reach || d.y >= physics::HALF.y + R {
            return false;
        }
        if inv.add(&mut self.stack) {
            pops.push(self.pos);
            got.push(self.stack.id);
        }
        self.stack.count == 0
    }
}

pub struct Drops {
    pub items: Vec<ItemEntity>,
    /// `World.rand`: drawn in the same order as the Java drop code.
    rng: JavaRandom,
    /// Stands in for the unseeded `Math.random()` the `EntityItem` constructor uses for its first motion.
    fx: JavaRandom,
    /// Time left over from the last 20 Hz tick.
    acc: f32,
    /// Where items went into the bag since `lib.rs` last took them: each is a `random.pop`.
    pub pops: Vec<Vec3>,
    /// The ids that went into the bag with them (`onItemPickup`: the log and the leather achievements).
    pub got: Vec<u16>,
}

impl Drops {
    pub fn new(seed: i64) -> Self {
        Self { items: Vec::new(), rng: JavaRandom::new(seed), fx: JavaRandom::new(seed ^ 0xF00D), acc: 0.0, pops: Vec::new(), got: Vec::new() }
    }

    /// How far into the next tick we are, 0..1, for drawing between `prev` and `pos`.
    pub fn alpha(&self) -> f32 {
        (self.acc / TICK).min(1.0)
    }

    /// `Block.dropBlockAsItem` for block `block` just broken at `cell`: `quantityDropped` entities of one item
    /// each, placed at random in the middle 0.7 of the cell, hopping up and sideways, 10 ticks before pickup.
    /// The caller has already checked `dig::can_harvest` (vanilla `sendBlockRemoved`: no harvest, no drop).
    /// `meta` is the block's metadata from before it was cleared (`ChunkManager::meta`): it decides the damage.
    pub fn spawn_block(&mut self, block: u8, meta: u8, cell: (i32, i32, i32)) {
        if matches!(block, 26 | 64 | 71) && meta & 8 != 0 {
            return; // BlockBed / BlockDoor.idDropped: the second half drops nothing
        }
        if block == 59 {
            // `BlockCrops`: `idDropped` is wheat only at meta 7 (the `super` call still draws its float), then 3 tries at seeds, each `nextInt(15) <= meta`.
            self.rng.next_float();
            if meta == 7 {
                self.spawn_stack(ItemStack { id: 296, count: 1, damage: 0 }, cell);
            }
            for _ in 0..3 {
                if self.rng.next_int_bound(15) <= meta as i32 {
                    self.spawn_stack(ItemStack { id: 295, count: 1, damage: 0 }, cell);
                }
            }
            return;
        }
        for _ in 0..quantity(block, &mut self.rng) {
            self.rng.next_float(); // `nextFloat() <= chance` with chance 1.0: always true, but it draws
            let id = id_dropped(block, &mut self.rng);
            if id <= 0 {
                continue;
            }
            self.spawn_stack(ItemStack { id: id as u16, count: 1, damage: damage_dropped(block, meta) }, cell);
        }
    }

    /// NOT b1.7.3 (`biomeRules`, `biomelife::leaf_odds`): a broken leaf gives its sapling 1 time in `sapling` and, if it is oak, an apple
    /// (260) 1 time in `apple`. The drops are the same stacks `spawn_block` makes.
    pub fn spawn_leaf(&mut self, meta: u8, cell: (i32, i32, i32), (sapling, apple): (i32, i32)) {
        if self.rng.next_int_bound(sapling) == 0 {
            self.spawn_stack(ItemStack { id: 6, count: 1, damage: damage_dropped(18, meta) }, cell);
        }
        if meta & 3 == 0 && self.rng.next_int_bound(apple) == 0 {
            self.spawn_stack(ItemStack { id: 260, count: 1, damage: 0 }, cell);
        }
    }

    /// `Block.dropBlockAsItem_do`: one stack placed at random in the middle 0.7 of `cell`, hopping up and sideways.
    /// Shears on leaves use it directly to drop the leaves block itself (`BlockLeaves.harvestBlock`).
    pub fn spawn_stack(&mut self, stack: ItemStack, (x, y, z): (i32, i32, i32)) {
        let mut offset = || ((self.rng.next_float() * 0.7) as f64 + (1.0f32 - 0.7) as f64 * 0.5) as f32;
        let pos = Vec3::new(x as f32 + offset(), y as f32 + offset(), z as f32 + offset());
        let mut jitter = || (self.fx.next_double() * 0.2f32 as f64 - 0.1f32 as f64) as f32;
        let vel = Vec3::new(jitter(), 0.2, jitter());
        self.push(ItemEntity { pos, prev: pos, vel, stack, age: 0, pile: false, delay: 10, on_ground: false, health: 5 });
    }

    /// `EntityPlayer.dropPlayerItem`: thrown from 0.3 below the eye along the look direction, 40 ticks before it can
    /// be picked up again. ponytail: vanilla adds a little random sideways scatter; this one flies straight.
    pub fn throw(&mut self, stack: ItemStack, eye: Vec3, forward: Vec3) {
        let pos = eye - Vec3::new(0.0, 0.3, 0.0);
        let vel = forward * 0.3 + Vec3::new(0.0, 0.1, 0.0);
        self.push(ItemEntity { pos, prev: pos, vel, stack, age: 0, pile: false, delay: 40, on_ground: false, health: 5 });
    }

    /// A stack leaving `pos` with `vel` blocks per tick (a caught fish flying to the player), pick-up delay 10.
    pub fn throw_from(&mut self, stack: ItemStack, pos: Vec3, vel: Vec3) {
        self.push(ItemEntity { pos, prev: pos, vel, stack, age: 0, pile: false, delay: 10, on_ground: false, health: 5 });
    }

    /// A broken furnace's contents pop out of the middle of its cell (`BlockFurnace.onBlockRemoved`).
    /// ponytail: vanilla splits a stack into random-sized piles; this is one entity per stack.
    pub fn scatter(&mut self, stack: ItemStack, (x, y, z): (i32, i32, i32)) {
        let pos = Vec3::new(x as f32 + 0.5, y as f32 + 0.5, z as f32 + 0.5);
        let mut jitter = || (self.fx.next_double() * 0.2 - 0.1) as f32;
        let vel = Vec3::new(jitter(), 0.2, jitter());
        self.push(ItemEntity { pos, prev: pos, vel, stack, age: 0, pile: false, delay: 10, on_ground: false, health: 5 });
    }

    /// A death's drop (NOT b1.7.3, UNVERIFIED): `scatter`, but the item belongs to the pile (it lasts `PILE_LIFE`, and the map marks it).
    pub fn scatter_pile(&mut self, stack: ItemStack, cell: (i32, i32, i32)) {
        self.scatter(stack, cell);
        if let Some(e) = self.items.last_mut() {
            e.pile = true; // `push` always appends
        }
    }

    /// Where the pile lies: the middle of its items on the ground plane, `None` once none is left (all picked up, burnt or old).
    pub fn pile_at(&self) -> Option<(f32, f32)> {
        let (n, x, z) = self.items.iter().filter(|e| e.pile).fold((0.0, 0.0, 0.0), |(n, x, z), e| (n + 1.0, x + e.pos.x, z + e.pos.z));
        (n > 0.0).then(|| (x / n, z / n))
    }

    /// Add an entity, dropping the oldest one when `MAX_ITEMS` is reached.
    fn push(&mut self, e: ItemEntity) {
        if self.items.len() >= MAX_ITEMS {
            self.items.remove(0);
        }
        self.items.push(e);
    }

    /// Advance by `dt` seconds in 20 Hz ticks; items near `player` (centre of its box) go into `inv`.
    pub fn tick(&mut self, dt: f32, get: BlockQuery<'_>, player: Vec3, inv: &mut Inventory) {
        self.acc += dt;
        while self.acc >= TICK {
            self.acc -= TICK;
            self.items.retain_mut(|e| e.step(get) && !e.picked_up(player, inv, &mut self.pops, &mut self.got));
        }
    }
}

#[cfg(test)]
mod tests {
    /// `Explosion.doExplosionA` on a dropped item: `attackEntityFrom` takes the damage off its 5 health (gone at 0) and the push is added to its motion.
    #[test]
    fn a_blast_wears_an_item_down_and_throws_it() {
        let mut it = super::ItemEntity::resting(glam::Vec3::ZERO, super::ItemStack { id: 1, count: 1, damage: 0 }, 0);
        assert!(!it.blast(glam::Vec3::new(0.1, 0.2, 0.0), 4), "5 - 4 = 1 left");
        assert_eq!(it.vel, glam::Vec3::new(0.1, 0.2, 0.0));
        assert!(it.blast(glam::Vec3::ZERO, 1), "1 - 1 = 0: gone");
        let mut tough = super::ItemEntity::resting(glam::Vec3::ZERO, super::ItemStack { id: 1, count: 1, damage: 0 }, 0);
        assert!(tough.blast(glam::Vec3::ZERO, 65), "a TNT at point blank deals 65");
    }

    #[test]
    fn names_match_lang() {
        let n = |id, damage| super::name(super::ItemStack { id, count: 1, damage });
        assert_eq!(n(1, 0), Some("Stone"));
        assert_eq!(n(257, 0), Some("Iron Pickaxe"));
        assert_eq!(n(35, 14), Some("Red Wool")); // meta 14 = red (~14 & 15 = 1)
        assert_eq!(n(263, 1), Some("Charcoal"));
        assert_eq!(n(44, 2), Some("Wooden Slab"));
        assert_eq!(n(351, 4), Some("Lapis Lazuli"));
        assert_eq!(n(9999, 0), None);
    }

    use super::*;

    /// Crops drop seeds when young, wheat plus seeds when ripe (`BlockCrops`), never a crops item.
    #[test]
    fn crops_drop_seeds_and_wheat() {
        let mut d = Drops::new(1);
        for _ in 0..50 {
            d.spawn_block(59, 3, (0, 64, 0));
        }
        assert!(d.items.iter().all(|e| e.stack.id == 295), "young crops: seeds only");
        let mut d = Drops::new(1);
        d.spawn_block(59, 7, (0, 64, 0));
        assert_eq!(d.items.iter().filter(|e| e.stack.id == 296).count(), 1);
        assert!(d.items.iter().all(|e| e.stack.id != 59));
    }

    /// Stew heals 10 and leaves a bowl; other items are not food and stay.
    #[test]
    fn stew_heals_and_leaves_a_bowl() {
        let mut inv = Inventory::default();
        inv.slots[0] = Some(ItemStack { id: STEW, count: 1, damage: 0 });
        inv.slots[1] = Some(ItemStack { id: 4, count: 5, damage: 0 });
        assert_eq!(inv.eat(1), None);
        assert_eq!(inv.slots[1].map(|s| s.count), Some(5));
        assert_eq!(inv.eat(0), Some(10));
        assert_eq!(inv.slots[0], Some(ItemStack { id: BOWL, count: 1, damage: 0 }));
        assert_eq!(inv.eat(0), None);
        assert_eq!(inv.eat(2), None);
    }

    // Death pile: it outlives a plain drop (5 minutes) up to 20, its mark survives the level file's `age`, and it is found by the middle of its items.
    #[test]
    fn a_death_pile_lasts_four_times_as_long_and_is_found() {
        let mut d = Drops::new(1);
        let floor = |_: i32, y: i32, _: i32| Some(if y <= 9 { 1 } else { 0 });
        let mut inv = Inventory::default();
        d.scatter(ItemStack { id: 4, count: 1, damage: 0 }, (0, 10, 0));
        d.scatter_pile(ItemStack { id: 5, count: 1, damage: 0 }, (0, 10, 0));
        d.scatter_pile(ItemStack { id: 6, count: 1, damage: 0 }, (4, 10, 4));
        let (x, z) = d.pile_at().expect("a pile");
        assert!((x - 2.5).abs() < 0.5 && (z - 2.5).abs() < 0.5, "the middle of the two: {x} {z}");
        let saved: Vec<u32> = d.items.iter().map(|e| e.saved_age()).collect();
        assert!(saved[0] < PILE_BIT && saved[1] >= PILE_BIT, "only the pile is marked");
        let back = ItemEntity::resting(Vec3::ZERO, ItemStack { id: 5, count: 1, damage: 0 }, saved[1] + 7);
        assert!(back.pile && back.age == 7, "the mark and the age come back apart");
        d.tick(301.0, &floor, Vec3::new(100.0, 11.0, 0.0), &mut inv); // 6020 ticks
        assert_eq!(d.items.iter().filter(|e| e.pile).count(), 2);
        assert_eq!(d.items.len(), 2, "the plain drop is gone");
        d.tick(900.0, &floor, Vec3::new(100.0, 11.0, 0.0), &mut inv); // 24020 ticks in all
        assert!(d.items.is_empty() && d.pile_at().is_none());
    }

    /// The Java drop rules, `addItemStackToInventory`, and an item falling, landing and being picked up.
    #[test]
    fn drops_inventory_and_item_physics() {
        let mut d = Drops::new(1);
        let ids = |d: &Drops| d.items.iter().map(|e| (e.stack.id, e.stack.damage)).collect::<Vec<_>>();
        d.spawn_block(1, 0, (0, 10, 0)); // stone
        d.spawn_block(2, 0, (0, 10, 0)); // grass
        d.spawn_block(79, 0, (0, 10, 0)); // ice: nothing
        d.spawn_block(32, 0, (0, 10, 0)); // dead bush: nothing
        assert_eq!(ids(&d), [(4, 0), (3, 0)]);
        d.spawn_block(21, 0, (0, 10, 0)); // lapis: 4..=8 dye with damage 4
        let n = d.items.len() - 2;
        assert!((4..=8).contains(&n) && ids(&d)[2..].iter().all(|&i| i == (351, 4)));

        // Floor at y <= 9. With the player far away every item comes to rest on top of it.
        let floor = |_: i32, y: i32, _: i32| Some(if y <= 9 { 1 } else { 0 });
        let mut inv = Inventory::default();
        d.tick(2.0, &floor, Vec3::new(100.0, 11.0, 0.0), &mut inv);
        assert!(d.items.iter().all(|e| (e.pos.y - (10.0 + R)).abs() < 0.01 && e.on_ground));
        // The player walks over: everything is picked up, equal items merge into one stack.
        let before = d.items.len();
        d.tick(0.1, &floor, Vec3::new(0.5, 10.9, 0.5), &mut inv);
        assert!(d.items.is_empty());
        assert_eq!(d.pops.len(), before); // one `random.pop` for each item that went in
        assert_eq!(inv.slots[0], Some(ItemStack { id: 4, count: 1, damage: 0 }));
        assert_eq!(inv.slots[2].map(|s| (s.id, s.count as usize)), Some((351, n)));

        // 70 cobblestone: one full stack and a 6; a full hotbar takes nothing; consume empties a slot.
        let mut inv = Inventory::default();
        let mut s = ItemStack { id: 4, count: 70, damage: 0 };
        assert!(inv.add(&mut s) && s.count == 0);
        assert_eq!((inv.slots[0].unwrap().count, inv.slots[1].unwrap().count), (64, 6));
        for slot in 1..SLOTS {
            inv.slots[slot] = Some(ItemStack { id: 5, count: 64, damage: 0 });
        }
        let mut s = ItemStack { id: 4, count: 1, damage: 0 };
        assert!(inv.add(&mut s) == false && s.count == 1);
        d.pops.clear();
        d.spawn_stack(s, (0, 10, 0));
        d.tick(0.1, &floor, Vec3::new(0.5, 10.9, 0.5), &mut inv);
        assert!(d.pops.is_empty() && d.items.len() == 1); // a full bag takes nothing: silent
        inv.slots[3] = Some(ItemStack { id: 5, count: 1, damage: 0 });
        inv.consume(3);
        assert_eq!(inv.slots[3], None);

        // 36 slots: the 28th stack goes to slot 27. Tools stack 1 and the use past the durability breaks them.
        let mut inv = Inventory::default();
        let mut s = ItemStack { id: 4, count: 64, damage: 0 };
        assert!(max_stack(285) == 1 && max_stack(280) == 64 && MAIN == 36);
        inv.slots[..27].fill(Some(ItemStack { id: 5, count: 64, damage: 0 }));
        assert!(inv.add(&mut s) && inv.slots[27] == Some(ItemStack { id: 4, count: 64, damage: 0 }));
        inv.slots[0] = Some(ItemStack { id: 285, count: 1, damage: 31 }); // golden pickaxe: 32 uses
        inv.damage(0, 1);
        assert_eq!(inv.slots[0].map(|s| s.damage), Some(32));
        inv.damage(0, 1);
        assert_eq!(inv.slots[0], None);
        inv.damage(1, 1); // not a tool: untouched
        assert_eq!(inv.slots[1].map(|s| s.count), Some(64));
    }

    /// `damageDropped` / `getPlacedBlockMetadata`: metadata survives break -> drop -> place.
    #[test]
    fn metadata_survives_break_and_place() {
        let mut d = Drops::new(1);
        let stacks = |d: &Drops| d.items.iter().map(|e| (e.stack.id, e.stack.damage)).collect::<Vec<_>>();
        d.spawn_block(35, 14, (0, 10, 0)); // red wool
        d.spawn_block(17, 2, (0, 10, 0)); // birch log
        d.spawn_block(43, 3, (0, 10, 0)); // double slab: two single slabs of the same type
        assert_eq!(stacks(&d), [(35, 14), (17, 2), (44, 3), (44, 3)]);
        // Leaves drop their species without the placed bit; a placed leaf gets the bit.
        assert_eq!(damage_dropped(18, 8 | 2), 2);
        let stack = |id: u16, damage: u16| ItemStack { id, count: 1, damage };
        assert_eq!((placed_meta(stack(18, 2)), placed_meta(stack(35, 14)), placed_meta(stack(1, 0))), (10, 14, 0));
        // A block item shows its metadata colour; a tool's wear is not metadata.
        assert_eq!(stack_tile(stack(35, 14)), atlas::tile_of(35, 14));
        assert_eq!(stack_tile(stack(270, 3)), tile(270) as u16);
    }

    /// NOT b1.7.3: broken oak leaves give apples at the odds given, other species only saplings; the stacks are those of `spawn_block`.
    #[test]
    fn leaves_give_apples_at_the_odds_given() {
        let mut d = Drops::new(5);
        for _ in 0..1000 {
            d.spawn_leaf(0, (0, 64, 0), (20, 25));
        }
        let (apples, saplings) = (d.items.iter().filter(|i| i.stack.id == 260).count(), d.items.iter().filter(|i| i.stack.id == 6).count());
        assert!((20..=65).contains(&apples) && (25..=85).contains(&saplings), "{apples} apples, {saplings} saplings of 1000 leaves (about 40 and 50)");
        let mut spruce = Drops::new(5);
        for _ in 0..1000 {
            spruce.spawn_leaf(1, (0, 64, 0), (20, 1));
        }
        assert!(spruce.items.iter().all(|i| i.stack.id == 6 && i.stack.damage == 1), "spruce leaves: its sapling, never an apple");
    }
}
