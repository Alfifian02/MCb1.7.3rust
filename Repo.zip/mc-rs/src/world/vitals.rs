//! Player health and damage: `EntityLiving.attackEntityFrom` (the 10-tick damage window), `Entity.updateFallState` /
//! `EntityLiving.fall`, drowning (`air`), lava and burning, and falling out of the world (`Entity.onEntityUpdate`).
//! b1.7.3 has no hunger and no natural regeneration (only Peaceful heals): food heals on the tap, and in an Immersive Pack world `combat::mend`
//! adds the hearth, the bandage and the bed. Still no hunger.
//! Suffocation (1 damage a tick with the head in a wall) is `Env.in_wall`.
//! ponytail: no damage flash or knockback, no burning/hurt sounds (all later).

use crate::world::dig::TICK;
use crate::world::combat::{guard::Guard, mend::Mend};
use crate::world::stamina::Stamina;

pub const MAX_HEALTH: i32 = 20;
pub const MAX_AIR: i32 = 300;

/// What the world says about the player this frame.
#[derive(Clone, Copy, Default)]
pub struct Env {
    /// Vertical movement this frame (negative = fell).
    pub dy: f32,
    pub on_ground: bool,
    /// The box touches water / lava (`handleWaterMovement`, `handleLavaMovement`).
    pub water: bool,
    pub lava: bool,
    /// The feet are in a ladder cell (`isOnLadder`): `fallDistance` is reset every frame.
    pub ladder: bool,
    /// The eye is inside a water cell (`isInsideOfMaterial(water)`), and its height (`Entity.posY` of a player).
    pub eye_in_water: bool,
    pub eye_y: f32,
    /// The head is inside a normal cube (`Entity.isEntityInsideOpaqueBlock`): suffocation.
    pub in_wall: bool,
}

pub struct Vitals {
    pub health: i32,
    /// Set by a fresh hit (`random.hurt`, also the death cry) and by a landing that hurt (the block's step sound); the frame takes them.
    pub cry: bool,
    pub thud: bool,
    /// Blocks fallen by landings of 2 or more (`EntityPlayer.fall` -> `distanceFallenStat`); the frame takes it.
    pub fell: f32,
    /// Set when water puts out a burning player (`random.fizz`); the frame takes it.
    pub fizz: bool,
    pub air: i32,
    pub fire: i32,
    /// `heartsLife`: 20 right after a hit, counts down; while above 10 only a bigger hit than `last_damage` counts.
    hearts_life: i32,
    last_damage: i32,
    fall: f32,
    acc: f32,
    /// `getTotalArmorValue`, set by the caller each frame; `rem` = `damageRemainder`; `wear` = damage the armor has to take.
    pub armor: i32,
    pub wear: i32,
    rem: i32,
    /// Set when the air ran out and the drowning bubbles pop (`EntityLiving.onEntityUpdate`); the caller takes it.
    pub drowned: bool,
    /// Stamina (`world::stamina`): here so health and armor set its maximum, a damage marks combat, and every respawn / reset fills it.
    pub stamina: Stamina,
    /// NOT b1.7.3 (`biomeRules`): ticks left of a meal's warmth (`biomelife::FED_TICKS`); food for the cold.
    pub fed: u32,
    /// Cortes Combat C4 (NOT b1.7.3, only with the Immersive Pack ON): healing without hunger (`combat::mend`: hearth, bandage) and the sword's guard,
    /// both back to their start on every respawn.
    pub mend: Mend,
    pub guard: Guard,
}

impl Default for Vitals {
    fn default() -> Self {
        Self { health: MAX_HEALTH, cry: false, thud: false, fell: 0.0, fizz: false, air: MAX_AIR, fire: 0, hearts_life: 0, last_damage: 0, fall: 0.0, acc: 0.0, armor: 0, wear: 0, rem: 0, drowned: false, fed: 0, stamina: Stamina::default(), mend: Mend::default(), guard: Guard::default() }
    }
}

impl Vitals {
    pub fn dead(&self) -> bool {
        self.health <= 0
    }

    /// `EntityPlayer.damageEntity`: armor takes `dmg` off 25ths (`25 - armor`), the remainder carries over to the next hit.
    fn absorb(&mut self, dmg: i32) -> i32 {
        let t = dmg * (25 - self.armor) + self.rem;
        (self.wear, self.rem) = (self.wear + dmg, t % 25);
        t / 25
    }

    /// `EntityLiving.attackEntityFrom` for a damage source with no attacker. False if nothing was taken.
    pub fn hurt(&mut self, dmg: i32) -> bool {
        if self.health <= 0 {
            return false;
        }
        if self.hearts_life > 10 {
            if dmg <= self.last_damage {
                return false;
            }
            self.health -= self.absorb(dmg - self.last_damage);
        } else {
            self.hearts_life = 20;
            self.health -= self.absorb(dmg);
            self.cry = true;
        }
        self.last_damage = dmg;
        self.stamina.hit(); // `LivingDamageEvent.Post`: any damage taken puts the player in combat for 15 s
        true
    }

    /// `Entity.onStruckByLightning`: 5 fire damage and burning (`++fire`, 300 ticks if it was out; here 0 = not burning, vanilla -1).
    pub fn lightning(&mut self) {
        self.hurt(5);
        self.fire = if self.fire <= 0 { 300 } else { self.fire + 1 };
    }

    /// `EntityLiving.heal`: nothing for the dead; the damage window drops to half.
    pub fn heal(&mut self, n: i32) {
        if self.health > 0 {
            self.health = (self.health + n).min(MAX_HEALTH);
            self.hearts_life = 10;
        }
    }

    /// Points from `combat::mend` (hearth, bandage) or a bed: like `heal`, but the damage window stays as it is (`heal` cuts it to half, which a
    /// trickle of points would keep doing).
    pub fn restore(&mut self, n: i32) {
        if self.health > 0 {
            self.health = (self.health + n).min(MAX_HEALTH);
        }
    }

    /// `updateFallState` (every frame) and `EntityLiving.fall`: landing after `d` blocks costs `ceil(d - 3)`;
    /// water cancels the fall.
    fn land(&mut self, e: &Env) {
        if e.water || e.ladder {
            self.fall = 0.0;
        }
        if e.on_ground {
            if self.fall >= 2.0 {
                self.fell += self.fall;
            }
            let dmg = (self.fall - 3.0).ceil() as i32;
            self.fall = 0.0;
            if dmg > 0 {
                self.hurt(dmg);
                self.thud = true;
            }
        } else if e.dy < 0.0 {
            self.fall -= e.dy;
        }
    }

    /// One 20 Hz tick of `Entity.onEntityUpdate` + `EntityLiving.onEntityUpdate`.
    fn tick(&mut self, e: &Env) {
        if self.hearts_life > 0 {
            self.hearts_life -= 1;
        }
        if e.in_wall {
            self.hurt(1); // `attackEntityFrom(null, 1)` every tick inside a wall
        }
        if e.water {
            self.fizz |= self.fire > 0;
            self.fire = 0;
        }
        if self.fire > 0 {
            if self.fire % 20 == 0 {
                self.hurt(1);
            }
            self.fire -= 1;
        }
        if e.lava {
            // setOnFireFromLava: 4 damage (the damage window lets one through every 10 ticks) and 30 s of fire.
            self.hurt(4);
            self.fire = 600;
        }
        if e.eye_y < -64.0 {
            self.hurt(1000);
        }
        if e.eye_in_water {
            self.air -= 1;
            if self.air == -20 {
                self.air = 0;
                self.drowned = true;
                self.hurt(2);
            }
            self.fire = 0;
        } else {
            self.air = MAX_AIR;
        }
    }

    /// Advance by `dt` seconds: the fall is judged now, everything else on 20 Hz ticks.
    pub fn update(&mut self, dt: f32, e: Env) {
        self.land(&e);
        self.acc += dt;
        while self.acc >= TICK {
            self.acc -= TICK;
            self.tick(&e);
        }
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    /// A fresh hit sets `cry` (the top-up of a bigger hit inside the window does not), a landing that hurt sets `thud`.
    #[test]
    fn a_fresh_hit_cries_and_a_hard_landing_thuds() {
        let mut v = Vitals::default();
        v.hurt(4);
        assert!(std::mem::take(&mut v.cry) && !v.thud);
        v.hurt(6);
        assert!(!v.cry, "inside the window");
        let mut v = Vitals::default();
        for _ in 0..10 { v.update(0.0, Env { dy: -1.0, ..Env::default() }); }
        v.update(0.0, Env { on_ground: true, ..Env::default() });
        assert!(v.cry && v.thud);
    }

    /// A 10 block fall costs 7 (ceil(10 - 3)); water cancels it; the damage window ignores equal hits and tops up
    /// bigger ones; drowning starts after 300 + 20 ticks and then costs 2 every 20.
    #[test]
    fn damage_like_java() {
        let mut v = Vitals::default();
        for _ in 0..10 { v.update(0.0, Env { dy: -1.0, ..Env::default() }); }
        v.update(0.0, Env { on_ground: true, ..Env::default() });
        assert_eq!(v.health, 13);

        let mut v = Vitals::default();
        for _ in 0..10 { v.update(0.0, Env { dy: -1.0, ..Env::default() }); }
        v.update(0.0, Env { on_ground: true, water: true, ..Env::default() });
        assert_eq!(v.health, 20);

        let mut v = Vitals::default();
        assert!(v.hurt(4) && !v.hurt(4) && v.hurt(5));
        assert_eq!(v.health, 15);
        v.heal(3);
        assert_eq!(v.health, 18);
        v.heal(10);
        assert_eq!(v.health, MAX_HEALTH);
        v.health = 0;
        v.heal(10);
        assert!(v.dead());
        v.restore(10);
        assert!(v.dead(), "nothing mends the dead");
        let mut v = Vitals::default();
        v.hurt(4);
        v.restore(2);
        assert_eq!((v.health, v.hearts_life), (18, 20), "`restore` leaves the damage window alone (`heal` drops it to 10)");

        // Water puts a burning player out with one fizz; no fire, no fizz.
        let mut v = Vitals::default();
        v.fire = 100;
        v.tick(&Env { water: true, ..Env::default() });
        assert!(v.fizz && v.fire == 0);
        v.fizz = false;
        v.tick(&Env { water: true, ..Env::default() });
        assert!(!v.fizz);

        let mut v = Vitals::default();
        let under = Env { eye_in_water: true, ..Env::default() };
        for _ in 0..319 { v.tick(&under); }
        assert_eq!(v.health, 20);
        v.tick(&under);
        assert_eq!(v.health, 18);
        for _ in 0..20 { v.tick(&under); }
        assert_eq!(v.health, 16);
        v.tick(&Env::default());
        assert_eq!(v.air, MAX_AIR);

        // Any damage taken is combat for the stamina: the next sprint tick costs 0.6, not the calm 0.42.
        let mut v = Vitals::default();
        v.stamina.tick(true, MAX_HEALTH, 0.0);
        assert!((v.stamina.cur - (200.0 - 0.42)).abs() < 1e-3);
        let mut v = Vitals::default();
        v.hurt(1);
        v.stamina.tick(true, MAX_HEALTH, 0.0);
        assert!((v.stamina.cur - 199.4).abs() < 1e-3);
    }
}
