# Design rules for what comes after b1.7.3

Once every b1.7.3 system is ported (see [`missing.md`](missing.md)), new content is added by these rules. The goal is the middle picture of the "good update design" diagram: every new feature is joined to several old ones, and old ones keep a job. Nothing here is code; it is a checklist to fill in *before* a feature is written, and a list of what the port already joins.

## The rules

1. **Two hooks minimum.** A new feature must name at least two existing systems it reads from or writes to. A feature with one hook, or none, is not built yet. (Tested by writing the "Hooks" line below; if it cannot be written, the design is not finished.)
2. **No obsolescence.** A new feature may not make an old block, item, mob or tool pointless. If it overlaps one, the old one gets a new role or the new one is cut. Check every item in the same family (tools, food, fuel, blocks of the same material).
3. **Close the loop.** What the feature takes in must come from somewhere (an existing source) and what it makes must go somewhere (an existing sink: crafting, smelting, trading with the world, redstone, a mob, a block's use). No dead ends in either direction.
4. **Reuse the existing tables.** Recipes go into `craft::recipes()`, sounds into the audio table, blocks into the block tables, so everything that reads those (the recipe book, the sounds, the saves) sees the new entry with no extra line. If that is not true, fix the table first.
5. **Say what it is not.** Anything that is not in b1.7.3 is marked **NOT b1.7.3** in its module doc, the README row and the changelog, and gets a switch if it changes how the old game plays (like `animalAi`).
6. **One written line per feature, kept in this file:** `Name: needs (sources) -> makes (sinks); Hooks: A, B; Overlaps: C (what C does now).`

## Original ideas: recommend them

If an idea is original, meaning it is not in vanilla b1.7.3, it is still welcome: just recommend it, with the hooks it would use and a few search words. The player looks for mods that do something similar and uses them as inspiration, so a proposal does not need to be solved in full. Every such idea is still written as a line in this file before any code (rule 6), marked NOT b1.7.3, and given a switch when it changes how the old game plays (rule 5).

## Hook points of the b1.7.3 base

Systems a new feature can attach to. Each one already exists in the port (the module is in brackets).

Light and the day (`sky`, `climate`, `atmos`); weather and biome climate (`climate`, `biome`); block ticks (`ticks`); redstone and rails (`redstone`, `rail`, `minecart`); mobs, their spawning and their pathfinding (`mobs`, `path`); items, durability and armor (`items`, `gear`, `vitals`); crafting and smelting (`craft`); containers (`chest`); the Nether and the portal (`portal`, `gen::nether`); sound (`audio`); the world save (`save`).

## What the port already joins (read from the code on 2026-10-26: check before relying on it)

- **Recipe book -> `craft::recipes()`.** The book lists the one recipe table the grid uses, so the compass, clock and chest cart recipes appeared in it with no line added. This is rule 4 working.
- **Stamina -> `vitals`.** Health and armor set the bar's maximum, damage marks combat, a respawn refills it (`vitals.rs` holds the `Stamina`). Sprint and jumping spend it (`lib.rs` joins `sprint` to it).
- **Immersive pack -> satchel, book, menu, options, fog, clouds, items, player model, touch buttons.** It is the most joined of the extras: the world's switch decides which inventory screen opens, and the satchel tints each slot by item category (`pack::category`).
- **Smart animals -> `path`.** The same A* walks wolves to their owner and keeps calm animals off cliffs and water; the grazing behaviours hang on the same switch (`Mobs::smart`).
- **Atmosphere -> `biome`, `sky`, both renderers.** One editor drives fog and sky colour per biome.

## Where a feature is thin today (my reading of the code; confirm before acting)

- **Shoulder-surf camera:** only `lib.rs` uses it. It is a view, so one hook may be enough, but it reads nothing from the world (no aim assist with the bow or fishing rod, no look at mobs).
- **Sprint and stamina vs food:** b1.7.3 has no hunger, so stamina's only inputs are health and armor. Any later hunger or food system must be joined to the bar, not stand beside it.

## Feature lines

Written 2026-10-26 for entry (20) of the gameplay changelog. All are NOT b1.7.3 and all read what the base already has.

- **Apple:** needs oak leaves (decayed or broken, any world; one in 200) -> food (heals 4) and the golden apple recipe; Hooks: leaf decay and breaking (`ticks`, `lib`), food (`items`), crafting (`craft`); Overlaps: none (the item was in b1.7.3 and could not be found).
- **Autumnal forest:** needs its leaves -> 4 times the apples (one in 50) and a second sapling roll (replanting); Hooks: leaf drops, food, saplings and tree growth; Overlaps: seasonal forest (unchanged).
- **Marsh:** needs wet ground -> clay (bricks), reeds (sugar, paper, books), mushrooms (stew), and slimes on the surface at night (slimeballs for the sticky piston); Hooks: world generation (`populate`), mobs (`mobs`), crafting and redstone (`craft`); Overlaps: swamp (unchanged).
- **Chaparral:** needs dry scrub with no rain -> fire catches and jumps more, so wood and wool there are a risk and the grass burns; Hooks: fire (`ticks`), weather (`Biome::rains`), the burn rates of blocks; Overlaps: desert (no fire change there).
- **Wet woodland:** needs a canopy (20 trees a chunk, leaves take light) -> monsters spawn under it by day (light 8..11 passes the dark check); Hooks: light (`light_opacity`), mobs (`can_spawn`), tree generation; Overlaps: rainforest (unchanged).
- **Snowy birch grove:** needs snow and cold -> wolves live there (the forest and taiga list of b1.7.3, which now spawns for real), tamed with bones; Hooks: climate (`snows`), mobs (spawn lists), wolf taming; Overlaps: taiga (same wolves; the grove has birches and no flowers).
- **Oak woodland:** needs trees and grass -> animals come in herds two larger (food, wool, leather sooner); Hooks: mobs (`pack`), crafting (wool, beds); Overlaps: forest (wolves). This is the weakest line: if it still does not earn its place after play, rule 2 says cut the biome or give it a second hook.

## Ideas waiting (proposed 2026-10-26; built 2026-10-27: 1, 2, 4, 5 and the buildable part of 6; not built: 3 and the landmarks, by request)

Each one serves several biomes at once, so the biomes share systems and none stands alone. Proposed order, easiest first: 2, 3, 1, 5, 4, 6. **Built 2026-10-27 (gameplay entry 24):** the switch is `biomeRules` in options.txt (on; no button) for 1, 2, 4 and the apples of 6, and `animalAi` for 5. Every number is UNVERIFIED by eye; the code is `world/biomelife.rs` unless said. "Inspiration" is a set of search words for finding mods that do something alike.

- **Fog is cover (proposal 2).** needs the thick fog of the marsh, swamp, rainforest and wet woodland (`atmos` already sets fog per biome) -> mobs see you from less far there, and you see them from less far; walking quietly and ambushes become real; Hooks: atmosphere, mob sight (`sees`, the aggro range in `mobs`); Overlaps: none. Inspiration: "fog stealth", "dynamic fog gameplay". **Built:** `biomelife::sight(density)` is 1 below an exp² density of 0.004 and falls to 0.4 at 0.011; `Ctx::sight` scales the 16-block aggro range of every hostile mob (wet woodland 0.83, marsh 0.7, swamp 0.49 of it). "You see them from less far" is the fog the renderer already draws (`photon` / `atmos`, UNVERIFIED that mobs are fogged like terrain).
- **A beam that shows from far (proposal 3).** needs one landmark per biome whose position is worked out from the seed (`structory::spread` is a pure function of the seed and gives each region's start chunk; a function that answers "the nearest landmark" and checks its biome without making chunks is still to be written) -> a thin column of light is drawn in the sky pass (a few quads, faded by distance and fog; probably `render/sky.rs`, not read for this) at each of the nearest landmarks, so it shows past the render distance (16 / 8 / 4 / 2 chunks) with no LoD, which is slow in mc-rs; the compass (now craftable) can be tuned to the nearest landmark with one rare material and gives the way in; the real tower exists only once its chunks load. A tall block alone cannot do this: unloaded chunks are not drawn, so a tower is gone at the render distance. The beam shows only where the structure will really form (the biome check passes), and only the nearest 3 within about 1000 blocks are drawn; Hooks: sky pass, compass (`render/anim.rs`, `craft`), structures (`gen::structory`); Overlaps: the compass, which points to the world spawn only. Inspiration: "waystone", "lodestone compass", "structure locator", "beacon beam visible from far".
- **Heat and cold are stamina (proposal 1).** needs the temperature the biome manager already has (`climate_at`) -> the desert, savanna, shrubland and chaparral drain stamina faster in open daylight; tundra, ice desert, taiga and the snowy grove slow its recovery away from a torch or furnace; Hooks: stamina (`vitals`), day (`sky`), light (torches and furnaces become a second use), armor (`gear`); Overlaps: none. Inspiration: "temperature survival", "heat and cold stamina". **Built:** by biome, not by the noise temperature (desert 1, chaparral 0.8, savanna 0.6, shrubland 0.5; tundra 1, grove 0.8, taiga 0.7): `air(biome, Body)` gives `hot` (times open daylight on the head, +10% a piece of metal armor) and `cold` (zero within 3 blocks of a torch, furnace or lava: block light 11; leather halves it at four pieces; a meal halves it for 5 minutes). `Stamina::tick_in`: a sprint costs `1 + 0.6 hot` times, recovery is `1 - 0.5 cold` times. The jump cost does not change.
- **Predators and grazers (proposal 5).** needs the smart-animal paths (`path`) and the wolf lists of entry (20) -> wolves of the taiga, forest and grove hunt sheep; sheep graze and keep a meadow short in the plains and oak woodland, so tending a pasture is a thing to do; wool and bones feed beds and taming; Hooks: mobs, `path`, smart animals, wolf taming, crafting; Overlaps: the oak woodland's herds (they would gain a reason). Needs the `animalAi` switch. Inspiration: "predator prey", "grazing animals". **Built (not the oak woodland's herds, which are not built):** `Mobs::hunt`: a wild, calm, standing wolf picks the nearest sheep within 14 blocks for 10 seconds out of every 30 (offset by its place in the list), runs it down at 1.8 times its walk and bites for 2 a second; a sheep with such a wolf within 8 blocks runs from it; a tame wolf never hunts. A sheep that finishes grazing sends `Ev::Graze`: `lib.rs` removes the tall grass in its cell, or else turns the grass block under it to dirt, and `BlockGrass.updateTick` (spread) covers it again, so a crowded pasture goes bald and a tended one does not. Wolves are spawned in the forest, the taiga and the snowy grove (`wolf_land`, 1 in 21 attempts), with the coat of the biome (`coat_for`; the pack's six coats).
- **Seasons in the forests (proposal 4).** needs a day count (`world_ticks`) -> in the seasonal and autumnal forests the leaf colour follows the season and apples and saplings drop in some seasons more than others; Hooks: atmosphere tints, leaf drops (entry 20), crops (`ticks`); Overlaps: the autumnal forest's flat apple bonus (it would become the autumn peak). Inspiration: "seasons mod crops". **Built (not the crops):** `season(world_ticks)`: 3 days of 24000 ticks each, spring first, a year of 12 days. The oak foliage of the seasonal and the autumnal forest is tinted by season (`foliage`; spruce and birch keep their colours), a change restarts the loaded meshes (`ChunkManager::restart_meshes`; the LoD keeps its colours until its columns are read again). `leaf_odds`: oak leaves give an apple 1 in 200 anywhere and a sapling 1 in 20; the two forests give saplings in spring (1 in 12) and autumn (14), apples in summer (150 / 100), at the autumn peak (60 / 30, the autumnal forest first) and hardly in winter (800 / 600).
- **Every biome has one export (proposal 6).** needs a table of one specific material per biome (clay of the marsh, sand and cactus of the desert, spruce and furs of the taiga, apples of the autumnal forest) -> another biome's feature needs it (bricks for the desert's buildings, glass for the forests, food for the cold); the table is the real design and is written before the code; Hooks: world generation, crafting, mobs, structures' loot; Overlaps: whatever a biome already gives. Inspiration: "biome exclusive resources". **The table (built where marked):**

  | Biome | Export | Wanted by | Built |
  |---|---|---|---|
  | Marsh | clay: 24 veins a chunk where there is water (10 elsewhere) | bricks, for what is built elsewhere | the clay; **nothing in the base needs bricks yet** |
  | Autumnal and seasonal forest | apples, at their autumn peak | food for the cold: any meal keeps the cold at half for 5 minutes (`Vitals::fed`) | yes |
  | Taiga, tundra, snowy grove | furs: leather armor (b1.7.3's cows give the leather) | four pieces halve the cold | yes |
  | Desert | sand and cactus: glass | windows for the forests' buildings | **not built** (no building uses glass) |
  | Desert, savanna | metal is the thing to take off (+10% heat a piece) | the hot biomes | yes (a cost, not an export) |

  Bricks and glass need a structure that asks for them, which is the landmarks' job (not built, by request).

## Landmarks (proposed 2026-10-26, nothing built)

Serves proposal 3 (the beam): every structure in `gen::structory` today is low and wide (ruins, chapels, camps, manors, boats, the taiga dungeon, the swamp ruin), so none has a silhouette. These do. They are built by code (the tree generator, the dungeon builder), not by new jigsaw templates, because `structory.bin` is already 994 KB. Order, easiest first: 1, 2, 3, 4, 5, 6.

**The one role they all share:** a landmark can be attuned once, by right-clicking its base with the rare material of proposal 3, and the compass then points to the next landmark in that direction. The attuning mark at the foot is an existing block (a lapis block), so no new block id is needed. Together they form a chain to follow, and what each one is on its own is only a silhouette and one local reason to stop. Rule 1 is met through this role (compass, crafting) plus the hooks below.

**Two rules for all six:** the base is stone (or sandstone, or ice) so that the landmark the beam points to cannot burn or be dug away by accident; and each stands only where the biome check of its set passes, so the beam never points at nothing.

- **1. Standing stone (plains, tundra).** needs a flat spot -> one tall stone pillar in a ring of mossy cobblestone with a chest at its foot; Hooks: compass (attuning), loot (a chest of b1.7.3 items), light (a torch ring at night); Overlaps: none.
- **2. The great tree (wet woodland, autumnal forest, rainforest).** needs the tree generator (`gen::populate::Tree`) scaled to 40 or more blocks -> a single giant tree whose canopy is a landmark by day and a dark roof under it; apples and saplings drop from it as from any leaves; Hooks: tree generation, leaf drops and the apple (entry 20), the wet woodland's dark spawn check, compass; Overlaps: the ordinary trees there (this one is the only tall one).
- **3. The stilt tower (marsh, swamp).** needs shallow water -> tall wooden posts over the water with a lamp at the top (a glowstone or jack-o-lantern) and a platform with a chest; slimes spawn on the surface around it at night (entry 20) and the clay is under it; Hooks: marsh slimes (`can_spawn`), clay and reeds (`populate`), light, compass; Overlaps: the swamp ruin (that one is low and sunk).
- **4. The stepped pyramid (desert).** needs sand -> a stepped sandstone pyramid with a trapped chamber inside (pressure plate and TNT) and a chest of better loot as the reward for the risk; Hooks: sandstone, redstone and TNT (`redstone`, `ticks`), loot, compass; Overlaps: none.
- **5. The fire tower (chaparral).** needs dry scrub -> a stone base and a wooden top with a brazier; the wood burns easily there (entry 20), so the top can be lost to a fire while the stone base and the beam stay; Hooks: fire (`ticks::fire`), the burn rates, skeletons in the dark of the base (`mobs`), compass; Overlaps: none.
- **6. The ice spire (snowy birch grove, tundra, ice desert).** needs snow -> a tall spike of ice blocks with a wolf den at its foot (the grove's wolf list, entry 20), bones from the skeletons around it for taming; Hooks: ice and snow (`snows`), wolf spawn lists and taming, compass; Overlaps: the taiga (same wolves, no spire).

Inspiration (search words): "waystone", "ancient obelisk", "world tree", "signal fires beacon chain", "stilt hut swamp", "desert temple trap", "ice spike".

## Cortés Combat (written 2026-10-30, NOT b1.7.3)

- **Combat rework (cone reach, cooldown, charge, guard, five weapon families):** needs wood, cobblestone, iron, diamond, gold, sticks, flint and iron blocks (existing sources) -> weapons that kill mobs; Hooks: crafting (`craft::recipes`, recipe book), durability (`craft::max_damage`), mobs and their damage window (`mobs`), stamina (`vitals`, guard), the touch HUD (`input/touch_ui`), sound (`audio`); Overlaps: sword, axe, hoe (they get a profile of the same system, so each keeps a job: the sword is the wide cheap cone with no special, the hoe sweeps). Switch: `combatRules`, default off. Plan: [`combat.md`](combat.md).
