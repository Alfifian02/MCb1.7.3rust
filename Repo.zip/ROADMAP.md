# Roadmap: Minecraft b1.7.3 -> Android in Rust

Fresh start. One milestone per session. Vanilla names. Vulkan-only.
Own simple save format (M7 dropped McRegion). Client-only networking.

## Milestones
| #   | Name | Deliverable |
|-----|------|-------------|
| M0  | Skeleton | Buildable APK, solid color on screen, lifecycle correct |
| M1  | Blocks + chunks | Hand-built 16x16x128 stone chunk visible |
| M2  | Camera + physics | First-person walk, jump, AABB collision |
| M3  | Overworld gen | Beta-1.7 noise: grass/dirt/stone, sea level 64, ores |
| M4  | Biomes + trees + caves | All b1.7.3 biomes + worldgen populate step |
| M5  | Block interaction | Raycast pick, break, place, light update (done, compiled and ran on an Android device: see Changelog) |
| M6  | Inventory + crafting | Survival inv, hotbar, crafting grid, recipes (done, compiled and ran on an Android device: see Changelog) |
| M7  | Save | Own format (not McRegion, by decision): per-chunk RLE files + `level`; autosave, save on pause/exit, resume (done, compiled and ran on an Android device: see Changelog) |
| M8  | Entities + AI | Mobs + item entities |
| M9  | Audio | Positional OGG, music stubs |
| M10 | Multiplayer | Full b1.7.3 client protocol |
| M11 | Nether | Hell biomes, portals, ghast, zombie pigman |
| M12 | Touch UX | Landscape; move stick, look drag, jump button, hotbar tap, pause menu |
| M13 | Optimization | Frustum culling, greedy meshing, profiler |
| M14 | Polish | Splash, main menu, settings, lang |

## Build
- Workspace at `mc-rs/`
- `cargo test --lib` runs the unit tests: 47 before block metadata, 52 with it, 56 with swimming, health, food and frustum culling (Android host such as Termux; see README).
- `cargo run` boots a desktop window (Metal / Vulkan / GL depending on host).
- APK via GitHub Actions `cargo apk build --release` -> `MinecraftB173Rust.apk`.
- A long-lived debug keystore at `keystore/debug.keystore` signs the release
  APK in CI. The same keystore is what `cargo apk build --release` expects at
  `~/.android/debug.keystore` with password `android` if you build locally.

## Source-of-truth rule

Anything that cannot be diffed against the b1.7.3 Java sources or the
decompiled `minecraft/` tree is marked `// UNVERIFIED:` in the code. PRs
that fix UNVERIFIED items should drop the marker and link the source line
they matched.

## Next step

M8 (entities + AI). M7 (save) is written but not compiled: run `cargo test --lib` first. Furnaces smelt (see the furnace entry), so the whole tool chain up to diamond is reachable. M6 is written and the crate type-checks and tests on a host, but nothing has run on a device (M5 included). M4 is done: caves and populate match the real classes bit for
bit (`tools/golden/`). Still approximate in populate (see README): light model, no metadata, no tile entities, no block
ticks (liquids/sand). Sapling growth, fluid flow and falling sand are in M6b (block updates). Ice Desert exists in
BiomeGenBase but climate never selects it; b1.7.3 has no ravines.

## Changelog
- 2026-10-13: FIX lines along block edges + white flicker on textures (written WITHOUT a Rust toolchain: not compiled, not run; the clamp maths ran in `tools/atlas_bleed_check.py` on the real `terrain.rgba`, the WGSL is validated by the existing `chunk_shader_validates_and_legacy_is_forward`, which gained one assert; video `Record_2026-10-13-14-24-31.mp4`):
    - Root cause, one shared read in `gpu/pipeline.rs`: every block texture is a 16 px tile of one atlas, and the sampler is `Linear` (minified, i.e. distant or slanted faces, and everything at `RENDER_SCALE` 0.67) with `Linear` mips. A bilinear tap within half a texel of a tile edge reads the NEIGHBOURING tile, and the UV inset of 0.02 texel (`atlas::terrain_uv`) only covers mip 0, so at mip 1/2 a tap at the edge takes ~half of the next tile (`Repeat` also wraps tile 0 into tile 15 and the items rows). Measured in the script: up to 97/255 of colour from outside the tile (planks next to a transparent-black neighbour, dirt next to sand, ...), changing with the lod as the camera moves = lines at the block ends and a flicker. Transparent texels are black (`terrain.rgba`), the bright ones are light neighbours.
    - Fix: `atlas_sample` (WGSL) replaces both `textureSample(tex, ..)` calls (`fs_main`, `fs_water`): the UV is clamped into its own tile by half a texel of the coarsest mip the sampler will touch (`ceil(lod)`, `lod` from the same derivatives), then `textureSampleGrad`. Magnified (Nearest) it changes nothing; the flat-colour strip is read at mip 0 (before, its mips blended neighbouring flat colours on items and mobs). The script's worst edge error goes from 97 to 0.
    - Second cause of a shimmer on dirt walls: the grass-side overlay (tile 38, 2 mm off the face) z-fought with the face under it past ~40 blocks (Depth32 resolves ~1.2e-6 z^2 blocks at near 0.05). `vs_main` pulls tile 38 forward by 8 depth ulps (`o.pos.z -= 5e-7 * o.pos.w`). UNVERIFIED on a device; if the fringe still flickers far away, raise it.
    - ponytail: mip alpha is still averaged (distant plants thin out, the cut-out reads mip 0); the clamp costs 1 `log2` + 1 `floor` per pixel; the atlas is not padded or dilated (an alternative that costs memory and a new generator step).
- 2026-10-13: `done` player and world effects (written WITHOUT a Rust toolchain: not compiled, not run; +1 test `effects_follow_java` and the extended `chunk_and_level_round_trip` not run; Java read from the decompiled `Entity`, `EntityLiving`, `EntityLightningBolt`, `EntityBubbleFX`, `EntitySplashFX`, `EntityRainFX`, `TileEntityMobSpawner`, `World.tick`):
    - `world/effects.rs` (new): splash on entering water (`1 + width * 20` bubbles + splashes), drowning bubbles (`Vitals.drowned`), suffocation (`inside_opaque` -> `Env.in_wall`: 1 damage a tick), thunderstorms (`Effects::storm`: 1 in 100000 per chunk of the 19 x 19 round the player while rain > 0.2 and thunder > 0.9; `Bolt` = `EntityLightningBolt`'s 2-tick life + 1..3 strikes; `struck` box; `Vitals::lightning` = 5 damage + fire; mobs take 5; `lightning_flash` pulls the sky colour towards the flash like `func_4079_a`), `TileEntityMobSpawner` (`Effects::tick_spawners`: player within 16, 4 tries, `>= 6` of its kind within 8 x 4 x 8 stops, 200..800 tick delay; populate now records the mob it drew: `Region::take_spawners` -> `ChunkManager::take_spawners`, saved in `level` after the chests, an older file loads with none). Particles and bolts are flat boxes in `render/items.rs`.
    - Weather visuals: `render/weather.rs` is now self-contained (own pass over the HDR scene with the terrain depth read-only, no water layer needed) and wired into `lib.rs` `render`; rain/snow quads come from the existing `weather::build`.
    - Lighting: dropped items, mobs, arrows and falling blocks are lit by the cell they are in (`ChunkManager::light_levels` -> the mesher's `lm`, `Entity.getBrightnessForRender`), they were always full sky light.
    - Not done: sounds, fire from a bolt, charged creeper / pigman, a jagged bolt, the spinning mob cage of a spawner, mobs suffocating, signs / other tile entities, rain splashes on the ground, rain behind water, the lightning flash in the Photon (non-legacy) sky, the rest of lighting parity (the mesher still treats leaves as open sky on purpose, populate keeps its column light model). UNVERIFIED: `EntityFlameFX` / `EntitySmokeFX` motion, bolt column and spawner kind not drawn from `World.field_9437_g`, flash decay (one a tick).
- 2026-10-13: FPS hitches (UNVERIFIED on a device, no toolchain in the session). The 60-117 ms gaps in `Record_2026-10-12-20-37-27` fit meshing two chunks in one frame on a weak phone (a mesh now also samples the climate noise for the biome tints). `ChunkManager::update` times its stages: a second mesh in a frame starts only while the frame's chunk work is under `CHUNK_WORK_BUDGET` (6 ms), so a slow phone builds one chunk per frame and a fast one two; `LIGHT_BUDGET` 10 -> 4 ms (a new chunk lights a few frames later, no frame spends 10 ms on it). A frame whose chunk work takes 16 ms or more logs `slow chunk work` with its stages (stream + populate / light / meshes): if hitches remain, `adb logcat | grep 'slow chunk work'` says which stage. Autosave is NOT the cause that is fixed here: writing chunks eagerly would rewrite each one up to 4 times (`put_region` dirties the 2x2). Next step if one mesh alone is still too slow: mesh on the workers (neighbour blocks behind an `Arc`).
- 2026-10-12: FIX magenta terrain + cheaper frame on low-end. UNVERIFIED on a device (no toolchain in the session): `cargo test --lib` and a phone run still to do. Video `Record_2026-10-12-15-16-45`: hard-edged screen rectangles where only terrain pixels lose green (sky and HUD in the same rectangle are fine); the clean-frame pixels pushed through the shader maths with scene green = 0 reproduce the observed colours, so green is non-finite in the HDR scene (`sane` zeroes it). Suspect: the opaque terrain pipeline used `BlendState::REPLACE`, which still enables the blend unit and reads the old framebuffer (`dst * 0`); now `blend: None`. If magenta survives, suspect Rgba16Float as the scene format on that GPU. Perf: `ChunkManager::set_sky_sub` no longer marks every mesh stale (no vertex the shaders read depends on the baked sky-light; day/night is the `amb.x` uniform), which removes a whole-ring remesh at every sky-light step; legacy `fs_main` computes `face_index` only for flat faces (`in.ao < 0`). Test: `sky_light_step_keeps_the_meshes`. Not done: `draw_ranges` walks a HashMap, so terrain draws in random order (the nearest-first `ring` could give front-to-back).
- `done` rendering gaps (written WITHOUT a Rust toolchain: not compiled, not run; +4 tests not run: `mesh::grass_overlay_tint_and_rail_quad`, `anim::tiles_stay_in_their_ranges`, `climate::colours_come_from_the_maps`, extended `atlas::faces_pick_terrain_tiles`). `tools/gen_terrain.py` ran: `terrain.rgba` is now UNTINTED, plus `grasscolor.rgb`, `foliagecolor.rgb`, `items.rgba`, `render/icons.rs`.
    - Biome tint per block: `Vertex.tint` (8th float, `r<<16|g<<8|b`, `VF` = 8), `world/climate.rs` (`ColorizerGrass`/`ColorizerFoliage`), `ChunkManager::biome_tints` samples the climate of the 16 x 16 columns at mesh time; `mesh::tint_of` (grass top, tall grass, reeds, leaves: pine / birch by metadata). The shader multiplies the texel by it (`vs_main` -> `fs_main`).
    - Grass side overlay: tile 38 as a second cut-out quad 2 mm off each side, grass-tinted; snow on top uses tile 68 and no overlay.
    - Animated water, lava, fire: `render/anim.rs` ports the 6 `TextureFX` classes, ticked at 20 Hz in `lib.rs`, written by `ChunkPipeline::animate` (with their mips). Fire (51) is drawn as crossed quads of tiles 31 / 47 (`mesh::push_fire`, ponytail: no wall / roof flames).
    - Mipmaps: 3 levels (16 / 8 / 4 px per tile, alpha-weighted box filter), `Nearest` magnification, linear minification.
    - Item sprites: `gui/items.png` under the flat strip in the atlas (`ITEM_TILE0 + icon`), `item_icon` from the generated `Item.iconIndex` table; dropped items are two crossed thin slabs, the HUD draws sprites (`HudPipeline::push_sprite`, textured HUD quads). Blocks stay flat colour in the HUD (vanilla draws an isometric cube).
    - Water sorted back to front per chunk (`draw_ranges`). ponytail: faces inside a chunk keep map order.
    - Models: doors (64, 71: `door_face` mirrored faces, 3/16 boxes by state), bed (26: `bed_tile`, 9/16 box), ladder (65) and rails (66, 27, 28: `mesh::push_flat`, slopes and curves). Rails and ladders no longer collide; the bed collides 9/16 high; a door still collides as a full cell (ponytail: queries carry ids, not metadata). Not done: door open / close, bed sleeping, ladder climbing, rail shape on placement (no item or recipe makes these blocks yet).
- `done` legacy frame: terrain lit in one forward pass; black-terrain flicker (written WITHOUT a Rust toolchain or a GPU: not compiled, not run; +1 test `gpu::pipeline::tests::chunk_shader_validates_and_legacy_is_forward` not run; numbers are from the OPPO A5i video `Record_2026-10-12-14-58-18.mp4`: 633 frames in 26.2 s, 41 ms average, 11 frames over 100 ms, FPS counter 16..43):
    - Symptom, measured on the video: in ~85 of 633 frames most of the TERRAIN is black while the sky and the HUD are right; 2 frames are black through the whole scene area. Several of them show a lit screen-aligned rectangle (a block of tiles) inside the black, which is how a GPU tile that was not flushed / finished before it was read looks, not a NaN (a NaN in the post chain would blacken the sky too: the post chain was ruled out).
    - Cause (UNVERIFIED on a device: it is the only pass pair in the legacy frame where a full-screen pass reads what an earlier pass just wrote): `fs_main` wrote albedo + a packed light value into an RGBA16F G-buffer, `copy_depth` copied the depth, and `fs_deferred` (full screen) read both back. Where its read raced the tile writes, the G-buffer reads as 0 = black albedo (cleared to transparent) under a depth that says "terrain".
    - Fix: in legacy `fs_main` lights and fogs the texel itself (`photon_light` legacy branch, face 6, then `apply_fog`: the same maths `fs_deferred` did, so the picture does not change) and `lib.rs` draws terrain, items and outline straight into the scene pass (`draw_opaque`), then the sky (LessEqual: only the pixels still at depth 1), then water. Gone from the legacy frame: the G-buffer pass, `copy_depth`, the full-screen deferred pass, and the shaft march's first frame. The Photon look (`LEGACY = false`) keeps its G-buffer path unchanged.
    - Cost: also one full-resolution RGBA16F write + read, one depth copy and one full-screen shading pass fewer per frame. `post.rs`: with `Settings.taa` off the TAA pass only copied the scene, so it is skipped (`draw`) and the bloom / grade read the scene directly (`targets`: `frame`).
    - Not touched, and the likely next cost on a phone: chunk generation, populate, light and meshing run on the render thread (see Performance notes); the FPS log line's CPU ms/frame says whether a run is CPU-bound. Levers: `RENDER_SCALE`, `RENDER_DIST`, `AUTOSAVE_CHUNKS`, the 10 ms light budget in `world/chunks.rs`.
    - ponytail: `Photon.gbuf` is still allocated in legacy (4 MB at 0.67 scale, unused); delete it with the Photon path when that goes.
- `done` shader pass for the OPPO A5i video (black terrain flicker, dark leaves, no light shafts, ~6 fps). Written WITHOUT a Rust toolchain or a GPU: not compiled, not run; +1 test (`photon::deferred_shader_validates`), `vl` tests changed (`march_is_shafts_only_and_hdr` replaces `lookups_use_photons_shadow_code`). Numbers below are from the video (143 frames in 22.9 s: 160 ms average, 470 ms worst), not from a profiler:
    - Black flicker, root cause in `render/post.wgsl` TAA: `sqrt(m1 - m0 * m0)` (variance clip) rounds to a hair below 0 on flat areas -> NaN, which the old `max0v(history)` did not clear on every driver (it came back one frame later: the strobe). Also `reinhard_inverse` divided by `1 - x` with x >= 1 after the YCoCg clip, and CAS divided 0 / 0 on a black 3x3. Now `sane()` (integer test for the all-ones exponent, survives fast-math) guards the TAA inputs, history and output and the grade input, the variance is `max(.., 0)`, the inverse is clamped to < 1, CAS divides by `max(max_color, 1e-4)`. The deferred pass guards its own decode and output the same way.
    - Dark, flickering leaves: the surface shadow was computed in `vl.rs` at half resolution from a face normal rebuilt from the depth buffer; alpha-cut leaves have noisy depth, so the axis snap picked a wrong face and `n.L <= 0` shadowed them (the TAA jitter made it flicker). Now `photon.rs` `fs_deferred` looks the shadow up at full resolution with the G-buffer's exact face: normal offset of ~1.2 texels (x the distortion factor, more at grazing angles), a 0.15 block depth bias, 4 hardware-bilinear compares rotated by IGN, faded to `get_lightmap_shadows` at the map edge. Deleted from the march: `face_normal`, `view_pos`, the PCSS include and its blocker search (the `shadows::pcss_wgsl` code stays, unused). `Photon::new` / `draw_deferred` take the shadow group.
    - Light shafts: their colour was AstraLex's LDR scale next to a 7x HDR sun. `Params::hdr(light_color)` replaces it with `photon::lighting().light_color * SHAFT_GAIN (0.30) * (1 - 0.8 rain)`; the time-of-day weights are unchanged. The march takes 8 samples (was 10, spacing x1.4 keeps the reach). The shadow cone can no longer black out the frame (its darkening was already capped at `SHADOW_DARK`).
    - Cost: `RENDER_SCALE` 0.67 (`gpu/context.rs`): depth, G-buffer, HDR scene, shafts and the post chain run at the scaled size and `fs_final` upscales (bilinear taps on the output grid + CAS one source pixel apart; `Post::new` / `resize` take the surface size). `ENTITY_SHADOWS` (`lib.rs`) false: no per-frame 1024^2 entity map, no second fetch per tap. The FPS log line now prints CPU ms per frame (without the swap-chain wait): near the frame time = CPU-bound (chunk generation / meshing on the render thread), far below = GPU-bound.
    - UNVERIFIED on a device: all of it. Levers: `RENDER_SCALE`, `SHAFT_GAIN`, `MARCH_STEPS`, the PCF radius / bias in `photon.rs`, `Settings.taa` / `cas`. ponytail: the entity cone umbra still loops up to 8 boxes per full-resolution pixel when mobs are near (`CONE_MAX`); the shadow map is still redrawn on every `mesh_gen` change while chunks stream in.
- `done` milestone 6 of the Photon port: GTAO, water + translucent layer, weather (written WITHOUT a Rust toolchain: not compiled, not run; +3 tests not run: `gtao::shader_text_is_complete`, `water::water_text_and_pack`, `weather::rain_columns_and_gaussian`; the last compares `JavaRandom::next_gaussian` with the JDK value for seed 42 from memory):
    - `render/gtao.rs`: `d3_ao.fsh` + `gtao.glsl` + slerp/catmull-rom/r2, half resolution, temporal accumulation, ping-pong history. Outputs `ambient` (ao, SSS, bent normal xy) and `history_data` (1 - depth, age); `AO_UPSAMPLE_WGSL` is `d4_deferred_shading`'s depth-aware upsample for milestone 1 to paste. Normal rebuilt from depth until the G-buffer exists (marked `ponytail:`). Not wired into `lib.rs`: nothing reads it yet.
    - `render/water.rs`: `gbuffers_all_translucent` water path (Gerstner waves, height variation, parallax, `get_water_displacement` in the vertex stage, texture + edge highlight, `water_fog_simple` absorption, GGX sun/moon highlight, diffuse) into a translucent layer with its own depth + a refraction target, then `c1_blend_layers` (refraction + `scene * (1 - a) + rgb`). Needs a scene colour texture that is not the target (milestone 1's HDR buffer) and a stored opaque depth. Missing, all because the input is milestone 2/3/4/5's: sky and environment reflections, PCSS shadows (uses the pack's no-shadow `pow8(skylight)`), cloud shadows, `common_fog`/analytic fog (uses the chunk shader's terrain fog), Purkinje shift. Sky/ambient colours are uniforms (`Frame`).
    - `render/weather.rs`: `EntityRenderer.renderRainSnow` geometry (same Random draws, quads, alpha, light; radius 5, `FANCY` false) + `gbuffers_weather` shading (slanted rain, `RAIN_OPACITY` 0.25, `SNOW_OPACITY` 0.75, premultiplied) drawn inside the water pass. Support: `JavaRandom::next_gaussian`, `ChunkManager::biomes` / `top_solid`, `Biome::snows` / `rains`, `assets/rain.rgba`, `assets/snow.rgba` (from the jar's `environment/`), `assets/noise.rgba` (photon `noise.png`, `render/noise.rs`).
    - Integration order (milestone 1 owns the frame graph): terrain pass into the HDR target with depth stored; `Gtao::run`; `WaterLayer::update/prepare/begin/setup`, draw water ranges, `Weather::update/draw`; `composite` into the next target. Old `fs_water` / `water_pipeline` in `gpu/pipeline.rs` and the packed water column in `mesh.rs` become dead then.
- `done` Photon rewrite, milestone 5: the post chain (written on a Linux host: `render/post.rs` compiled, its 3 tests pass, the chain ran headless on lavapipe in 4 configurations x 4 frames; the `lib.rs` wiring is NOT compiled, nothing ran on a device; no FPS numbers):
    - `render/post.rs` + `render/post.wgsl` (new, + `assets/noise_b.r8` = `noise.png`'s blue channel for DOF): port of Photon `c2_dof`, `c4_taa_exposure` (TAA with variance + AABB clipping, closest-fragment reprojection, catmull-rom history, off-centre rejection, auto exposure off / simple / histogram), `c5`..`c10` bloom down, `c11` merge, `c12`/`c13` gaussian, `c14`..`c18` up, `c19_color_grading` (bloom mix, exposure, vignette, grade in/out, white balance, tonemap, every operator of `tonemap_operators.glsl` incl. ACES full + fit), `c21_fxaa`, `final` (CAS, dither). `Settings::default()` = `settings.glsl` defaults; the tonemap is ACES full (the pack ships Lottes: `Tonemap::Lottes`).
    - `lib.rs`: the chunk/sky/entity/water pass draws into `Post::scene_view()` with the jittered projection (`Post::jittered`), `vl::composite` now blends into that scene (own pass) instead of the surface, `Post::draw` ends on the surface, the HUD pass draws last (not tonemapped). The depth buffer is now always stored (TAA and DOF read it). `Gpu::resize` is followed by `Post::resize`.
    - Same maths, different plumbing: y-down uv, depth 0..1, Iris' colortex0 flip is two explicit bloom textures with the same read/write order (so photon's quirk that tiles 3 and 1 read the horizontally-blurred copy as destination is kept), exposure is a 1x1 pass (also keeps `centerDepthSmooth`), matrices of `color.glsl`/`aces` are multiplied in f64 and written as literals, `texelFetch` is clamped to the edge. Jitter keeps the pack's `jitter_y / viewWidth`.
    - Not ported: TAAU + `c3_taau_prep` (render scale 1), motion blur `c20`, `BLOOMY_FOG` (needs the fog buffer of milestone 4), debug views. ponytail: sky and the volumetric march use the unjittered camera (<= 0.33 px), the scene is stored in the surface format until the G-buffer milestone makes it HDR (until then `exposure` 1 + ACES darken the old LDR frame), no hand (`HAND_DEPTH` only matches within ~0.11 block), exposure reads the scene before DOF, 20 small passes per frame (first lever for a low-end GPU: `Settings.bloom = false`, then `fxaa`).
    - UNVERIFIED on a device: look and cost; sRGB-surface handling (`final` undoes the hardware encode because the pack writes display-encoded values).
- `done` photon port, milestone 3 of 6: shadows (photon `include/lighting/shadows/{common,distortion,pcss}.glsl` + the distortion of `program/shadow.vsh`; written WITHOUT a Rust toolchain: not compiled, not run, +3 tests not run; the lookup maths was checked in a numpy transcription of the GLSL, see below):
    - `render/shadows.rs` (new): `distortion_wgsl()` (quartic distortion `SHADOW_DISTORTION` 0.85, `SHADOW_DEPTH_SCALE` 0.2, `get_shadow_bias`) and `pcss_wgsl()` (`blocker_search`, `shadow_pcf`, `get_filtered_shadows`, `get_shadow_distance_fade`, `get_lightmap_shadows`, `get_lightmap_light_leak_prevention`) as WGSL; `Shadows` = group 2 (`ShadowU`: `shadowModelView` in scene space, GL `shadowProjection`, light, eye, frame; `noisetex`). photon "medium" profile: `SHADOW_PCF` + `SHADOW_VPS`, no `SHADOW_COLOR` (needs the M6 translucent pass), no `SHADOW_SSRT` (needs the M1 G-buffer): past the map `get_lightmap_shadows`. `assets/noise_b.r8` + `tools/gen_noise.py` = the pack's `noisetex.b` (blue noise).
    - `gpu/pipeline.rs`: `vs_shadow` uses `distort_shadow_space`, stored depth is `z_gl * 0.1 + 0.5`; the comparison sampler is linear (`shadowHardwareFiltering1`); `Uniforms.sh`, `SHADOW_DISTORT`, `SHADOW_BIAS`, `SHADOW_BRIGHTNESS` are gone. `render/camera.rs`: `shadow_view`, `shadow_model_view`, `shadow_projection` (the pack's split of the same box); `shadow_view_proj` is unchanged (culling, `vs_shadow`).
    - `render/vl.rs` (volumetric light kept, only its lookups moved): the march distorts like the shadow pass (`DEPTH_BIAS` = 0.25 block in the new depth units); the surface shadow is `get_filtered_shadows` mixed with `get_lightmap_shadows` by `distance_fade` (as `d4_deferred_shading.fsh`), replacing the hand-made normal offset, slope bias, 4 extra depth taps and the grazing fade (`NORMAL_BIAS`, `SH_RES` deleted). Entity map: `shadowtex0` = min of both depths, `shadowtex1` = min of both compares.
    - Deviations: back-face culling stays (the pack's `shadow.culling = reversed` would erase the sun-facing hull, the mesher drops hidden faces); `frameCounter` is 0 until TAA (M5, const `TAA`); skylight 1, no clouds, no SSS until M1/M4; foliage is still parked by tile in `vs_shadow` (photon's `shadow.fsh` alpha discard + colour output belong with M6); 1024^2 over 64 blocks = the pack's 8 texels per block.
    - Check done off-device: numpy transcription of the GLSL lookups against a rasterised map (per-vertex distortion, back-face culled): flat ground at sun 10..88 degrees and eye offsets, 0..90 blocks: lit 1.000 (min 1.00, no acne); sun-facing wall at 25/35/60 degrees: 1.000; pillar umbra 0.001; with the bias off the same ground is 0.563 lit. UNVERIFIED on a device: that the WGSL compiles (no validator was available), PCSS grain after the 4-tap blur, cost of the half-resolution PCSS on low-end GPUs (`SHADOW_PCF_STEPS_MAX`, `SSS_STEPS`, `SHADOW_VPS` are the levers).
- `done` Photon port, milestone 2 of 6: sky (d0 sky map, d4a sky SH, stars, sun, moon; written WITHOUT an Android build: `render/sky.rs` and both shaders compiled and ran headless on lavapipe, 2 tests pass; `lib.rs` NOT compiled (`ndk-sys` only builds for Android), its 4 edits are read by eye; not run on a device). Photon Shaders by SixthSurge, licence in `LICENSE-PHOTON` (no redistribution on platforms that pay creators, no selling):
    - `render/sky.wgsl` = `atmosphere.glsl` (LUT lookup for sun and moon together, analytic transmittance), `light_color.glsl`, `weather_color.glsl`, `projection.glsl`, `stars.glsl`, the sun and moon of `sky.glsl`, `d0_sky_map`, SH helpers. `render/sky_sh.wgsl` = `d4a_generate_sky_sh`. `assets/scattering.dat` is the pack's `scattering.dat` unchanged (RGB16F, padded to RGBA at load), `assets/noise.rgba` its `noise.png` (`tools/gen_noise.py`).
    - `render/sky.rs`: `SkyRenderer::encode` (sky map 192x108 rgba16f, light/ambient colour in column 191, then the SH) before the scene, `draw` over every pixel still at depth 1 after the opaque draws. `params` turns mc-rs's sun angle into the pack's uniforms (`sunAngle = fract(angle + 0.25)`, rising half = `angle > 0.5`, no moon phases in b1.7.3). The vanilla dome, sunrise fan, sun/moon quads, glare and star quads are gone (`world::sky::star_vertices` etc. stay, golden-tested, unused by the renderer).
    - For milestone 1 (d4): `sky::WGSL` is the library (`draw_sky`, `atmosphere_scattering`, `project_sky`, `sh_evaluate_irradiance`), `sky_map`, `sh` (9 coefficients + irradiance up, vec4 each), `bind_group()`/`layout`.
    - Deviations: SH is one 64-thread group of 4 samples (same 256 samples; the pack's 27 KB of shared memory exceeds the 16 KB limit) and goes to a buffer, not column 191. Not in yet: clouds and aurora (M4; aurora is in no milestone), analytic fog over the sky map (M4), rainbow and snow/sand weather colour (M6). `stand_in_tonemap` (fixed exposure + ACES fit) is temporary: delete with M5.
    - Known until M4: terrain fog still fades to the vanilla horizon colour, which differs from the new horizon.
- `done` photon port, milestone 1: G-buffer + deferred lighting into the HDR frame (its own tone map + grade were dropped when M5 landed: `render/post.rs` owns the HDR scene and the swap-chain output; written WITHOUT a Rust toolchain: not compiled, not run; +2 tests in `render/photon.rs` not run, `mesh`/`chunks` tests edited for the new stride). Ported from `photon-main`: `d4_deferred_shading.fsh` (terrain branch), `diffuse_lighting.glsl`, `light_color.glsl`, `atmosphere.glsl` (analytic transmittance, sun+moon LUT mapping, post-processing), `d0_sky_map.vsh` `get_ambient_color`, `c19_color_grading.fsh` (grade_input, `tonemap_lottes`, grade_output, vignette) and the `AUTO_EXPOSURE_OFF` exposure of `c4_taa_exposure.vsh`. `render/vl.rs` is kept: it still marches the shafts and its green channel is now the surface shadow the deferred pass reads; its blend no longer darkens the frame (`res.w` = 0) and is drawn in the HDR pass.
    - Frame: G-buffer pass (terrain, items, outline: albedo + `face * 256 + lm` in an RGBA16F target, depth kept) -> `vl` march (now every frame) -> HDR scene pass (sky, `fs_deferred`, water, shafts) -> tone map into the swap chain under the HUD. `Vertex` gains `lm` (`sky * 16 + block`, raw sky light, `mesh::VF` = 7 floats); `light` stays for water depth. The `lighting()` colours (`light_color`, `ambient_color`, `blocklight_color`, `time_noon`) are computed on the CPU from the pack's `scattering.dat` (`assets/scattering.dat`).
    - Deviations: the sky pass is still mc-rs's (LDR colours in the HDR frame); ambient is the pack's non-SH branch (`ambient_color * sqr(sky)`); no AO, SSS, cloud shadows, bent normals, coloured lights, handheld light; shadow = the half-resolution one from `vl` (no PCSS/SSRT); direct light x `1 - 0.9 rain` stands in for cloud shadows; flat normal from `dpdx`/`dpdy`; items/mobs/outline are lit as sky level 15; fog is still AstraLex's, now applied in the deferred pass and in `fs_water`.
    - Not done (next milestones): 2 sky (`d0`, `d4a` SH, stars), 3 shadows (`d4` PCSS + SSRT), 4 fog + clouds (`d1`, `d2`, `p0`), 5 post (TAA + exposure, bloom, DOF, FXAA, white balance), 6 GTAO, water/translucents, weather. Skipped for good: LPV, Photonics, LoD-mod support.
- `done` shadow cone (rewritten, compiled and rendered headless on lavapipe): the umbra an item or mob throws through the air.
    - `render/vl.rs` `cone_thickness` (in the shaft composite, `LightShafts::set_cone`): for each of the `CONE_MAX` (8) nearest entity boxes the exact path length of the view ray through the volume swept toward the sun (points whose sun ray, up to `CONE_LEN` 10, meets the box), up to the surface behind the pixel; darkening is `1 - exp(-CONE_DENSITY * thickness)` x shadow strength. It replaces the 40-instance stacked-layer draw (`vs_cone`, `CONE_COPIES`, removed): no banding, the mob itself is not darkened, no per-copy fill cost. Ceilings (ponytail): the sun moves in the YZ plane so x is a plain slab (a sun with an x component would need the general form); an axis the sun is within 0.02 of parallel to is treated as a slab; entities beyond the 8 nearest cast none.
- `done` volumetric light visibility: `STRENGTH` 1.0 -> 1.8, and the march's dither now moves per frame (`u.c.z`) so TAA averages it (the same 10 samples act like many). Halo around a low sun and the sunrise wash verified in headless renders.
- `done` frame cost: bloom and FXAA off by default (`post::Settings`), PCSS taps 6..12 -> 3..6 (`shadows.rs`).
- `done` `Gpu::copy_depth`: a per-frame depth copy that photon's deferred pass and the shaft composite read, so no pass samples the depth it has attached (a mobile-driver hazard; the suspected cause of the on-device black rectangles, which do not reproduce headless: UNVERIFIED on a device).
- `done` water depth (written WITHOUT a Rust toolchain: not compiled, not run; the existing `water_has_its_own_indices` test gains 2 asserts, not run): water showed its bed at every depth (flat 0.54 alpha). `mesh::build_split` packs the water column under each water face (cells, <= 15) into the integer part of the vertex `light` (`light * WATER_LIGHT + depth`, no new vertex attribute); `fs_water` unpacks it and uses alpha `max(0.54, 1 - e^(-0.35 d))` blended toward 1 at grazing angles (`graze`), with the colour tinted darker and bluer by the same absorption. UNVERIFIED: constants tuned by eye against a shader-pack screenshot. ponytail: the column is counted straight down, not along the view ray; no sky reflection, no refraction.
- `done` chest storage (host-checked: `chest_screen_clicks_and_layout`, `chests_follow_the_java`, `chests_pick_their_tile_from_the_neighbours`, the extended `chunk_and_level_round_trip` and `populate_matches_java` pass; `lib.rs` not compiled; 3 older tests (`leaves_do_not_shade_like_a_roof`, `table_fills`, `drops_inventory_and_item_physics`) already fail on the uploaded tree, untouched):
    - `world/chest.rs` (new): `BlockChest.canPlaceBlockAt`, `blockActivated` (group order of `InventoryLargeChest`), `getBlockTexture` (read by the mesher per face, so facing needs no metadata), `canInteractWith` (8 blocks, still a chest: the screen closes like `EntityPlayer.onUpdate`), `opaque` = `opaqueCubeLookup` from the Java overrides.
    - `craft.rs`: `SlotId::Chest`, `Screen::at_chest`, `get/set/click/drop_one` take the container's slots as a slice (furnace and chests share it); `layout`/`panel`/`cell`/`slot_at` take `gw` (= chest slot count) for the taller `ContainerChest` panel. `lib.rs` copies the slots out and back (`with_ext`), so a large chest is one slice.
    - Save: `level` ends with the chests; a file without that tail loads with none. Populate: `Region::take_loot` -> `ChunkManager::take_loot` -> chests; `loot` keeps the same draws as before and now returns the stack.
    - Not done: shift-click (`ContainerChest.getStackInSlot`), the 3D chest model (b1.7.3 has none), vanilla's random stack split/motion when a chest is broken (one entity per stack, like furnaces), spill happens on the next 20 Hz tick, `isBlockNormalCube` uses the opacity table (UNVERIFIED for glass-like materials).
- `done` non-full blocks (written WITHOUT a Rust toolchain: not compiled, not run; +8 tests not run: `mesh` x5, `physics`, `pick`, `outline`). Ported from `Block.setBlockBounds` / `getCollisionBoundingBoxFromPool` / `RenderBlocks.renderBlockFluids` / `renderBlockCactus`; one table in `world/chunk.rs` feeds mesher, physics, pick and outline:
    - `chunk.rs`: `box_bounds` (slab 0.5, torch 0.2 x 0.6, farmland 15/16, snow layer 2(1+layers)/16, cactus), `cross_shape` gains the sapling (it was a solid cube), `pick_bounds` / `outline_bounds` (cactus outline inset 1/16), `collision` (slab, cactus inset 1/16 and 15/16 high, fence 1.5, farmland full, fluids/plants/torch/snow none), `opaque` (what hides a neighbour's face). `light_opacity(60)` was 0, the Java and golden `TAB 60` say 255.
    - `mesh.rs`: faces of a box are scaled to its bounds with the matching window of the tile; a face inside the cell is always drawn; only `opaque` neighbours hide faces (water, slab, cactus, farmland, torch no longer hide the stone beside them). Fluids: corner heights as `func_1224_a` (a pool is 8/9, full under more fluid, lower beside air), sides use the flowing tile (206/238), same-fluid and ice hide faces. Cactus sides are pulled in 1/16 (`renderBlockCactus`).
    - `physics.rs`: collision is a box overlap against `collision()`, not the whole cell; standing on a slab / cactus works. `pick.rs`: `ray_trace` takes bounds (`Block.collisionRayTrace`), `overlaps_player` takes the block id (a torch can be placed inside you). `outline.rs` draws the selection box.
    - Flowing fluid tops are turned by the flow direction (`flow_angle` = `getFlowVector` + `func_293_a`, `flow_uv` = the rotated 16 px square of `renderBlockFluids` on the flowing tile 206 / 238). ponytail: vanilla centres the square on a corner of 4 flow tiles; here tile 255 holds birch leaves, so the square is shrunk to stay inside one tile (coarser than vanilla), and a still top keeps the still tile.
    - Water is translucent (written WITHOUT a Rust toolchain: not compiled, not run, +1 test): `terrain.rgba` tile 205 keeps the png's alpha (138 = 0.54; `tools/gen_terrain.py` no longer calls `opaque` on it), `mesh::build_split` puts blocks 8 / 9 in their own index list (`build` keeps its old pair), `Mesh.water` is a second index buffer on the same vertices (sorted by section like the opaque one, `draw_ranges(.., water, ..)`), `ChunkPipeline::water_pipeline` = `fs_water` (no discard, `shade` shared with `fs_main`), alpha blending, no depth write, no culling (the surface shows from below), drawn after the terrain and the items, before the outline. Water no longer casts shadows (the shadow pass reads the opaque indices only). Lava and ice stay opaque.
    - ponytail: water chunks are not sorted back to front (two water chunks in one line blend in map order, nearly invisible: same colour); the light shafts' march reads the terrain depth, so a shaft behind water is not dimmed by it; no underwater fog.
    - Fluid on a chunk seam (written WITHOUT a Rust toolchain: not compiled, not run, +1 test `flow_reads_the_neighbour_chunk_levels` not run): `build_split` takes the 4 side neighbours' `Nibbles`; `fluid_heights` / `flow_angle` read levels through one `meta` closure (this chunk or a neighbour), so a flowing cell across a seam is no longer read as a source. ponytail: the diagonal chunk at a 4-chunk corner is still skipped.
    - Step-up (written WITHOUT a Rust toolchain: not compiled, not run, +1 test `a_slab_is_stepped_up_a_full_block_is_not` not run): `physics::sweep_axis` takes `grounded`; a grounded box blocked on x or z whose box raised `STEP` (0.5, `stepHeight`) is free climbs, then settles on the surface below (`snap`), so a slab needs no jump. One shared function, so the player and every mob (`step_box`) get it; not in a fluid. ponytail: vanilla redoes the whole move raised and keeps it only if it goes further; here the first free raised position wins, and a 0.5 climb is instant (no smooth rise). Verified against the decompiled source: `Entity.stepHeight` = 0 (line 47), `EntityLiving` sets 0.5 (line 67; the player and every mob inherit it), only `EntityOtherPlayerMP` resets it to 0; `Entity.moveEntity` (lines 341-405) does the raised retry and keeps it only if it moves further, as described above.
    - Snow layer collision (written WITHOUT a Rust toolchain: not compiled, not run, +1 test `snow_collides_from_three_layers` not run): `BlockSnow.getCollisionBoundingBoxFromPool` is a 0.5 high box from `meta & 7 >= 3`, none below. `BlockQuery` carries ids, so `chunk::physics_id(id, meta)` turns such a layer into the pseudo id `SNOW_DEEP` (255) that `collision` maps to the box; `lib.rs` applies it in the player/mob query and the drops query (the one place each is built). ponytail: a pseudo id instead of metadata in `BlockQuery`; upgrade = make the query return (id, meta). Other callers of `collision` (placing, items) see the real id.
    - Torches, fence, stairs, crops (written WITHOUT a Rust toolchain: not compiled, not run; +3 tests not run: `mesh` x2, `pick` x1; the torch part is the uploaded `torches-on-latest.patch` ported onto this tree, the shapes are read from the decompiled `RenderBlocks` / `BlockStairs` / `BlockFence`):
        - Wall torches: `mesh::push_torch` (stick + head quads, leaning 0.4 off the wall, full bright), `pick::torch_meta` (facing from the face aimed at, else the first support -X, +X, -Z, +Z, floor; no support = no placement, `lib.rs` places through it), `pick::torch_stays` (`ticks.rs` drops a torch that lost its wall or floor), `chunk::normal_cube` (what holds it; a fence holds it from below), pick box / outline by metadata in `box_bounds`.
        - `mesh::shapes`: one table of boxes per block, drawn by the existing face loop: stairs (`renderBlockStairs`: step + riser, metadata & 3), fence (`renderBlockFence`: post, two bars per axis that has a fence neighbour, a 2/16 stub when it has none; only the same block id connects, as in the Java). Crops: `mesh::push_crops` (`func_1245_b`: 4 quads at 1/4 and 3/4, sunk 1/16, tile 88 + growth stage), pick box 0.25 high, no collision (it was a full cube). Stairs, fence and crops no longer hide the faces beside them (`opaque`).
        - Not done: doors and bed (two-cell blocks: open/close, placement, sleeping; no item or recipe makes them), stairs collision (still one full cell: `BlockStairs.getCollidingBoundingBoxes` is two boxes, which needs multi-box collision and metadata in `BlockQuery`, see the snow ponytail), stairs placement facing (`onBlockPlacedBy` from the yaw) and the stairs/fence/crops items and recipes: nothing in the game can place a stair or a fence yet, so those shapes are only seen once the recipes land.
- `done` entities cast shadows: dropped items, mobs and falling blocks (written WITHOUT a Rust toolchain: not compiled, not run; the vl.rs test gains one assert, not run; no FPS numbers):
    - Before, only chunk meshes were drawn into the shadow map, so nothing that moves threw a shadow. `gpu/pipeline.rs`: a second `Depth32Float` map `ent_view` (same size, same `shadow_vp`, bound as binding 2 of the shadow group). `lib.rs`: an `entity_shadow_pass` draws the whole item buffer (`item_mesh`, all entities) into it with `shadow_pipeline`, EVERY frame, because the terrain map is cached (`ShadowCache`) and a walking mob would leave a trail in it; it is cleared once more after the last entity is gone (`ent_shadow_dirty`; starts true because a fresh depth texture reads 0 = all shadow).
    - `render/vl.rs` `fs_march`: the surface test samples both maps with the same lookup point and bias and is lit only if both say lit (`min`). The light-shaft march does NOT read it: a 0.25 block volume is far below what 10 samples over 64 blocks can resolve (tried, no visible volume), so the umbra in the air is drawn as geometry instead, see the next entry.
    - Consequences (UNVERIFIED on a device): the entity map is drawn at the terrain map's resolution and distortion, so a 0.25 item shadow is a few texels near the eye and blocky far away; the entity pass costs a 1024^2 clear every frame while any entity exists; foliage tiles are skipped by `vs_shadow`, so a dropped sapling or flower casts nothing. ponytail: no culling of the entity draw; items are flat full-brightness cubes, so their own sun-lit faces are shaded only by the map.
- `done` FIX acne everywhere + sun-facing faces going dark when the player walks up (written WITHOUT a Rust toolchain: not compiled, not run; +1 test `surface_bias_pulls_the_reference_toward_the_sun` not run; the margins below come from a 2-D Python model of `fs_march`'s lookup, not from a device):
    - Root cause, one character in `render/vl.rs` `fs_march`: the surface lookup ADDED its depth bias (`c.z * 0.5 + 0.25 + bias`). The sampler is `LessEqual` (lit when ref <= stored) and a point nearer the sun has the smaller depth, so a positive bias pushes the reference away from the sun and every face into its own shadow. Now `- bias`. The line that was meant to help, the normal offset, only pulls the reference toward the sun by `texel x n.L`; the bias's 0.05 block floor outweighed it wherever the map's texel is < ~0.12 block (`distort()` makes texels small near the map centre, which is the eye within 4 blocks, see `ShadowCache`). That is one cause for both reports: a sun-facing dirt wall self-shadowed inside ~11 blocks of the centre and was lit beyond it (dark as you approach), and flat faces had a negative margin at every distance (acne). With the minus sign the modelled margin is positive for every n.L in 0.02..1 and every distance 0..63 (texel quantisation only).
    - The grazing fade of `vl-grazing-acne-followup.patch` stays, but its premise ("no bias fixes its acne") was the sign bug. Its real job is the ceiling now marked `ponytail:` in the shader: `distort()` is per vertex, so over a 1-block face the shadow depth is interpolated in distorted screen space and errs by ~0.02 block x tan(angle) within ~2 blocks of the map centre; below n.L ~0.3 that beats the bias. If acne is gone on a device, narrow or delete the `smoothstep(0.05, 0.3, nl)` line (the ground then stays bright to a lower sun).
    - Not touched: the shaft march's own lookup (`+ u.light.w`, `DEPTH_BIAS`) samples points in air, where no surface can shadow itself; only the surface test had the wrong sign. `gpu/shadow_test.rs` is not in `gpu/mod.rs` and tests the deleted chunk-shader lookup; it never runs.
- `done` FIX tree shade + stripes on dirt in the light-shaft pass (written WITHOUT a Rust toolchain: not compiled, not run; +1 test `leaves_do_not_shade_like_a_roof` not run, -1 test `pillar_casts_a_shadow_away_from_the_sun` with the code it tested):
    - Dark blocky square under a tree = vanilla sky light: leaves have `Block.lightOpacity` 1, so every cell under a canopy lost one sky level per leaf, flat per face, and the shadow map then darkened the same spot again. `render/mesh.rs`: `bright` now takes a cell as open sky (15) when only air, plants and leaves lie above it (`open`), so the canopy's shade comes from the shadow map alone. A stone roof still dims it. The light engine itself is untouched (mob spawning, grass and the golden tests still see vanilla light); only the drawn brightness changes.
    - Deleted the baked shadow ray that this replaced and that nothing could reach any more: `mesh::build`'s `sun` argument, `occ`, `solid`, `skyl`, `NO_SUN`, `ChunkManager::set_sun` + its field, `sky::sun_key`.
    - Diagonal stripes on dirt (and the lit/dark bands on grass edges) = shadow acne in the surface shadow of `render/vl.rs`: the pass had no normal, only a flat 1-block bias, and the shadow pass culls back faces, so a face turned away from the sun, or parallel to it (every X face: the sun moves in the YZ plane), was compared against a depth that is not its own. Now `fs_march` rebuilds the face normal from the depth buffer (`face_normal`, nearer neighbour per axis, snapped to an axis because every face is axis aligned); `n.L <= 0` is shadowed outright (like the old `N.L`), a lit face looks the map up `NORMAL_BIAS` (1) texel along its normal with a depth bias of 0.05 block + texel x slope (slope capped at 4). A texel's size in blocks follows `distort()` (0.0125 at the eye, ~1.5 at the map edge), so the bias scales with the distance. `SURFACE_BIAS` is gone.
    - Consequences (UNVERIFIED on a device): X faces and every face turned from the sun now take the full `SHADOW_DARK` (0.55): lower it if the shaded sides look too heavy; a pixel on the edge between two faces can pick the neighbour's normal (a 1-pixel line, blurred by the composite); the normal costs 4 extra depth taps per shadowed pixel at half resolution.
- `done` TEMPORARY reset-world button (written WITHOUT a Rust toolchain: not compiled, not run, +1 test `reset_needs_two_taps` not run): a dark-red button under resume in the pause menu (a hollow square: the HUD has no text). The first tap arms it (bright red), the second confirms; resuming or pausing again disarms it. `App::reset_world` deletes the save folder, builds a new `ChunkManager` for `SEED` (the seed's terrain, no edits), preloads, finds the spawn, and resets player, camera, time, weather, inventory, health, mobs, drops, furnaces, block updates and the shadow cache. ponytail: preload runs on the render thread (a short freeze). Remove it with the M14 menu: `PointerRole::Reset`, `LayoutRects.reset`, `TouchUi.reset*`, the HUD block under the resume button, `App::reset_world`.
- `done` shadows moved from the chunk shader into the volumetric pass, and darker (written WITHOUT a Rust toolchain: not compiled, not run; no new test: the shader math needs a GPU, and `gpu/shadow_test.rs`, which tested the chunk shader's lookup, is deleted):
    - `gpu/pipeline.rs`: `fs_main` no longer reads the shadow map (no normal from derivatives, no `N.L` term, no lookup): texture x vertex light, then fog. The map is still drawn (`vs_shadow`) for the volumetric pass.
    - `render/vl.rs`: the half-resolution march also looks up the shadow map at the pixel's own depth (+ `SURFACE_BIAS` ~1 block along the light) and writes it to the green channel; the composite blurs it with the shafts' 4 taps and darkens the frame by `dark = shadow x SHADOW_DARK (0.55) x sun strength` through the existing blend (`a = 1 - (1 - k)(1 - dark)`, glow unchanged). The old shadow darkened 25%. `Params.shadow` is set from `sky::shadow_strength` in `lib.rs`, so no shadow at night or in rain, as before.
    - Consequences (UNVERIFIED on a device): shadow edges are as soft as the half-resolution target (blur + depth-edge bleed); faces turned away from the sun are no longer darkened by `N.L` (only the baked 0.5/0.6/0.8 face shades remain); no shadows under water (the volumetric pass is off there); acne on grazing ground depends on `SURFACE_BIAS`; tune `SHADOW_DARK` / `SURFACE_BIAS`.
- `done` render shape + vertical distance + per-section draws (written WITHOUT a Rust toolchain: not compiled, not run, +1 test `render_shape_and_sections` not run; no FPS numbers):
    - `world/chunks.rs`: a chunk's indices are sorted by 16-block section (`by_section`, one counting pass at mesh time, same vertex buffer). `ChunkManager::draw_ranges` tests each section's box (one block taller each end) against the render shape and the frustum, merges touching sections into one `draw_indexed` range, skips empty ones. Before, one 128-tall box per chunk decided everything.
    - `Shape::Cylinder` = circular horizontal distance (exact in blocks from the eye to the section box, not just the chunk ring); `Shape::Sphere` = 3D distance <= the same radius (the terrain fog is by 3D distance, so the cut-off hides in it). Both are capped by `RENDER_VERT` (3 chunks) above and below the eye. `lib.rs`: `RENDER_SHAPE` (Sphere), `RENDER_VERT`; no settings screen yet (M14).
    - Loading, light and the shadow pass are unchanged (the shadow pass still draws whole meshes in its 64-block box). ponytail: sections out of range still cost memory; far above or below the eye the fog does not hide a vertical cut-off (the fog colour is the horizon's).
    - UNVERIFIED: that it compiles; FPS gain on a device; a face on a section border may sit in the neighbouring section, covered by the one-block margin.
- `done` render cost pass for shadows + light shafts + sun glare (written WITHOUT a Rust toolchain: not compiled, not run, +1 test `shadow_cache_redraws_only_when_stale` not run; no FPS numbers):
    - Shadow map is cached (`render::camera::ShadowCache`): it was redrawn every frame, all chunks in a 128-tall box. Now it is redrawn only when the eye moved > 4 blocks, the light turned > 0.5 degrees, a mesh changed size / an unload happened (`ChunkManager::mesh_gen`), or it was unused the frame before. Between redraws the terrain and the shafts read it with the matrix + light it was drawn with (`upload_uniforms` takes the cached centre), so nothing swims.
    - Shadow pass culls back faces (the mesher drops hidden faces, so the depth map is the same).
    - Light shafts: `shadow_vp * inverse_view` is one CPU-side matrix (one mat4 per sample, was two), `pow(t, 1.5)` is `t * sqrt(t)`; the blend (`LightShafts::composite`) now runs inside the HUD pass, saving one full-screen load/store of the frame. The chunk pass discards its depth when the shafts are off.
    - Sun glare: the quad's half-size 200 -> 90 (`GLARE_R`): the alpha is < 2% past ~40 degrees, and the quad is drawn over the whole sky before the terrain covers it, so it shaded ~5x more pixels than it showed. Terrain fog is left as is (a `length` + smoothstep per pixel, only past 0.6 x far).
    - ponytail: a mesh rebuilt with the same index count (the time-of-day relight) does not refresh the map; an edit that keeps the count shows at the next sun / movement refresh (<= ~2 s). Levers left, in order: `SHADOW_RES` 1024 -> 512, 10 -> 6 march samples in `fs_march`, march at quarter resolution, no moon shafts (`Params.active` only for the sun), a render scale below native.
- `done` FIX black screen from the entry below: the glare branch of the sky shader used the Rust constant `GLARE` inside the WGSL text (no such name: shader compile failed, init panicked, the frame stayed black) and sampled the texture after a branch on a varying. The glare is now its own entry point `fs_glare` and pipeline (`glare_pl`) in `render/sky.rs`, `GLARE` is substituted into the source (`@GLARE@`). Terrain fog (`gpu/pipeline.rs`) was read and is valid WGSL. Still not compiled or run here.
- `done` terrain fog + sun glare (port of AstraLex `NormalFog` / `sunGlare.glsl`; written WITHOUT a Rust toolchain: not compiled, not run; +1 assert in `sky.rs` tests):
    - `gpu/pipeline.rs`: `fs_main` fades to the horizon fog colour (`sky::fog_color`, also the clear colour and the dome's fog) by `1 - (far - d) * 5 / (density * far)`, smoothstepped; `far` = `RENDER_DIST * 16`, density 2.0 (+50% per unit of rain), off under water. `ChunkPipeline::set_fog` writes the new `fog`/`fogp` uniforms (called from `lib.rs` after `upload_uniforms`).
    - `render/sky.rs`: a glare quad (alpha blend, before the sun) shaded per pixel by `VoL^8` as in `sunGlare.glsl`, warm `lightCol`, faded by `sunVisibility` and rain.
    - Not ported: the pack's exponential fog term (about 0.4% at 64 blocks in clear weather), `GetFogColor` (HDR; the existing vanilla fog colour is used), glare over terrain (the pack adds it to the whole frame; here the sky pass draws it, so terrain hides it), underwater fog.
    - UNVERIFIED: `GLARE` (1.2) and density 2.0 look on a device.
- `done` volumetric light (port of AstraLex `volumetricLight.glsl` + the `LIGHT_SHAFT` part of `composite1.glsl`; written WITHOUT a Rust toolchain: not compiled, not run; +3 tests in `render/vl.rs` not run, their numbers come from a line-by-line Python transcription of the GLSL):
    - `render/vl.rs` (new): `params()` = every per-frame scalar of the pack (`lightCol`, `sunVisibility`, `shadowFade`, `lightShaftTime`, rain/night multipliers, `endurance`, `vlPower`), CPU side, pure. `LightShafts::draw` = two passes after the terrain, before the HUD: a half-resolution march (10 samples, `pow(i + dither + 0.714, 1.5) * minDistFactor`, fov falloff, `sqrt(vl * visibility)`) through the sun's shadow map into an RGBA8 target, then a full-screen pass (4-tap blur, square, `NdotU` direction term, colour, additive/mixed blend) with blend `rgb + dst * (1 - a)`.
    - `lib.rs`: the shadow pass now also runs while the light is above the horizon (the sun at sunrise/sunset/rain, the moon at night: `lightVec` flips at timeAngle 0.5325 / 0.9675 like the pack), with that light as the pass's direction; the terrain still takes its shadow only from `sun_strength`. `gpu/context.rs`: the depth texture is also a texture binding. `gpu/pipeline.rs`: `SHADOW_DISTORT` and `shadow_layout` are public.
    - Deviations (all in the file header): `InterleavedGradientNoise` instead of blue noise, mc-rs's own shadow lookup (distort + depth) and a march that ends at `SHADOW_RADIUS` (outside the map a sample counts as lit), no coloured shadows, `DEPTH_BIAS` ~0.25 block. `LIGHT_SHAFT` / `STRENGTH` in `vl.rs` stand for the pack's `#define`s.
    - Not ported: underwater shafts (off while the eye is in water), `SMOKER_LIGHT_SHAFT` (needs `noise.png`), End shafts, cave fade (the pack's `isEyeInCave` is 0 above y = 5).
    - UNVERIFIED: brightness on a device (the pack's numbers assume its HDR scene + tone map; if the glow is too strong lower `STRENGTH`), cost of the march on low-end GPUs (half resolution is the first lever, then fewer samples), and the second shadow pass at night.
- `done` real block textures (written WITHOUT a Rust toolchain: not compiled, +1 test and 1 changed test not run; `tools/gen_terrain.py` ran, its tiles were looked at):
    - `assets/terrain.rgba` = the real `terrain.png` (256x256, from the jar) with the biome tint baked in: grass top, tall grass, fern, reeds x the grass colour, leaves x the foliage colour,
      spruce 0x619961, birch 0x80A755 (own tile 255, the png has no birch leaf tile); water, lava and ice made opaque. Climate is one fixed point (temperature 0.8, rainfall 0.4).
    - `render/atlas.rs`: the atlas texture is 256 x 288, the png on top and under it the old flat-colour strip (items, mobs, falling blocks and blocks without a tile keep it).
      `terrain_tile(id, meta, side)` = `getBlockTextureFromSideAndMetadata` of the blocks the world has (grass, log, leaves, sandstone, cactus, furnace, workbench, pumpkin, wool,
      slabs, tnt, ...); `face_uv` picks it per face (the mesher's face order -> the Java side), `terrain_uv` insets a hair so Nearest never reads the next tile.
    - `render/mesh.rs`: faces use `face_uv`; plants are full-height 0.9-wide crossed quads (`renderCrossedSquares`) with the cut-out texture (`cross_shape` still sizes pick and collision).
    - `gpu/pipeline.rs`: the shader drops texels with alpha < 0.5 (plants, glass); the shadow pass finds foliage by terrain tile (`PLANT` is built from `terrain_tile`).
    - Not done: biome tint per block (needs a colour vertex attribute), grass side overlay (tile 38), animated water/lava/fire, translucent water/ice/glass, mipmaps (distant tiles shimmer), furnace/pumpkin/chest
      facing (front is always +Z until metadata carries it), item sprites and mob/GUI textures (M14).
- `done` M6b block updates (`world/ticks.rs`, hooks in `world/chunks.rs`, `world/gen/populate.rs`, `render/items.rs`, `lib.rs`; written WITHOUT a Rust toolchain: not compiled, not run, expect a compile fix or two; no new tests yet):
  - `ChunkManager` logs every notifying write (`set_block` / `set_block_meta`: x, y, z, old id, new id); `set_quiet` is the `setBlockAndMetadata` / `setBlockMetadata` write that does not. `Ticks::step` (20 Hz, next to the furnaces) runs the scheduled
    ticks (`TickUpdates`: BTreeSet by due time, dedup set, <= 1000 per tick, skipped unless the cell's +-8 area is loaded), then 80 random ticks per lit final chunk within 9 chunks with the Java LCG (`World.tick`), then replays the log:
    `onBlockAdded`, `onBlockRemoval`, `onNeighborBlockChange` of the six neighbours, until it is empty.
  - Water/lava: `BlockFlowing.updateTick` (levels, downward flow with +8, sources from 2 neighbours for water, lava creeps 2 levels and 3 of 4 ticks held back, `calculateFlowCost` / `getOptimalFlowDirections`), `BlockStationary` waking up,
    `checkForHarden` (obsidian / cobblestone), tick rates 5 / 30. Items in the way drop (water only).
  - Sand, gravel: schedule 3 ticks, `EntityFallingSand` as `ticks::Falling` (gravity 0.04, drag 0.98, <= 64, drawn as a 0.98 flat box), lands or drops as an item.
  - `BlockLeaves` decay (bit 8, 4 steps from a log, `onBlockRemoval` of logs +-4 and leaves +-1 sets the bit), `BlockSapling` (bit 8 then `growTree` through `populate::grow_sapling` on a 2x2 chunk `Region`; the 4 chunks are re-lit),
    `BlockFlower.canBlockStay` for flowers, tall grass, dead bush, mushrooms, crops (they drop and vanish), `BlockGrass` spread/death, `BlockCrops` growth + `getGrowthRate`, `BlockFarmland`, `BlockReed`, `BlockCactus`.
  - Not ported: fire (lava does not ignite), mushroom spread, snow/ice, rain wetting farmland, falling sand when chunks are far (vanilla drops it instantly), trampling farmland, saving pending ticks (vanilla does not).
  - UNVERIFIED: mushroom `canBlockStay` light limit (only the opaque ground is checked), the `Block.tickOnLoad` list was read from the `setTickOnLoad(true)` calls.
- `done` real-time shadows (port of shaderLABS/Shadow-Tutorial, written on a Linux host: `render::camera`, `world::sky` and `gpu::pipeline` compiled and tested there (14 tests, incl. a headless lavapipe render, `gpu/shadow_test.rs`); `lib.rs` edits NOT compiled; not run on a device):
    - `gpu/pipeline.rs`: shadow map `Depth32Float` 1024^2 + comparison sampler (group 1), `vs_shadow` (= `shadow.vsh`: `distort()`, foliage parked off-screen via a tile bitmask built from `chunk::is_plant`), `fs_main` (= `gbuffers_terrain.fsh`: face normal from position derivatives, `SHADOW_BRIGHTNESS`, `sqrt(N.L)` lit mix, strength fade). `camera::shadow_view_proj` (ortho 64 blocks around the eye), `sky::sun_dir` / `shadow_strength`; `lib.rs` runs the extra depth pass only while the strength is > 0 (never at night or in rain).
    - Replaces the baked shadow ray: `lib.rs` no longer calls `set_sun`, so `mesh::build`'s `occ` code, `ChunkManager::set_sun` and `sky::sun_key` are dead and can go.
    - Not ported: colored shadows (no translucent pass yet: glass and water are opaque cubes) and `SHADOW_DISTORT_ENABLED`/`COLORED_SHADOWS` toggles. Block light is not exempt from shadow (the vertex `light` merges sky and block light, the pack only darkens the sky part).
    - Deviation: `NORMAL_BIAS` offsets in blocks (one texel of the distorted map x `SHADOW_BIAS`); the pack's offset is 1/R of that and left flat ground full of acne in the test.
    - UNVERIFIED: 64-block radius, 1024 map and the 37-degree test scene on real hardware; cost of the second pass on low-end GPUs (Back-face culling in the shadow pipeline is the first thing to try).
- `done` all overworld mobs (written WITHOUT a Rust toolchain: not compiled, 3 tests in `mobs.rs` not run; `tools/gen_names.py` now also writes `RESIST`):
    - `world/mobs.rs`: the pig's `Pig` became `Mob` + `Kind` with `spec` = (`setSize`, health, `moveSpeed`, `attackStrength`): Pig, Cow, Sheep (`getRandomFleeceColor`),
      Chicken (egg every 6000..12000 ticks, `motionY x 0.6` fall), Wolf (neutral until hit), Squid (`EntitySquid` swim vector), Zombie, PigZombie (400..800
      ticks of anger, 0.95 speed), Giant (6x zombie), Skeleton (`attackEntity` arrows every 30 ticks, `EntityArrow` 4 damage), Creeper (30-tick fuse at 3 blocks,
      `Explosion.doExplosionA` rays, power 3, resistance = `RESIST`/hardness x 5, /5), Spider (leaps at 2..6, gives up in light, climbs walls), Slime (size
      1/2/4, health size^2, hops, four halves on death, damages only above size 1). Melee is `EntityMob.attackEntity` (dist < 2, 20 ticks apart). Zombies and
      skeletons catch fire in sun (`onLivingUpdate`, 1 damage a second). Loot = `getDropItemId` x `rand(3)` (skeleton arrows + bones, sheep 1 wool of its colour,
      squid 1..3 ink, slime balls at size 1). Despawn = `func_27021_X`.
    - Spawning (UNVERIFIED, not `SpawnerAnimals`): animals on lit grass every 400 ticks + a burst at start (cap 12; sheep 12, pig 10, chicken 10, cow 8), monsters
      every 40 ticks in the dark (`light <= rand(8)`, cap 10; slimes only in `func_997_a(987234911)` chunks below y 16), squid in water y 46..62 (cap 3), 24..48
      blocks from the player.
    - `Chunks::light` (= `World.getBlockLightValue`), `lib.rs`: `Ctx`/`Ev` hooks (`Hurt` -> `Vitals.hurt`, so armor works; `Boom` -> `App::explode`: blocks
      cleared, 30% drop, player damage), tap-to-hit now for every mob (`Mobs::hit`).
    - `render/items.rs`: `parts` = the b1.7.3 models (`ModelQuadruped`, `ModelBiped`/`ModelZombie`/`ModelSkeleton`, `ModelCreeper`, `ModelChicken`, spider, squid,
      wolf, slime from memory) as flat wool-coloured boxes (red when hurt, white fuse flash); arrows are small boxes.
    - Not done: Ghast and the zombie-pigman spawn (M11), wolf spawning (needs biomes), taming, shearing, milking, saddles, A*, sounds, saving mobs, explosion
      exposure/knockback, arrows sticking in blocks, a skeleton/spider jockey, the textures (M14).
- `done` cheap table fills (written WITHOUT a Rust toolchain: not compiled, `table_fills` test not run; `craft.rs`, `items.rs`, `vitals.rs`, `lib.rs`):
    `RecipesDyes` (shapeless, `ShapelessRecipes.matches`: `Recipe.w == 0`), `RecipesIngots`, `RecipesArmor` (all 20 pieces; chain wants fire), cookie, bucket;
    food `heal_amount` for apple, bread, golden apple, fish, cookie; raw fish smelts; lava bucket burns 20000 and leaves an empty bucket;
    buckets stack 1. Armor: `Inventory.slots` is 40 long (36..40 = `armorInventory`, helmet at 39), `SlotArmor` rules in `Screen::armor_ok`,
    `Vitals.armor` / `absorb` = `EntityPlayer.damageEntity` (25ths with a carried remainder), worn pieces wear by the damage dealt (`lib.rs`).
    - Save format changed (inventory 36 -> 40 slots): an old `level` file fails to decode and starts a new game.
    - Not done: filling/emptying buckets (no fluid flow), armor model and HUD armor bar, shift-click, a pumpkin stack onto the head (needs a single pumpkin in hand).
    - UNVERIFIED: the mode toggle moved to the top right (152, 8) to clear the armor column; armor tile colours are invented.
- `done` item-name tooltip (written WITHOUT a Rust toolchain: not compiled, +2 tests not run; `tools/gen_names.py` ran and its output was
  spot-checked against `lang/en_US.lang`): `GuiContainer.drawScreen` shows `translateNamedKey(getItemName())` in a 75% black box (3 units of
  padding) for the hovered slot when the cursor is empty. Touch has no hover, so it shows while a finger is down: the stack under it, or the
  picked-up stack (a tap picks the slot's stack up, which would otherwise hide it). `render/font.rs` (generated: `default.png` glyphs +
  `FontRenderer` widths, ASCII 32..126 only), `world/names.rs` (generated: `setBlockName`/`setItemName` + lang), `items::name` (wool, dye,
  slab, charcoal by damage), `HudPipeline::push_text` / `text_width` / `push_tooltip`, hud quad cap 2048 -> 4096.
    - Not done: tooltips in the hotbar/in play (b1.7.3 has none), non-ASCII, text anywhere else (that is M14), item sprites.
    - UNVERIFIED: the tooltip spot (34 units above the finger, below it near the top edge) is invented; vanilla uses mouse + (12, -12).
- `done` sun, moon, stars, sunrise glow and weather (written WITHOUT a Rust toolchain, then compiled and ran on an Android device; the 5 new tests not run; the Java reference
  numbers behind 3 of them were generated from the real classes, `tools/golden/G.java` `sky()`; +5 tests):
    - `world/sky.rs`: `Weather` = `World.updateWeather` (rain/thunder timers on a `java.util.Random`, strengths +-0.01 per tick; started clear, not
      saved, a loaded world starts clear), `skylight_subtracted` / `sky_color` now take the rain and thunder strengths, `fog_color` (horizon colour
      `func_4096_a` mixed with the sky, rain/thunder darkening), `sunrise_color`, `star_brightness`, `star_vertices` (`renderStars`, `Random(10842)`).
      Golden: celestial angle, horizon colour, sunrise glow, star brightness, skylight with weather, 1M ticks of weather for 2 seeds, the star quads.
    - `render/sky.rs` (new) + `assets/sky.rgba`: one pass drawn first in the frame, depth never tested or written, around the viewer (view matrix keeps
      only the rotation, far plane 2 x 128): dome (16 above, fog 0..0.8 x far by distance), sunrise fan (alpha blend), sun 60 / moon 40 wide
      (the real `terrain/sun.png` / `moon.png`, additive, alpha `1 - rain`), stars (additive, brightness `star_brightness x (1 - rain)`), dark plane 16 below.
      The frame now clears to the fog colour, not the sky colour. `lib.rs`: `App.sky`, `App.weather`, `weather_ticks` (whole ticks run, set to the loaded time).
    - ponytail: vanilla draws no sky below NORMAL view distance and mixes the fog by `1 - (1/(4 - renderDistance))^0.25`; mc-rs always draws it with
      NORMAL's numbers (mix 0.24, far 128), though terrain reaches 64. The brightness term of the fog colour (darker in caves) is left out.
    - UNVERIFIED: surface gamma. Colours are written as in vanilla (framebuffer values); on an sRGB surface (wgpu's usual pick) they come out lighter,
      like the old clear colour did. Sun/moon use an sRGB texture like the block atlas.
    - Not done: rain/snow streaks (`renderRainSnow`; `rain.png`/`snow.png` are in the jar), rain particles and sound, lightning (`EntityLightningBolt`)
      and the sky flash, snow layers and ice from weather, clouds, fog on terrain, water/lava fog, the weather is not saved. A new world waits
      12000..180000 ticks (10..150 minutes) for the first rain; to see it sooner, call `weather.tick()` in a loop at start-up until `weather.rain(1.0) > 0`.
- `done` M7 fix: autosave no longer interrupts play every 5 s (compiled and ran on an Android device). `App::save` called `close_screen()`
  unconditionally, and `close_screen` also runs `touch.set_screen(false)`, so each autosave (screen closed) reset the touch state and cut
  the held move stick / look drag / dig. Now `save` closes a screen only when one is open (`lib.rs`, one `if`). Pause and exit saves are
  unchanged (they still turn an open screen into dropped items first).
    - UNVERIFIED: `input/touch_ui.rs` was not in the zip, so that `set_screen(false)` resets the pointer state is inferred from the call
      site, not read. If actions still drop, look there first.
    - Still open: autosave writes the level + up to 24 chunks on the render thread; on a slow phone that can hitch a frame. If so, lower
      `AUTOSAVE_CHUNKS` or move the writes to a thread.
- `done` M7 save (written WITHOUT a Rust toolchain, then compiled and ran on an Android device; tests not run; +2 tests). Decision: it does
  not follow b1.7.3 (no McRegion, NBT, zlib): the aim is fewer lines and a smaller, faster save, not a loadable vanilla world.
    - `world/save.rs` (new): `encode_chunk`/`decode_chunk` = populated flag + run-length-coded block ids + metadata nibbles (runs of
      1..=255), `Level` encode/decode (time, position, spawn, look, hotbar slot, health/air/fire, 36 slots, furnaces, dropped items),
      `write` = temp file + rename, so a kill mid-write keeps the old file. Decoding checks every length, stack size and float and
      answers `None` for anything off (chunk: generated again; level: new game); it never panics.
    - Only chunks that differ from the seed are written: `Entry.dirty` is set by an edit and by `populate` (on all 4 chunks it writes
      into), cleared by a write. Untouched chunks are regenerated, light and height map are recomputed on load. `ChunkManager::with_dir`
      scans the folder once into `saved`; `stream` reads saved chunks (8 per frame) instead of asking a worker; `flush(budget)` writes
      dirty ones; unloading writes a dirty chunk first. `preload(cx, cz)` now takes the centre chunk (it was `lo, hi`).
    - `lib.rs`: the world resumes where the player stood (`Level` -> `App::restore`); a new world still searches a spawn (`find_spawn`).
      Autosave every 5 s of play (level + 24 chunks, skipped with a screen open), and a full save on `Pause` and `TerminateWindow`,
      which matters: `TerminateWindow` drops the whole `App`, so before this a trip to the home screen lost the world. An open screen is
      closed first, so its cursor and grid become dropped items. Folder: `internal_data_path()/world-<seed hex>/` (`c.<cx>.<cz>`, `level`).
      To start a new world, clear the app's data (no menu until M14).
    - This also ends the old ponytail note in `stream` (an unloaded chunk was populated again on return).
    - Not saved: pause state, mining progress, velocity of dropped items (they come back at rest), the sky/light, anything a menu would
      choose. Furnace facing is still lost when a furnace lights (`set_block` clears metadata).
    - Known ceiling: a hard kill (not a normal pause/exit) can lose up to 5 s of play, and can leave a chunk border with a tree cut off
      if a populated chunk was written before its neighbour. Chunk writes and reads run on the render thread (a few small files per frame).
    - Tests: `chunk_and_level_round_trip` (codec, run splitting, every corrupt case), `edits_survive_a_restart` (flush, new manager loads
      it, corrupt file forgotten).
- `done` M13 frustum culling (host-checked: type-checks, 48 tests pass; compiled and ran on an Android device; the FPS gain is still unmeasured):
    - `render/camera.rs`: `Frustum::from_view_proj(proj * view)` takes the six planes (Gribb-Hartmann, depth 0..1 so the near plane is row 2),
      `intersects_aabb` is the usual conservative test against the corner furthest along each plane normal. Test covers ahead, behind,
      sides, above/below, past the far plane, the camera inside a box, the wide 2:1 shape and a 90 degree turn.
    - `world/chunks.rs`: `meshes_where(visible)` yields the meshes whose box (16 x `H` x 16 at the chunk key) passes the test. `lib.rs` draws
      only those. Only the terrain draw is culled: dropped items, the outline and the HUD are tiny.
    - Not done on purpose: tightening the box to each chunk's real height (it is the full 128), occlusion culling, greedy meshing, a profiler.
      Culling also trims only draw calls and GPU vertex work; chunk meshing and generation still run for the whole ring.
- `done` sword, hoe, shears (host-checked like M6: crate type-checks, 47 tests pass, compiled and ran on an Android device):
    - `craft.rs`: swords (ids 267/268/272/276/283, 1.5x on everything, 15x and harvest on web, 2 wear per block), hoes (290..294, no wear
      from digging, 1 per tilling), shears (359, 238 uses: 15x and harvest on web, 15x on leaves, 5x on wool, wear only on leaves and web).
      Recipes `RecipesWeapons` x 5, hoe x 5 from `RecipesTools`, shears from two iron ingots. Wear is `wear_on_break(held, block)`.
    - `lib.rs`: a hoe tills dirt, or grass with air above and not from below, into farmland (60) and wears 1 (`ItemHoe.onItemUse`);
      shears on leaves drop the leaves block itself (`BlockLeaves.harvestBlock`) via `Drops::spawn_stack`.
    - Not done: farmland reverting to dirt, its 15/16 height, crops (so a hoe only makes farmland), sheep, bow and arrow.
- `done` mushroom stew + eating (`world/items.rs`, `world/craft.rs`, `world/vitals.rs`, `lib.rs`; written WITHOUT a Rust toolchain, then compiled and ran on an Android device; tests not run, +1 test and extra asserts):
    `ItemFood.onItemRightClick` / `ItemSoup`: a tap that neither places a block nor opens a workbench/furnace uses the held item (as
    `Minecraft.clickMouse` -> `sendUseItem` does, aimed at a block or not). Food uses up one and `Vitals::heal`s (`EntityLiving.heal`: nothing when dead,
    capped at 20, damage window back to 10); eating at full health still uses it up. Stew (282) heals 10, stacks to 1 and leaves an empty bowl (281).
    Recipes: bowl (3 planks in a V, x4) and stew (red + brown mushroom + bowl, either order). Only the stew is in `heal_amount`; apple, bread, pork, golden
    apple and fish are one line each (ids in the comment) once mobs, crops or chests exist. Not done: eating animation and sound, the hold-to-eat delay
    (b1.7.3 has none: eating is instant).
- `done` health, damage, death (`world/vitals.rs`, `lib.rs`; written WITHOUT a Rust toolchain, then compiled and ran on an Android device; test not run, +1 test):
    `Vitals` = `EntityLiving.attackEntityFrom` (20 health, the 10-tick damage window: an equal or smaller hit inside it is ignored, a bigger one
    pays the difference), `Entity.updateFallState` + `EntityLiving.fall` (`ceil(fall - 3)`, water cancels it), drowning (300 air, then 2 damage every
    20 ticks once it runs out, `isInsideOfMaterial`), lava (4 damage per window + 600 ticks of fire, 1 damage per second while burning, water puts
    it out) and the void (eye below -64). Frame-based fall check, everything else on the 20 Hz tick. `physics::step` now returns (water, lava).
    HUD: 10 hearts above the hotbar, air bubbles while the eye is under water. Death (`App::die`): the open screen and the whole inventory drop where
    he died, the pause menu turns red and its resume button respawns at the first spawn point with full health and a clean `Vitals`.
    b1.7.3 has no hunger and no natural regeneration (only Peaceful heals), so health stays down until food is ported. Not done: suffocation in
    blocks, hurt flash/blink, knockback, burning and hurt sounds, fire overlay, death camera roll, items burning in lava, per-difficulty damage,
    bed spawn, health in the save (M7).
- `done` fluids are not solid + swimming (`world/physics.rs`; written WITHOUT a Rust toolchain, then compiled and ran on an Android device; test not run, +1 test):
    the player used to stand on water and lava because physics treated every id > 0 as solid. Ids 8..=11 are now passable; `step` takes the
    held jump flag and ports `Entity.handleWaterMovement`/`handleLavaMovement` (box shrunk 0.4 top and bottom) and
    `EntityLiving.moveEntityWithHeading`: no gravity in a fluid, vertical drag 0.8 (lava 0.5) and 0.02 blocks/tick sink, held jump +0.04/tick,
    wall hop 0.3/tick when 0.6 higher is free. Simplified: every fluid cell is a source block (flow levels need metadata), horizontal speed is
    scaled to the terminal swim speed (2.0 m/s water, 0.8 lava) instead of accumulating. Not done: no flow push, no splash/bubbles, no breath
    or lava damage (next: health), dropped items still treat fluids as solid.
- `done` block metadata (written WITHOUT a Rust toolchain, then compiled and ran on an Android device; tests not run; the Java side was run). Foundation for wood
  and leaf species, wool colours, slabs, stairs, doors and the bed, so the chunk format does not change again when they arrive:
    - `world/chunk.rs`: `Nibbles` = `NibbleArray` (4 bits per cell, even cell index = low nibble, same index as the blocks), 16 KB
      per chunk, bytes identical to the McRegion `Data` tag (M7 writes `bytes()` as is). `world/chunks.rs`: `Entry.data`,
      `ChunkManager::meta`, `set_block_meta` (= `Chunk.setBlockIDWithMetadata`) and `set_block` (= `setBlockID`: nothing on the same
      id, metadata cleared when the id changes). `render/mesh.rs` reads only its own chunk's metadata.
    - `world/gen/populate.rs`: `Region` carries the 2x2 metadata; `set` clears it like `setBlock`, `set_meta` writes it like
      `setBlockAndMetadata`. Written where the Java writes: birch leaves/logs 2 (`WorldGenForest`), spruce 1 (`WorldGenTaiga1/2`), tall
      grass 1 or 2 (rainforest, `WorldGenTallGrass`), pumpkin facing 0..3. Oak and big trees stay 0. No Random draw changed.
    - Golden: `tools/golden/G.java`'s fake `World` keeps a `NibbleArray` per chunk with the Java setter semantics and prints a `META` line
      (FNV of each chunk's packed nibbles) after every `POP` line. Regenerated: every old line is byte for byte unchanged; 6 of the 11
      cases have non-zero metadata. `populate_matches_java` compares the Rust bytes with those hashes.
    - `world/items.rs`: `damage_dropped(block, meta)` (`Block.damageDropped`), `spawn_block(block, meta, pos)` (lib.rs reads the
      metadata before it clears the cell), `placed_meta` (`Item.getPlacedBlockMetadata`; leaves get bit 8), `stack_tile`; double
      slab drops 2 single slabs (`BlockStep`). `lib.rs` places with `set_block_meta`.
    - `render/atlas.rs`: the atlas is 16x32 (`TILES_W`/`TILES_H`, `gpu/pipeline.rs` follows); tiles 256.. are variants picked by
      `tile_of(id, meta)`: spruce/birch logs and leaves, the 15 coloured wools (`EntitySheep.fleeceColorTable`). Hotbar, inventory and
      dropped items use `stack_tile`, so a red wool stack is red. Log and leaf colours are UNVERIFIED stand-ins until M14 textures.
    - Not done: door/bed shapes (stairs and fence: see the torches entry), rotation on placement (no `onBlockPlacedBy`: furnace and pumpkin facing is stored by worldgen
      only), leaf decay and sapling growth, saving the data (M7), blocks the player cannot make yet (no wool dye or slab recipes).
      Note for M7: `ChunkManager::set_block` clears metadata, so the furnace lit/unlit flip loses the facing once furnaces have one.
- `done` touch spread (fix from a device report: with only tap = left click, a stack could not be split across a grid):
  a picked-up stack floats above the finger (`TouchUi::cursor_pos`), and dragging it over other slots puts one item into each
  slot it enters, the start slot included (`Screen::drop_one`: empty or same item with room, never a swap, never an output
  slot). A press that lifts where it began is still a tap, and the "1" toggle stays. The yellow cursor box is gone. The
  gesture state machine is in `lib.rs` (`on_screen_event`) and only `drop_one` is unit-tested; 47 tests pass, compiled and ran on an Android device.
- `done` furnace + smelting (same host checks as M6: crate type-checks, 46 tests pass, compiled and ran on an Android device):
    - `world/craft.rs`: `Furnace` = `TileEntityFurnace.updateEntity` (fuel used up when the fire starts, 200 ticks per item, output stacks
      to 64, relights from the next fuel without a flip), `FurnaceRecipes` (iron/gold/diamond ore, sand -> glass, cobble -> stone, clay -> brick,
      cactus -> green dye, log -> charcoal) and `getItemBurnTime` (wood blocks 300, stick/sapling 100, coal 1600). `ContainerFurnace` slots and the
      `SlotFurnace` rule: the output takes nothing, right click takes half.
    - `lib.rs`: furnaces live in a map by block position, created on first use, ticked at 20 Hz only while their chunk is loaded; the block swaps
      61 <-> 62 (lit, light 13) when the fire flips. Using a furnace opens its screen (flame and arrow bars). Breaking one spills its three slots.
    - Atlas colours for the new blocks (glass, wool, metal blocks, workbench, furnaces, snow block, glowstone); iron/gold/diamond tools had none.
    - Not done: the furnace contents are not saved (M7), furnace facing (no metadata), fuel/lava bucket, raw pork and fish.
- `done` M6 crafting + tools (written on a Linux host: the whole crate type-checks and its 45 tests pass against a stubbed
  `android-activity`; compiled and ran on an Android device):
    - `world/craft.rs` (new): `EnumToolMaterial` (wood/stone/iron/diamond/gold), pickaxe/axe/shovel ids 256..=286, `getStrVsBlock`,
      `ItemPickaxe.canHarvestBlock` (obsidian level 3, diamond/gold/redstone level 2, iron/lapis level 1, else rock/iron),
      `ItemSpade.canHarvestBlock` (snow). 26 shaped recipes (`RecipesTools` loop for 5 materials x 3 tools, planks, sticks,
      workbench, chest, furnace, torch, sandstone, snow/clay blocks, glowstone, wool); the matcher is `ShapedRecipes.matches`.
    - `Screen`: `ContainerPlayer` (2x2) and `ContainerWorkbench` (3x3). Touch has no mouse, so a tap is a left click and a toggle
      button ("1") turns taps into right clicks (put one, take half). Result slot as in `SlotCrafting`: refuses input, a take uses up
      one of each ingredient. Closing (or tapping outside the panel with the cursor full) throws the cursor stack and the grid out
      along the look direction (`dropPlayerItem`, 40 tick pickup delay).
    - `items.rs`: `Inventory` is 36 slots (`mainInventory`; pickups already fill the hotbar first), `ItemStack.damage` is `u16` (tool
      wear), tools stack to 1, `Inventory::damage` = `ItemStack.damageItem` (breaks past maxUses), `Drops::throw`.
    - `dig.rs`: `strength` and `Dig::tick` take the held item: `canHarvestBlock` false = the 1/100 rate, else tool efficiency / hardness / 30,
      with the /5 for water and air. `can_harvest` = material half (`harvestable_by_hand`) or the held tool. `lib.rs` breaks the block,
      wears the tool, and spawns the drops only if `can_harvest`: **stone by hand now drops nothing**, like the original.
    - Touch: inventory button left of pause; using a workbench (tap) opens the 3x3 screen instead of placing. While a screen is open the move
      stick, look, jump, hotbar and crosshair are hidden and every press is a tap. `hud.rs` quad capacity 512 -> 2048 for the screen.
    - Not done: smelting (so no iron/gold ingots), hoes, swords, shears (web and leaves still need them), armor slots, shift-click,
      item sprites (tools are a handle plus a head shape in the material colour), the other ~100 `CraftingManager` recipes.
    - The `ponytail` note in the drops entry below ("bare hands harvest everything") is superseded by this entry.
- `done` drops + hotbar inventory (`world/items.rs`, `render/items.rs`; the logic is unit-tested on a Linux host in a scratch crate,
  `lib.rs`/wgpu NOT compiled here: ):
    - Drops port `Block.dropBlockAsItem`: `quantityDropped`, then per item one `nextFloat` (chance 1.0) and `idDropped`, then the 3
      position draws, in the Java order on one `JavaRandom`. Table covers every block worldgen makes plus the metadata-free extras
      (stone -> cobblestone, grass/farmland -> dirt, gravel -> flint 1/10, coal/diamond/lapis(4-8 dye:4)/redstone(4-5) ores, leaves ->
      sapling 1/20, tall grass -> seeds 1/8, web, clay x4, snow block x4, glowstone dust 2-4, reeds, furnace, signs, redstone torch;
      none for fluids, ice, glass, bookshelf, TNT, spawner, snow layer, dead bush). Not yet: doors, bed, crops, slabs, stairs (need metadata).
    - `EntityItem`: 0.25 box, 20 Hz, gravity 0.04, drag 0.98, ground friction 0.588 (ice 0.9604), 10 tick pickup delay, 6000 tick life, pickup when
      the player's box grown 1.0 in x/z touches it. Collision tests the box centre line (ponytail, see items.rs). Max 256 entities.
    - `Inventory`: 9 hotbar slots, `addItemStackToInventory` (top up a matching stack, else first empty, partial adds), max stack 64 (16 snowball, 1 sign/door/bed).
      Starts empty; a tap places the selected item if it is a block (id < 256) and uses one up. Full hotbar leaves the item on the ground.
    - Bare hands harvest everything for now (vanilla `canHarvestBlock` would drop nothing from stone without a pickaxe; no tools/crafting yet).
    - Open: placing plants has no `canBlockStay` check; items are drawn as cubes, full brightness, no spin; no 27-slot inventory screen (M6).
- `done` hardness-based digging (compiled and ran on an Android device): `world/dig.rs` ports `Block.blockStrength` and the `PlayerControllerSP` damage
  counter at 20 Hz (hardness table from Block.java; bare hand: rock/iron/snow/web dig 3.3x slower; 5x slower when airborne or
  head under water; instant for hardness 0; 5-tick wait after a break; bedrock/portal unbreakable). Touch: hold still on the
  right half for 0.4 s to start digging, keep holding to finish (aiming elsewhere restarts the damage); progress bar under the
  crosshair (vanilla's crack textures need M14). Tap still places. No tools or drops yet (inventory).
- `done` faster world loading (compiled and ran on an Android device): chunk map uses a cheap integer hasher instead of SipHash; light work is bounded by
  10 ms per frame instead of a cell count and lights up to 2 chunks per frame; seam recomputation skips cells above the tallest
  column and block light when neither chunk has any; `App::init` (off the render thread) lights and meshes the spawn area
  (>= 24 chunk meshes or 8 s) before the first frame. Still open: populate and meshing run on the render thread.
- `done` plants drawn (written WITHOUT a Rust toolchain, then compiled and ran on an Android device; tests not run): flowers, mushrooms, tall grass, dead bush
  and reeds are two crossed double-sided quads (`chunk::cross_shape`, sized from each block's bounds; flat colours until M14
  textures), lit by their own cell, and pickable/breakable as a whole cell. Still not solid. Snow layer (78) is still not drawn.
- `done` day/night cycle (written WITHOUT a Rust toolchain, then compiled and ran on an Android device; tests not run):
    - `world/sky.rs`: ports of `calculateCelestialAngle`, `calculateSkylightSubtracted`, the sky colour (`func_4079_a` +
      `getSkyColorByTemp`, AWT HSB maths). 24000 ticks per day at 20 ticks/s, new world starts at tick 0 (sunrise). 2 tests.
    - `ChunkManager::set_sky_sub` (0..=11) marks every mesh stale when it changes; `mesh::build` takes `sky_sub` and uses
      `max(sky - sky_sub, block)` per cell, so night is dark but lava/torches stay lit. `temperature_at` feeds the sky colour.
    - Not done: sun, moon and stars are not drawn (done later: see the sun/moon/weather entry), no fog, no rain/thunder terms, time is not saved (M7) and not adjustable.
- `done` M5 block interaction (written WITHOUT a Rust toolchain, then compiled and ran on an Android device; tests not run, ):
    - `world/pick.rs`: port of `World.func_28105_a` + `Block.collisionRayTrace` (f64, 4.0 reach), place cell/replaceable/player-overlap rules. 3 tests.
    - `world/chunks/light.rs`: port of the b1.7.3 light engine (sky + block light, region queue, `MetadataChunkBlock` relaxation,
      `Chunk.func_1003_g` relight, `generateSkylightMap`). Chunks light once final; edits go through `ChunkManager::set_block`. 1 test.
    - `chunk.rs`: `light_opacity`/`light_value` tables derived from Block.java, `brightness`, `height_map`. `mesh.rs`: faces use the
      neighbour cell's brightness x vanilla face shade (1.0/0.5/0.8/0.6); `push_box`. `render/outline.rs`: selection outline.
    - Touch: tap on the right half places, hold breaks (repeat 0.25 s), drag looks. Crosshair added. Hotbar slot = block placed.
    - Simplifications: instant break, no drops/consumption (M6), no day/night (`skylightSubtracted` = 0), plants/liquids not pickable,
      light seams across a not-yet-final neighbour are fixed by the seam strips when it is lit.
- `done` M4d caves, trees, populate (compiled and tested on a Linux host with rustc 1.85; compiled and ran on an Android device):
    - `gen/caves.rs`, `gen/populate.rs` (new), `OverworldGenerator::generate` now ends with the caves; `populate_ores`
      and `next_u31` deleted. `mobSpawnerNoise` is the 8th noise stack (after the 7 terrain ones).
    - `world/chunks.rs`: raw ring is now `RENDER_DIST + 2`, populate (1 chunk/frame, nearest first) needs the 2x2 raw
      chunks, a chunk is meshed once populate ran on it and its -X/-Z/-X-Z neighbours (`is_final`); a populate that
      touches meshed chunks marks them for a rebuild. Spawn area is `preload(-1, 2)`.
    - Golden: `G.java` has a fake `World` (2x2 chunks, column light model, no-op springs) and prints RAW/POP hashes plus a
      block table; 3 seeds, 11 cases (taiga+snow, forest, lava lake, dungeon, pumpkin, mushrooms, cactus, clay, big trees).
    - Plants are neither meshed nor solid (`is_plant`); atlas colours for the new blocks. Spawn search skips trees.
    - The M4f chunk manager compiled first try on rustc 1.85; its 3 tests pass.
- `done` M4f chunk manager (`world/chunks.rs`; written without a Rust toolchain, NOT compiled, tested or run on
  a device yet, so  on the first CI run):
    - Replaces the 48x48 super-chunk (gone from `lib.rs`, `mesh.rs`, `populate_ores`). Chunks live in a
      `HashMap<(cx, cz), Entry>`; each has its own vertex/index buffer (empty chunks have none).
    - Ring: circle of `RENDER_DIST` (4) chunks is meshed and drawn, `RENDER_DIST + 1` is generated (a chunk is
      meshed only when its 4 neighbours exist, so seams cull correctly), unload beyond `RENDER_DIST + 2`.
    - Generation runs on 1-2 `std::thread` workers, each with its own generator (result does not depend on
      the worker: `generate()` reseeds per chunk). At most `2 x workers` requests in flight, rebuilt nearest-first
      from the player position every frame. Meshing + upload stay on the render thread, 2 chunks per frame.
    - Physics reads blocks through `ChunkManager::block`; an unloaded chunk reads as solid (invisible wall,
      no falling into void). Spawn: the 3x3 chunks around the origin are generated in `App::init`.
    - `populate_ores` is chunk-local (veins clipped at chunk edges; still UNVERIFIED, still replaced in M4d).
    - Tests: mesher edge culling (4 sides), block lookup across negative chunk coords, ring load/unload.
    - Not done on purpose: frustum culling (M13; the draw loop has a marker comment), greedy meshing, mesh on
      workers, saving chunks.
- `aef24f7` M3e-atlas-fix (1/2): 16x16 atlas + panic catcher in init.
- `2a5497f` M3e-atlas-fix (2/2): Uint32 indices. **Black screen root cause**: the
  48x128x48 super-chunk pushes the per-frame index count past `u16::MAX`, so
  `IndexFormat::Uint16` silently clipped the draw and wgpu presented black.
  Atlas size was a red herring.
- `ad33e0d` M12: Touch UX overlay (HUD + d-pad + look-stick + pause menu).
  Files: `src/input/{mod,touch_ui}.rs`, `src/render/hud.rs`,
  `src/lib.rs`, `ROADMAP.md`. Region-based touch UI state machine plus a
  separate 2D orthographic wgpu pass for the HUD overlay (alpha-blended,
  depth-less, runs after the chunk pass). 9 unit tests, 15/15 pass.
  Build status:
    - `cargo test --lib`: 15/15 pass on the host.
    - `cargo build --target aarch64-linux-android --lib --release`: clean,
      4.5 MB `libmc_rs.so`, ELF confirmed AArch64.
    - `cargo apk build --release`: not run locally (this host is aarch64
      Android, the SDK build-tools are x86_64 glibc ELFs). The CI workflow
      at `.github/workflows/ci.yml` runs the same command on a GitHub-hosted
      ubuntu-22.04 runner — that APK build is the end-to-end check.
  Verified against b1.7.3 sources:
    - Hotbar cell count (9), 20 px cell width, 22 px tall, centred horizontally.
      `GuiIngame.java` lines 58-62.
    - `moveStrafe` / `moveForward` semantics ({-1,0,1}). `MovementInputFromOptions.java`
      lines 67-83.
    - Jump velocity 8.4 m/s when on_ground. Preserved from the M2 baseline.
  UNVERIFIED (no b1.7.3 source — b1.7.3 PC has no touch UX at all):
    - Move-stick radius, look-zone split (left/right half), jump button position.
    - Pause and resume button rectangles.
  Follow-up: cross-check the touch rectangles against Pocket Edition 0.x
  or any later touch-based Minecraft client. Run `cargo apk build --release`
  on the CI runner and verify on a phone.
- `done` M4a-c: faithful Random/noise, climate biomes, terrain + surface. Golden test now
  passes (it failed before M4e because of the float constants below).
- `done` M4e fix pass (built and unit-tested on a host with a stubbed android-activity;
  NOT yet run on a device):
    - 48x48 super-chunk was indexed with the 16-deep `(x<<11)|(z<<7)|y` shifts; the bits
      overlap, so 1536 of 2304 columns overwrote each other (scrambled terrain). Now
      `(x*depth+z)*128+y` in lib.rs, mesh.rs, overworld.rs. Test: single block = one cube.
    - Jump never fired: `ground_test` probed under the box centre, not the feet. Test:
      standing on a floor is on_ground and can jump.
    - Camera sat 2.52 above the feet (1.62 added to the box centre). Now 1.62 above feet.
    - `camera.aspect` was never initialised (1.0); set at init, and the swapchain is
      re-synced to the native window size on resize/insets/focus events.
    - Status + nav bars hidden via JNI (`immersive.rs`) on window creation and focus gain.
    - Climate noise scales: `(double)0.025F` / `(double)0.05F` as in the Java.
  Confirmed on a device (screenshot): terrain renders correctly and blocks are square, so the
  stretch is gone. Still open: caves; populate; faithful ores; HUD does not yet avoid the
  display cutout.
    - Black strip at the left edge (display cutout area): fixed in `immersive.rs` with
      `layoutInDisplayCutoutMode = SHORT_EDGES` (Android 9+). Not yet seen on a device.
- `pending` M4d: caves, trees, populate (next, see "Next step" above).

- `done` Gear + shift-click (host-tested: `world/` + atlas, 51 tests; `lib.rs` not compiled here, rustc 1.75 < wgpu 26):
    - `world/gear.rs` (new): `bucket_fill`/`bucket_pour` (`ItemBucket`), `arrow_velocity` (1.5 b/tick), `use_on_mob` (shears 2+rand(3) wool, dye `~d&15`, bucket on cow), `Hook` (`EntityFish`, bite 1/500 or 1/300 in rain, `catch` wear 1/2).
    - `mobs.rs`: `Mob.sheared`, `Arrow.player`, `Ev::Landed`, `Mobs::shoot`; player arrows do 4 damage and drop as items. `craft.rs`: 5 recipes, rod durability 64, `Screen::shift_click`.
    - `lib.rs`: `use_held` (bow, rod, bucket, else food), mob interaction before attack, hook tick at 20 Hz, shift toggle, armor bar.
    - ponytail: hook never snags mobs, no draw time on the bow, no arrow spread golden, apples have no source (as in b1.7.3 outside chests).
- `done` block logic, step 3 of 5: the bed (written WITHOUT a Rust toolchain: not compiled, not run; +1 test `pick::door_tests::beds_place_on_two_floor_cells_and_wake_beside`, the `Level` round trip gains the bed). Ported from `BlockBed`, `ItemBed`, `EntityPlayer.sleepInBedAt` / `wakeUpPlayer` / `onUpdate`, `World.tick` (all asleep):
    - `world/pick.rs`: `BED_DIR` (`headBlockToFootBlockMap`), `bed_meta` (`ItemBed.onItemUse`), `wake_cell` (`getNearestEmptyChunkCoordinates`). `chunk.rs`: bed bounds / collision (9/16 high, so it needs a jump like vanilla), `atlas.rs`: tiles from `BlockBed.getBlockTextureFromSideAndMetadata` + `ModelBed.bedDirection` (planks underneath). `ticks.rs`: `bed_neighbour` (a half without its partner breaks, only the half without bit 8 drops the bed). `items.rs` / `craft.rs`: drops and the wool + planks recipe.
    - `lib.rs`: a tap on a bed sleeps at night within 3 / 2 / 3 blocks (`use_bed`: occupied bit, position and view of the bed, no movement or look while asleep); `sleep_tick` counts to 100 ticks, then sets the time to the next morning and wakes (`wake`: stands on the first free cell beside the bed and the bed becomes the respawn point); a missing bed or daybreak wakes earlier; the jump button leaves the bed. Death respawns at the bed while it stands (`respawn_pos`), else at the world spawn. `save.rs`: the bed is an optional tail of `level` (older files load without it).
    - Not done: the "no sleep now" / occupied messages (no HUD text), hostile mobs appearing when waking (`performSleepSpawning`), the bed model's lying player and camera offset (`func_22052_e`), mirrored bed tiles, the `Level` bed is not cleared when it is destroyed (the respawn checks the block). UNVERIFIED: view yaw from `getBedOrientationInDegrees`.
- `done` block logic, step 1 of 5: fire, mushroom spread, snow and ice, rain on farmland (written WITHOUT a Rust toolchain: not compiled, not run; +1 test `ticks::tests::burn_table_and_snow_floor` not run). Ported from the decompiled `BlockFire`, `BlockMushroom`, `BlockSnow`, `BlockIce`, `BlockFarmland`, `ItemFlintAndSteel`, `World.tick`:
    - `world/ticks.rs`: `fire` = `BlockFire.updateTick` (tick rate 40, age in metadata, `setBurnRate` table, the 6 `tryToCatchBlockOnFire` chances, the 3x3x6 spread loop with the Java's `(var8 - 1, var10, var4)` rain test kept as is, rain and netherrack rules), `added` / `neighbour` arms for fire (no ground and no fuel = gone), `mushroom` = `BlockMushroom.updateTick` (incl. its two unused draws; `canBlockStay` now has the light < 13 limit), `snow_ice` = the snow / ice part of `World.tick` (1 chunk in 16 per tick, column from the same LCG; snow while it rains, light < 10, snowy biome; still water freezes), snow layer / ice melt on block light, `rained_on` = `canBlockBeRainedOn`, farmland wets in rain. `Ticks::step` takes the rain strength (`func_27161_C`: > 0.2).
    - `world/chunks.rs`: `random_ticks` also returns the snow columns, `block_light` = `getSavedLightValue(Block)`. `craft.rs` / `lib.rs`: flint and steel (iron ingot + flint, 64 uses) lights the cell next to the face aimed at. `chunk.rs` / `atlas.rs`: fire is a plant-like cross on tile 31.
    - Not done: portal from fire (M11), TNT priming from fire (step 5), fire sound and smoke, `renderBlockFire` flames (crossed quads stand in), mushrooms tick only in chunks within `ACTIVE`, UNVERIFIED: `snow_ok` tells glass, leaves and ice apart by hand (`isOpaqueCube`).
    - Next steps, one per session: 2 doors + beds, stairs facing + collision; 3 tile entities (chest facing, spawner spawning, signs); 4 ladders, rails + minecarts, boats; 5 redstone, pistons, TNT, jukebox + note block.
- `done` block logic, step 2 of 5: stairs facing + two-box collision, doors (written WITHOUT a Rust toolchain: not compiled, not run; +2 tests not run: `chunk::phys_tests::stairs_and_doors_have_their_java_boxes`, `pick::door_tests::stairs_face_the_player_and_doors_need_a_floor`). Ported from `BlockStairs`, `BlockDoor`, `ItemDoor`:
    - `world/chunk.rs`: `physics_id` now also maps stairs (`STAIRS_PHYS + facing`) and doors (`DOOR_PHYS + getState`) to pseudo ids, `collisions(id)` returns up to two boxes (`stair_boxes`, shared with the mesher; `door_box`), `box_bounds` gives the door leaf for pick / outline / mesh. `physics.rs` tests every box, so a stair is stepped up by the existing `STEP` code. Doors no longer hide neighbours' faces.
    - `world/pick.rs`: `stairs_meta` (`onBlockPlacedBy`), `door_meta` (`ItemDoor.onItemUse`: facing, hinge side, `canPlaceBlockAt`). `lib.rs`: stairs take their facing from the camera yaw (`yaw + 180` degrees = `rotationYaw`), a door item places both halves against a top face, a tap on a wooden door swings both halves (`toggle_door`), iron doors ignore the hand.
    - `world/ticks.rs`: `door_neighbour` = `BlockDoor.onNeighborBlockChange` (no redstone yet). `items.rs`: wooden / iron door drops (the upper half drops nothing). `craft.rs`: wooden door, iron door, wooden and cobblestone stairs. `atlas.rs`: door tiles 97 / 98, upper half 81 / 82.
    - Not done: the bed (needs sleeping, time skip and the bed spawn: next patch), door sounds, redstone-driven doors (step 5), mirrored hinge texture, stairs `getBlockTexture` metadata, items and mobs still treat stairs as a full cell (`collision` is the bounding box).
